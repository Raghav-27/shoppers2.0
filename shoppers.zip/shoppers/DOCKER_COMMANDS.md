# Docker Management Scripts for Shoppers App

## Development Environment

# Start all services in development mode
docker-compose -f docker-compose.dev.yml up --build

# Start in background
docker-compose -f docker-compose.dev.yml up --build -d

# View logs
docker-compose -f docker-compose.dev.yml logs -f

# Stop all services
docker-compose -f docker-compose.dev.yml down

# Remove volumes (careful - this will delete Redis data)
docker-compose -f docker-compose.dev.yml down -v

## Production Environment

# Start all services in production mode
docker-compose up --build

# Start in background  
docker-compose up --build -d

# View logs
docker-compose logs -f

# Stop all services
docker-compose down

## Individual Services

# Build backend only
docker build -t shoppers-backend ./backend

# Run backend only (requires Redis running)
docker run -p 5000:5000 --env REDIS_HOST=localhost shoppers-backend

# Build frontend only
docker build -t shoppers-frontend .

## Useful Commands

# View running containers
docker ps

# View all containers
docker ps -a

# Remove all stopped containers
docker container prune

# Remove unused images
docker image prune

# Check Redis data using redis-commander (when running)
# Visit: http://localhost:8081

## Environment Variables

# Frontend (.env file in root):
REACT_APP_API_URL=http://localhost:5000

# Backend (set in docker-compose.yml):
REDIS_HOST=redis
REDIS_PORT=6379
REDIS_KEY=meesho:keyword:filter:data