# Admin Dashboard System

## Overview

The admin dashboard provides comprehensive management capabilities for users, sellers, orders, and products in the Shoppers platform. It runs as a separate microservice on port 5002.

## Features

### 1. **Dashboard Overview**
- Total users count (with admin count)
- Seller statistics (active/frozen)
- Order statistics (total/pending/completed)
- Product count
- Quick action buttons to navigate to management pages

### 2. **User Management**
- View all registered users
- Search by name or email
- Sort by any column
- Pagination support (20 users per page)
- View user roles (Admin/User)
- See join dates

### 3. **Seller Management**
- View all sellers
- Search by business name or email
- Filter by status (Active/Frozen)
- **Freeze/Unfreeze seller accounts** with confirmation modal
- View seller statistics (product count)
- Sort by any column
- Pagination support (20 sellers per page)

### 4. **Order Management**
- View all customer orders
- Search by order ID, email, or phone
- Filter by order status
- View order details (amount, payment status, date)
- Color-coded status badges
- Pagination support (20 orders per page)

### 5. **Product Management**
- View all seller products
- Search by product name
- View product images
- See stock levels with color indicators
- View product status (Active/Inactive)
- Sort by any column
- Pagination support (20 products per page)

## Architecture

### Backend (Port 5002)

**File**: `backend/admin_api.py`

#### Endpoints:

**Authentication**:
- All endpoints require admin authentication via `verify_admin_session`
- Admin status checked via `is_admin` field in user data

**Dashboard**:
- `GET /api/admin/dashboard/stats` - Overview statistics

**User Management**:
- `GET /api/admin/users` - List all users (with search, pagination)
- `GET /api/admin/users/{email}` - Get user details

**Seller Management**:
- `GET /api/admin/sellers` - List all sellers (with search, status filter, pagination)
- `GET /api/admin/sellers/{seller_id}` - Get seller details
- `PUT /api/admin/sellers/{seller_id}/freeze` - Freeze seller account
- `PUT /api/admin/sellers/{seller_id}/unfreeze` - Unfreeze seller account

**Order Management**:
- `GET /api/admin/orders` - List all orders (with search, status filter, pagination)
- `GET /api/admin/orders/stats` - Order statistics by status

**Product Management**:
- `GET /api/admin/products` - List all products (with search, pagination)

### Frontend

**Components**:
- `src/components/admin/AdminDashboard.js` - Main dashboard with stats cards
- `src/components/admin/UsersTable.js` - User management table
- `src/components/admin/SellersTable.js` - Seller management with freeze/unfreeze
- `src/components/admin/OrdersTable.js` - Order viewing
- `src/components/admin/ProductsTable.js` - Product catalog
- `src/components/admin/DataTable.js` - Reusable table component

**Routes**:
- `/admin` - Dashboard
- `/admin/users` - User management
- `/admin/sellers` - Seller management
- `/admin/orders` - Order management
- `/admin/products` - Product management

## Setup Instructions

### 1. Creating an Admin User

Admin users must be created manually in Redis. There are two methods:

#### Method A: Using Redis CLI

```bash
# Connect to Redis DB 0
docker exec -it shoppers-redis-1 redis-cli

# Select database 0
SELECT 0

# Get existing user data
GET user:admin@example.com

# Update user with is_admin flag
SET user:admin@example.com '{"first_name":"Admin","last_name":"User","email":"admin@example.com","password":"<hashed_password>","phone":"1234567890","country":"India","created_at":"2025-01-15T00:00:00","is_admin":true}'
```

#### Method B: Using Redis Commander

1. Open Redis Commander: http://localhost:8081
2. Navigate to DB 0
3. Find the user key: `user:your-email@example.com`
4. Edit the JSON value to add: `"is_admin": true`
5. Save changes

### 2. Starting the Admin API

The admin API is automatically started with Docker Compose:

```bash
# Start all services including admin API
docker-compose -f docker-compose.dev.yml up --build -d

# Check admin API logs
docker logs shoppers-admin-backend-1 -f

# Verify admin API is running
curl http://localhost:5002/health
```

### 3. Accessing the Admin Dashboard

1. Sign in with an admin account
2. Click on your profile avatar in the navbar
3. Click "Admin Panel" (only visible for admin users)
4. You'll be redirected to `/admin`

## Security Considerations

### 1. **Admin Authentication**
- All admin endpoints verify session token
- Check `is_admin` flag in user data
- Return 403 Forbidden if not admin
- Session verification happens on every request

### 2. **Session Management**
- Admin sessions use same HTTP-only cookies as regular users
- 7-day session expiry
- Session data stored in Redis DB 0

### 3. **Action Logging**
- Admin actions (freeze/unfreeze) are logged to backend console
- Format: `Admin {email} {action} seller {seller_id}`

### 4. **Recommendations**
- Use strong passwords for admin accounts
- Limit number of admin users
- Consider adding 2FA for admin accounts (future enhancement)
- Add audit trail to Redis (future enhancement)
- Implement IP whitelisting for admin access (future enhancement)

## Database Structure

### Redis DB 0 - Users & Sessions
```
user:{email} → JSON with is_admin field
session:{token} → Session data
```

### Redis DB 1 - Seller Products
```
seller:prod:{seller_id}:{product_id} → Product details
seller:prod:all → Set of all products
```

### Redis DB 2 - Sellers
```
seller:info:{seller_id} → Seller profile (includes status field)
seller:all → Set of all seller IDs
```

### Redis DB 3 - Orders
```
order:{order_id} → Order data
order:all → Set of all order IDs
order:status:{status} → Orders by status
```

## Freeze/Unfreeze Functionality

### How It Works:

1. **Freeze**: Sets `status: "inactive"` in `seller:info:{seller_id}`
2. **Unfreeze**: Sets `status: "active"` in `seller:info:{seller_id}`

### Effects of Freezing:

- Seller cannot log in to seller dashboard
- Seller products may not be visible (depends on implementation)
- Seller orders remain accessible
- Historical data is preserved

### Confirmation Modal:

- Shows before freeze/unfreeze action
- Displays seller business name
- Warning text for freeze action
- Prevents accidental clicks

## Pagination System

All tables support pagination:
- **Default limit**: 20 items per page
- **Query params**: `offset` and `limit`
- **Response format**:
  ```json
  {
    "items": [...],
    "total": 150,
    "offset": 0,
    "limit": 20
  }
  ```

## Search Functionality

### Debounced Search:
- 500ms delay before API call
- Reduces server load
- Improves user experience

### Search Fields:
- **Users**: First name, last name, email
- **Sellers**: Business name, email, seller ID
- **Orders**: Order ID, customer email, phone
- **Products**: Product name, description

## Dark Mode Support

All admin components support dark mode:
- Automatically synced with app theme
- Dark glassmorphism effects
- Adjusted color schemes
- Enhanced contrast for readability

## Future Enhancements

1. **Bulk Actions**: Select multiple sellers to freeze/unfreeze
2. **Advanced Filters**: Date range, price range, location
3. **Export Data**: CSV/Excel export for all tables
4. **Real-time Updates**: WebSocket for live order updates
5. **Analytics**: Charts and graphs for trends
6. **Audit Trail**: Complete admin action history in Redis
7. **User Management**: Ban/unban users, reset passwords
8. **Email Notifications**: Notify sellers when frozen
9. **Role Permissions**: Granular admin permissions (super admin, moderator)
10. **Activity Monitoring**: Real-time admin dashboard activity

## Troubleshooting

### Admin Panel Link Not Showing:
- Ensure user has `"is_admin": true` in Redis
- Clear browser cache and cookies
- Check session is valid
- Verify user data structure in Redis

### API Returns 403 Forbidden:
- Check `is_admin` flag is set correctly
- Verify session token is valid
- Check Redis DB 0 for user data
- Review backend logs for errors

### Freeze/Unfreeze Not Working:
- Check seller ID is correct
- Verify Redis DB 2 is accessible
- Check `sellers_manager.update_seller()` function
- Review admin API logs

### Tables Not Loading:
- Check admin API is running on port 5002
- Verify CORS settings allow localhost:3000
- Check browser console for errors
- Ensure Redis databases are accessible

## Development

### Adding New Admin Features:

1. **Backend**: Add endpoint to `backend/admin_api.py`
2. **Frontend**: Create component in `src/components/admin/`
3. **Route**: Add to `src/App.js`
4. **Link**: Add to admin dashboard or navbar

### Testing Admin Features:

```bash
# Test admin authentication
curl -X GET http://localhost:5002/api/admin/dashboard/stats \
  --cookie "auth_token=<your_token>"

# Test seller freeze
curl -X PUT http://localhost:5002/api/admin/sellers/1/freeze \
  --cookie "auth_token=<your_token>"

# Test user listing
curl -X GET "http://localhost:5002/api/admin/users?offset=0&limit=20" \
  --cookie "auth_token=<your_token>"
```

## Support

For issues or questions:
1. Check backend logs: `docker logs shoppers-admin-backend-1`
2. Check frontend console for errors
3. Verify Redis data structure
4. Review this README for common issues

---

**Version**: 1.0.0  
**Last Updated**: January 15, 2026  
**Port**: 5002  
**Database**: Redis (DB 0-3)
