"""
Test admin login and dashboard stats
"""
import requests
import json

ADMIN_URL = "http://localhost:5002"

def test_admin_login_and_dashboard():
    """Test admin login and dashboard stats fetching"""
    print("\n1. Testing admin login...")
    
    # Try to login with admin credentials
    login_data = {
        "email": "admin@shoppers.com",
        "password": "admin123"  # Common default password, adjust if needed
    }
    
    session = requests.Session()
    
    response = session.post(
        f"{ADMIN_URL}/api/admin/login",
        json=login_data,
        headers={"Content-Type": "application/json"}
    )
    
    print(f"Login Status: {response.status_code}")
    
    if response.status_code == 200:
        print("✅ Admin login successful!")
        print(f"Response: {json.dumps(response.json(), indent=2)}")
        
        # Now try to fetch dashboard stats
        print("\n2. Fetching dashboard stats...")
        
        stats_response = session.get(
            f"{ADMIN_URL}/api/admin/dashboard/stats",
            headers={"Content-Type": "application/json"}
        )
        
        print(f"Dashboard Stats Status: {stats_response.status_code}")
        
        if stats_response.status_code == 200:
            stats = stats_response.json()
            print(f"\n📊 Dashboard Statistics:")
            print(json.dumps(stats, indent=2))
            
            # Verify sellers
            sellers_total = stats.get('sellers', {}).get('total', 0)
            sellers_active = stats.get('sellers', {}).get('active', 0)
            
            # Verify products
            products_total = stats.get('products', {}).get('total', 0)
            
            print(f"\n✅ Summary:")
            print(f"   Sellers: {sellers_total} (Active: {sellers_active})")
            print(f"   Products: {products_total}")
            print(f"   Users: {stats.get('users', {}).get('total', 0)}")
            print(f"   Orders: {stats.get('orders', {}).get('total', 0)}")
            
            if sellers_total > 0:
                print("\n🎉 SUCCESS! Admin dashboard can now see sellers!")
            else:
                print("\n❌ ISSUE: Sellers still showing as 0")
                
            if products_total > 0:
                print("🎉 SUCCESS! Admin dashboard can now see products!")
            else:
                print("❌ ISSUE: Products still showing as 0")
                
        else:
            print(f"❌ Failed to fetch stats: {stats_response.text}")
            
    else:
        print(f"❌ Login failed: {response.text}")
        print("\nTrying different password...")
        
        # Try alternative passwords
        for pwd in ["Admin@123", "admin", "password", "shoppers123"]:
            login_data["password"] = pwd
            response = session.post(
                f"{ADMIN_URL}/api/admin/login",
                json=login_data,
                headers={"Content-Type": "application/json"}
            )
            
            if response.status_code == 200:
                print(f"✅ Login successful with password: {pwd}")
                
                # Fetch stats
                stats_response = session.get(
                    f"{ADMIN_URL}/api/admin/dashboard/stats"
                )
                
                if stats_response.status_code == 200:
                    stats = stats_response.json()
                    print(f"\n📊 Dashboard Statistics:")
                    print(json.dumps(stats, indent=2))
                    
                break

if __name__ == "__main__":
    print("=" * 60)
    print("ADMIN DASHBOARD TEST")
    print("=" * 60)
    
    test_admin_login_and_dashboard()
    
    print("\n" + "=" * 60)
    print("TEST COMPLETE")
    print("=" * 60)
