"""
Test script to verify admin dashboard data fetching works correctly
"""
import requests
import json

BASE_URL = "http://localhost:5001"  # Seller backend
ADMIN_URL = "http://localhost:5002"  # Admin backend

def test_seller_registration():
    """Test registering a new seller"""
    print("\n1. Testing seller registration...")
    
    seller_data = {
        "email": "testshop@example.com",
        "password": "testpass123",
        "business_name": "Test Shop",
        "contact_person": "John Doe",
        "phone": "+1234567890",
        "address": "123 Test Street"
    }
    
    response = requests.post(
        f"{BASE_URL}/api/seller/register",
        json=seller_data,
        headers={"Content-Type": "application/json"}
    )
    
    print(f"Status: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    if response.status_code == 201:
        print("✅ Seller registration successful!")
        return response.cookies
    else:
        print("❌ Seller registration failed!")
        return None

def test_add_product(cookies):
    """Test adding a product"""
    print("\n2. Testing product creation...")
    
    product_data = {
        "name": "Test Product",
        "description": "A test product",
        "price": 99.99,
        "category": "Electronics",
        "stock": 100,
        "image_url": "https://example.com/image.jpg"
    }
    
    response = requests.post(
        f"{BASE_URL}/api/seller/products",
        json=product_data,
        headers={"Content-Type": "application/json"},
        cookies=cookies
    )
    
    print(f"Status: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    if response.status_code == 201:
        print("✅ Product creation successful!")
        return True
    else:
        print("❌ Product creation failed!")
        return False

def test_admin_dashboard():
    """Test fetching admin dashboard stats"""
    print("\n3. Testing admin dashboard stats...")
    
    # First, we need to login as admin or create an admin session
    # For now, we'll just test the endpoint structure
    
    response = requests.get(
        f"{ADMIN_URL}/api/admin/dashboard/stats",
        headers={"Content-Type": "application/json"}
    )
    
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        stats = response.json()
        print(f"Response: {json.dumps(stats, indent=2)}")
        
        print(f"\n📊 Dashboard Statistics:")
        print(f"   Users: {stats.get('users', {}).get('total', 0)}")
        print(f"   Sellers: {stats.get('sellers', {}).get('total', 0)}")
        print(f"   Products: {stats.get('products', {}).get('total', 0)}")
        print(f"   Orders: {stats.get('orders', {}).get('total', 0)}")
        
        if stats.get('sellers', {}).get('total', 0) > 0:
            print("\n✅ Admin dashboard can see sellers!")
        else:
            print("\n❌ Admin dashboard shows 0 sellers!")
            
        if stats.get('products', {}).get('total', 0) > 0:
            print("✅ Admin dashboard can see products!")
        else:
            print("❌ Admin dashboard shows 0 products!")
            
    elif response.status_code == 401:
        print("⚠️  Need admin authentication (expected)")
        print("   But we can check Redis directly instead...")
    else:
        print(f"❌ Unexpected response: {response.text}")

def check_redis_directly():
    """Check Redis keys directly using redis-cli via Python"""
    print("\n4. Checking Redis directly...")
    
    try:
        import redis
        
        # Check DB 2 for sellers
        r2 = redis.Redis(host='localhost', port=6379, db=2, decode_responses=True)
        seller_all = r2.smembers('seller:all')
        seller_email_lookup = r2.hgetall('seller:email:lookup')
        
        print(f"\n   DB 2 (Sellers):")
        print(f"   - seller:all set: {seller_all}")
        print(f"   - seller:email:lookup: {seller_email_lookup}")
        
        if seller_all:
            for seller_id in seller_all:
                seller_info = r2.hgetall(f'seller:info:{seller_id}')
                print(f"   - seller:info:{seller_id}: {seller_info}")
        
        # Check DB 1 for products
        r1 = redis.Redis(host='localhost', port=6379, db=1, decode_responses=True)
        prod_all = r1.smembers('seller:prod:all')
        
        print(f"\n   DB 1 (Products):")
        print(f"   - seller:prod:all set: {prod_all}")
        
        if prod_all:
            for prod_key in list(prod_all)[:3]:  # Show first 3
                seller_id, product_id = prod_key.split(':')
                prod_data = r1.hgetall(f'seller:prod:{seller_id}:{product_id}')
                print(f"   - seller:prod:{seller_id}:{product_id}: {prod_data.get('name', 'N/A')}")
        
        print("\n✅ Redis data structure verified!")
        
    except ImportError:
        print("⚠️  redis-py not installed, skipping Redis check")
    except Exception as e:
        print(f"❌ Error checking Redis: {e}")

if __name__ == "__main__":
    print("=" * 60)
    print("ADMIN DASHBOARD DATA FETCHING TEST")
    print("=" * 60)
    
    # Test seller registration
    cookies = test_seller_registration()
    
    if cookies:
        # Test product creation
        test_add_product(cookies)
    
    # Test admin dashboard
    test_admin_dashboard()
    
    # Check Redis directly
    check_redis_directly()
    
    print("\n" + "=" * 60)
    print("TEST COMPLETE")
    print("=" * 60)
