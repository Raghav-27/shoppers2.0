const express = require('express');
const path = require('path');
const cors = require('cors');
const cookieParser = require('cookie-parser');

const app = express();

// Middleware
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());


// -----------------------------
// API ROUTES (YOUR BACKEND)
// -----------------------------

// Example:
// const userRoutes = require('./routes/userRoutes');
// app.use('/api/user', userRoutes);

// Add ALL your API routes above this line



// -----------------------------
// SERVE REACT FRONTEND
// -----------------------------

// Serve static files from React build
app.use(express.static(path.join(__dirname, 'build')));

// Catch-all: send index.html for ANY route not starting with /api/
app.get('*', (req, res) => {
  if (req.url.startsWith('/api/')) {
    return res.status(404).json({ error: 'API route not found' });
  }

  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});


// -----------------------------
// START SERVER
// -----------------------------
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
