# Quick Start: Address & Payment Features

## For Users

### Adding an Address During Checkout

1. **Navigate to Checkout**
   - Add items to cart
   - Click "Proceed to Checkout" (or navigate to `/checkout`)

2. **Select or Add Address**
   - See list of saved addresses
   - Click on address to select it
   - Or click "+ Add New Address"

3. **Fill Address Form** (if adding new)
   - **Label:** "Home", "Office", etc.
   - **Phone:** 10-digit number
   - **Street:** House/Building name
   - **City:** City name
   - **State:** State name
   - **Postal Code:** Zip/Postal code
   - **Country:** Country name
   - Check "Set as default" if desired

4. **Select Payment Method**
   - **Cash on Delivery (COD):** Pay when order arrives
   - **Online Payment:** Pay now using card

5. **Place Order**
   - For COD: Order placed immediately ✓
   - For Online: Redirected to payment page

### Making Online Payment

1. **After Selecting Online Payment**
   - You'll be redirected to `/payment/:orderId`
   - See order summary with total amount

2. **Pay with Card**
   - Click "💳 Pay with Card"
   - Enter card details:
     - Card Number (16 digits)
     - Expiry Date (MM/YY)
     - CVV (3 digits)
     - Cardholder Name

3. **Payment Status**
   - Success: ✓ Order confirmed, redirected to orders
   - Failed: ✗ Can retry payment

### Testing Payment (Demo Mode)

**Demo Buttons Available:**
- **✓ Simulate Success** - Test successful payment
- **✗ Simulate Failed** - Test failed payment

This is for testing before integration with real payment gateway.

### Viewing Your Addresses

1. Go to `/checkout` to see your saved addresses
2. Addresses include:
   - Label (Home, Office, etc.)
   - Complete address details
   - Phone number
   - Default address indicator

### Managing Addresses

**Edit Address:**
- Future enhancement - will allow updating saved addresses

**Delete Address:**
- Future enhancement - will allow removing saved addresses

**Set Default:**
- When adding/editing, check "Set as default"
- Default address pre-selected at checkout

## For Developers

### Testing Address Management

**API Test - Add Address:**
```bash
curl -X POST http://localhost:5000/api/user/addresses \
  -H "Content-Type: application/json" \
  -c cookies.txt \
  -b cookies.txt \
  -d '{
    "label": "Home",
    "phone": "9876543210",
    "street": "123 Main Street",
    "city": "Mumbai",
    "state": "Maharashtra",
    "postal_code": "400001",
    "country": "India",
    "is_default": true
  }'
```

**API Test - Get Addresses:**
```bash
curl http://localhost:5000/api/user/addresses \
  -b cookies.txt
```

**API Test - Update Address:**
```bash
curl -X PUT http://localhost:5000/api/user/addresses/addr_1_1234567890 \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d '{
    "label": "Office",
    "phone": "9876543211",
    "street": "456 New Street",
    "city": "Bangalore",
    "state": "Karnataka",
    "postal_code": "560001",
    "country": "India",
    "is_default": false
  }'
```

### Testing Payment Flow

**API Test - Initiate Payment:**
```bash
curl -X POST http://localhost:5000/api/payment/initiate \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d '{
    "order_id": "order_1234567890_user@example.com",
    "amount": 1999.98,
    "payment_method": "online"
  }'
```

**API Test - Confirm Payment:**
```bash
curl -X POST http://localhost:5000/api/payment/confirm \
  -H "Content-Type: application/json" \
  -d '{
    "session_id": "pay_order_1234567890_user@example.com_1234567890",
    "transaction_id": "TXN1234567890",
    "status": "success"
  }'
```

### Debugging

**Check Redis DB 0 (Addresses & Users):**
```bash
redis-cli -n 0
> KEYS *
> GET user:user@example.com
```

**Check Redis DB 4 (Orders):**
```bash
redis-cli -n 4
> KEYS *
> GET order_1234567890_user@example.com
```

**Frontend Errors:**
- Open browser DevTools (F12)
- Check Console tab for JavaScript errors
- Check Network tab to see API requests/responses

**Backend Errors:**
```bash
# Docker logs
docker logs <backend-container>

# Or check application logs
tail -f /path/to/logs
```

## Workflow Examples

### Example 1: Place COD Order with New Address

```
1. User logs in
2. Adds items to cart
3. Goes to checkout
4. Clicks "+ Add New Address"
5. Fills form:
   - Label: "Home"
   - Phone: "9876543210"
   - Address: "123 Main Street, Mumbai..."
   - Sets as default
6. Selects "Cash on Delivery"
7. Clicks "Place Order"
8. ✓ Order created, redirected to /orders
```

### Example 2: Place Online Payment Order with Existing Address

```
1. User logs in (has saved address)
2. Adds items to cart
3. Goes to checkout
4. Existing address already selected (default)
5. Selects "Online Payment"
6. Clicks "Place Order"
7. Redirected to /payment/:orderId
8. Sees order summary with amount
9. Clicks "Pay with Card"
10. Enters test card details
11. Clicks "Pay ₹1999.98"
12. For testing: Clicks "Simulate Success"
13. ✓ Payment confirmed, redirected to /orders
```

### Example 3: Failed Payment Retry

```
1. User completes checkout with online payment
2. On payment page, clicks "Simulate Failed"
3. Payment fails, shows error message
4. Clicks "Retry Payment"
5. Back to payment form
6. Can try again or go back to cart
```

## Common Tasks

### Task: Test Complete User Journey

```
1. Sign up new user
2. Browse products
3. Add items to cart
4. Go to checkout
5. Add new address
6. Place order (COD)
7. Check order history
8. Repeat with online payment
```

### Task: Verify Address Persistence

```
1. Add address during checkout
2. Complete order
3. Go to checkout again
4. ✓ Previously added address should appear
5. Should be selectable
```

### Task: Test Payment Gateway Flow

```
1. Place online payment order
2. Go to payment page
3. Use "Simulate Success" to test success flow
4. Verify order status is "confirmed"
5. Use "Simulate Failed" to test failure flow
6. Verify can retry
```

## Troubleshooting

### "No seller products in cart" error
- Make sure you added seller products (not marketplace products)
- Seller products have "source: seller" or "platform: Seller"

### Address form won't submit
- Check all fields are filled
- Phone must be exactly 10 digits
- Try entering data again

### Can't select address at checkout
- Make sure address was successfully added
- Check Redis DB 0 for user data
- Reload page and try again

### Payment page shows blank
- Check browser console for errors
- Verify order ID in URL
- Check backend API is running

### Order not appearing in history
- Check Redis DB 4 has the order
- Try refreshing page
- Check if you're logged in as correct user

## Next Steps

1. **For Testing:**
   - Use demo buttons on payment page
   - Test all address operations
   - Try different payment flows

2. **For Production:**
   - Integrate real payment gateway
   - Set up email notifications
   - Configure order tracking

3. **For Enhancement:**
   - Add address edit UI
   - Add address delete UI
   - Implement Google Maps integration
   - Add EMI options

## Resources

- **Full Documentation:** `ADDRESS_PAYMENT_GUIDE.md`
- **Migration Guide:** `MIGRATION_GUIDE.md`
- **Implementation Details:** `IMPLEMENTATION_SUMMARY.md`
- **API Documentation:** See `ADDRESS_PAYMENT_GUIDE.md` for all endpoints

## Support

For issues:
1. Check the troubleshooting section above
2. Review documentation files
3. Check console logs and network requests
4. Verify Redis connectivity
