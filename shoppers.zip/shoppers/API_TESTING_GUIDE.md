# API Testing Guide

## Postman Collection

### Authentication Setup
Before testing, ensure you have a valid session:
1. Sign up/login to create session
2. Cookies will be set by backend
3. Include credentials in all requests

## Address Management API

### 1. Add Address

**Request:**
```http
POST /api/user/addresses HTTP/1.1
Host: localhost:5000
Content-Type: application/json
Cookie: session=...

{
  "label": "Home",
  "phone": "9876543210",
  "street": "123 Main Street, Apt 4B",
  "city": "Mumbai",
  "state": "Maharashtra",
  "postal_code": "400001",
  "country": "India",
  "is_default": true
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Address added successfully",
  "address": {
    "id": "addr_1_1704873000",
    "label": "Home",
    "phone": "9876543210",
    "street": "123 Main Street, Apt 4B",
    "city": "Mumbai",
    "state": "Maharashtra",
    "postal_code": "400001",
    "country": "India",
    "is_default": true,
    "created_at": "2026-01-07T10:30:00"
  }
}
```

**Error Responses:**
```json
// 404 User not found
{
  "detail": "User not found"
}

// 500 Validation error
{
  "detail": "Phone number must be 10 digits"
}
```

### 2. Get All Addresses

**Request:**
```http
GET /api/user/addresses HTTP/1.1
Host: localhost:5000
Content-Type: application/json
Cookie: session=...
```

**Response (200 OK):**
```json
{
  "success": true,
  "addresses": [
    {
      "id": "addr_1_1704873000",
      "label": "Home",
      "phone": "9876543210",
      "street": "123 Main Street, Apt 4B",
      "city": "Mumbai",
      "state": "Maharashtra",
      "postal_code": "400001",
      "country": "India",
      "is_default": true,
      "created_at": "2026-01-07T10:30:00"
    },
    {
      "id": "addr_2_1704873060",
      "label": "Office",
      "phone": "9876543211",
      "street": "Corporate Plaza, 5th Floor",
      "city": "Bangalore",
      "state": "Karnataka",
      "postal_code": "560001",
      "country": "India",
      "is_default": false,
      "created_at": "2026-01-07T10:31:00",
      "updated_at": "2026-01-07T11:00:00"
    }
  ]
}
```

### 3. Update Address

**Request:**
```http
PUT /api/user/addresses/addr_1_1704873000 HTTP/1.1
Host: localhost:5000
Content-Type: application/json
Cookie: session=...

{
  "label": "Home (Updated)",
  "phone": "9876543210",
  "street": "456 New Avenue",
  "city": "Mumbai",
  "state": "Maharashtra",
  "postal_code": "400002",
  "country": "India",
  "is_default": true
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Address updated successfully",
  "address": {
    "id": "addr_1_1704873000",
    "label": "Home (Updated)",
    "phone": "9876543210",
    "street": "456 New Avenue",
    "city": "Mumbai",
    "state": "Maharashtra",
    "postal_code": "400002",
    "country": "India",
    "is_default": true,
    "created_at": "2026-01-07T10:30:00",
    "updated_at": "2026-01-07T12:00:00"
  }
}
```

**Error Responses:**
```json
// 404 Address not found
{
  "detail": "Address not found"
}
```

### 4. Delete Address

**Request:**
```http
DELETE /api/user/addresses/addr_1_1704873000 HTTP/1.1
Host: localhost:5000
Cookie: session=...
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Address deleted successfully"
}
```

**Error Responses:**
```json
// 404 Address not found
{
  "detail": "Address not found"
}
```

## Payment Gateway API

### 5. Initiate Payment

**Request:**
```http
POST /api/payment/initiate HTTP/1.1
Host: localhost:5000
Content-Type: application/json
Cookie: session=...

{
  "order_id": "order_1704873600_user@example.com",
  "amount": 2999.99,
  "payment_method": "online"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Payment session initiated",
  "session_id": "pay_order_1704873600_user@example.com_1704873600",
  "payment_url": "/payment/pay_order_1704873600_user@example.com_1704873600",
  "amount": 2999.99,
  "order_id": "order_1704873600_user@example.com"
}
```

**Error Responses:**
```json
// 404 Order not found
{
  "detail": "Order not found"
}

// 403 Access denied (order belongs to different user)
{
  "detail": "Access denied"
}

// 500 Internal error
{
  "detail": "Failed to initiate payment"
}
```

### 6. Get Payment Status

**Request:**
```http
GET /api/payment/status/pay_order_1704873600_user@example.com_1704873600 HTTP/1.1
Host: localhost:5000
Content-Type: application/json
Cookie: session=...
```

**Response (200 OK):**
```json
{
  "success": true,
  "session": {
    "session_id": "pay_order_1704873600_user@example.com_1704873600",
    "order_id": "order_1704873600_user@example.com",
    "user_id": "user@example.com",
    "amount": 2999.99,
    "currency": "INR",
    "status": "initiated",
    "payment_method": "online",
    "created_at": "2026-01-07T12:00:00"
  }
}
```

**Error Responses:**
```json
// 404 Session not found or expired
{
  "detail": "Payment session not found"
}

// 403 Access denied
{
  "detail": "Access denied"
}
```

### 7. Confirm Payment (Webhook)

**Request - Success:**
```http
POST /api/payment/confirm HTTP/1.1
Host: localhost:5000
Content-Type: application/json

{
  "session_id": "pay_order_1704873600_user@example.com_1704873600",
  "transaction_id": "TXN1704873620",
  "status": "success"
}
```

**Request - Failed:**
```http
POST /api/payment/confirm HTTP/1.1
Host: localhost:5000
Content-Type: application/json

{
  "session_id": "pay_order_1704873600_user@example.com_1704873600",
  "transaction_id": "TXN1704873620",
  "status": "failed"
}
```

**Response (200 OK) - Success:**
```json
{
  "success": true,
  "message": "Payment success",
  "order_id": "order_1704873600_user@example.com"
}
```

**Response (200 OK) - Failed:**
```json
{
  "success": true,
  "message": "Payment failed",
  "order_id": "order_1704873600_user@example.com"
}
```

**Error Responses:**
```json
// 400 Missing fields
{
  "detail": "Missing required fields"
}

// 404 Session not found
{
  "detail": "Payment session not found"
}
```

## Order Management API (Related)

### 8. Create Order

**Request:**
```http
POST /api/orders/create HTTP/1.1
Host: localhost:5000
Content-Type: application/json
Cookie: session=...

{
  "phone": "9876543210",
  "address": "123 Main Street, Mumbai, Maharashtra 400001, India",
  "items": [
    {
      "product_id": "prod_123",
      "seller_id": "seller_1",
      "seller_name": "Shoppers Seller",
      "product_name": "Sample Product",
      "price": 999.99,
      "quantity": 2,
      "image": "https://example.com/image.jpg",
      "category": "Electronics"
    }
  ],
  "payment_method": "cod"
}
```

**Response (200 OK):**
```json
{
  "success": true,
  "message": "Order placed successfully",
  "order": {
    "order_id": "order_1704873600_user@example.com",
    "user_id": "user@example.com",
    "user_name": "John Doe",
    "user_email": "user@example.com",
    "phone": "9876543210",
    "address": "123 Main Street, Mumbai, Maharashtra 400001, India",
    "items": [
      {
        "product_id": "prod_123",
        "seller_id": "seller_1",
        "seller_name": "Shoppers Seller",
        "product_name": "Sample Product",
        "price": 999.99,
        "quantity": 2,
        "image": "https://example.com/image.jpg",
        "category": "Electronics"
      }
    ],
    "total_amount": 1999.98,
    "order_date": "2026-01-07T12:00:00",
    "status": "pending",
    "payment_method": "cod",
    "payment_status": "cod"
  }
}
```

### 9. Get User Orders

**Request:**
```http
GET /api/orders/user HTTP/1.1
Host: localhost:5000
Content-Type: application/json
Cookie: session=...
```

**Response (200 OK):**
```json
{
  "success": true,
  "orders": [
    {
      "order_id": "order_1704873600_user@example.com",
      "user_id": "user@example.com",
      "total_amount": 1999.98,
      "order_date": "2026-01-07T12:00:00",
      "status": "pending",
      "payment_method": "cod",
      "items": [...]
    }
  ]
}
```

### 10. Get Order Details

**Request:**
```http
GET /api/orders/order_1704873600_user@example.com HTTP/1.1
Host: localhost:5000
Content-Type: application/json
Cookie: session=...
```

**Response (200 OK):**
```json
{
  "success": true,
  "order": {
    "order_id": "order_1704873600_user@example.com",
    "user_id": "user@example.com",
    "user_name": "John Doe",
    "user_email": "user@example.com",
    "phone": "9876543210",
    "address": "123 Main Street, Mumbai, Maharashtra 400001, India",
    "items": [...],
    "total_amount": 1999.98,
    "order_date": "2026-01-07T12:00:00",
    "status": "pending",
    "payment_method": "cod",
    "payment_status": "cod"
  }
}
```

## Testing Scenarios

### Scenario 1: Complete COD Order Flow

```
Step 1: Add Address
  POST /api/user/addresses
  Response: address_id = "addr_1_..."

Step 2: Create Order (COD)
  POST /api/orders/create
  ├─ phone: "9876543210"
  ├─ address: "..."
  ├─ payment_method: "cod"
  Response: order_id = "order_..."

Step 3: Verify Order
  GET /api/orders/{order_id}
  Response: order with status "pending"

Step 4: Get User Orders
  GET /api/orders/user
  Response: list includes new order
```

### Scenario 2: Complete Online Payment Flow

```
Step 1: Add Address (or get existing)
  GET /api/user/addresses
  Response: list of addresses

Step 2: Create Order (Online)
  POST /api/orders/create
  ├─ payment_method: "online"
  Response: order with status "pending", payment_status "initiated"

Step 3: Initiate Payment
  POST /api/payment/initiate
  ├─ order_id: "..."
  ├─ amount: 1999.98
  Response: session_id = "pay_..."

Step 4: Get Payment Status
  GET /api/payment/status/{session_id}
  Response: session with status "initiated"

Step 5: Confirm Payment (Success)
  POST /api/payment/confirm
  ├─ session_id: "..."
  ├─ transaction_id: "TXN..."
  ├─ status: "success"
  Response: order_id confirmed

Step 6: Verify Order Updated
  GET /api/orders/{order_id}
  Response: order with status "confirmed", payment_status "completed"
```

### Scenario 3: Payment Failure & Retry

```
Step 1-5: Same as Scenario 2 (steps 1-5)

Step 5: Confirm Payment (Failed)
  POST /api/payment/confirm
  ├─ status: "failed"
  Response: confirmation

Step 6: Order Still Pending
  GET /api/orders/{order_id}
  Response: status "pending" (not confirmed)

Step 7: Retry Payment
  POST /api/payment/initiate (again)
  Response: new session_id

Step 8: Confirm Payment (Success)
  POST /api/payment/confirm
  ├─ new session_id
  ├─ status: "success"
  Response: confirmed

Step 9: Order Now Confirmed
  GET /api/orders/{order_id}
  Response: status "confirmed"
```

## cURL Examples

### Add Address
```bash
curl -X POST http://localhost:5000/api/user/addresses \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -c cookies.txt \
  -d '{
    "label": "Home",
    "phone": "9876543210",
    "street": "123 Main Street",
    "city": "Mumbai",
    "state": "Maharashtra",
    "postal_code": "400001",
    "country": "India",
    "is_default": true
  }'
```

### Get Addresses
```bash
curl -X GET http://localhost:5000/api/user/addresses \
  -H "Content-Type: application/json" \
  -b cookies.txt
```

### Initiate Payment
```bash
curl -X POST http://localhost:5000/api/payment/initiate \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d '{
    "order_id": "order_1704873600_user@example.com",
    "amount": 2999.99,
    "payment_method": "online"
  }'
```

### Confirm Payment
```bash
curl -X POST http://localhost:5000/api/payment/confirm \
  -H "Content-Type: application/json" \
  -d '{
    "session_id": "pay_order_1704873600_user@example.com_1704873600",
    "transaction_id": "TXN1704873620",
    "status": "success"
  }'
```

## Response Headers

All endpoints return:
```
Content-Type: application/json
Content-Length: ...
Date: Wed, 07 Jan 2026 12:00:00 GMT
Connection: keep-alive
```

## Status Codes

- **200 OK** - Request successful
- **400 Bad Request** - Validation error
- **404 Not Found** - Resource not found
- **403 Forbidden** - Access denied
- **500 Internal Server Error** - Server error

## Best Practices

1. **Always authenticate** before making requests
2. **Include cookies** in all requests requiring authentication
3. **Validate input** before sending to API
4. **Handle errors** properly in frontend
5. **Test demo mode** before production integration
6. **Save session_id** for payment status checks
7. **Log transaction_id** for audit trail
8. **Set proper TTLs** on payment sessions
9. **Implement retry logic** for failed payments
10. **Monitor API response times**
