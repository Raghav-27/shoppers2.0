// Authentication utilities for session management

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

// Check if user has a valid session (using HTTP-only cookies)
export const checkSession = async () => {
  try {
    const response = await fetch(`${API_URL}/api/validate-session`, {
      method: 'GET',
      credentials: 'include', // Include cookies
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (response.ok) {
      const result = await response.json();
      if (result.valid) {
        // Transform backend field names to frontend field names
        const transformedUser = {
          firstName: result.user.first_name,
          lastName: result.user.last_name,
          email: result.user.email,
          phone: result.user.phone,
          country: result.user.country
        };
        
        return {
          isValid: true,
          user: transformedUser
        };
      }
    }
    
    return { isValid: false };
  } catch (error) {
    console.error('Session check failed:', error);
    return { isValid: false };
  }
};

// Logout user and clear session
export const logout = async () => {
  try {
    const response = await fetch(`${API_URL}/api/logout`, {
      method: 'POST',
      credentials: 'include', // Include cookies
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (response.ok) {
      return { success: true };
    } else {
      const result = await response.json();
      return { success: false, error: result.error };
    }
  } catch (error) {
    console.error('Logout failed:', error);
    return { success: false, error: 'Network error' };
  }
};

// Check if user is authenticated (for components that need quick check)
export const isAuthenticated = async () => {
  const session = await checkSession();
  return session.isValid;
};