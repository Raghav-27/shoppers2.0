const SELLER_API_URL = process.env.REACT_APP_SELLER_API_URL || 'http://localhost:5001';

export default SELLER_API_URL;
