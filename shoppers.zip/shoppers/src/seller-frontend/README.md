# Seller Frontend

React application for sellers to manage their products and business.

## Components

- **SellerRegister.js** - Seller registration page
- **SellerLogin.js** - Seller login page
- **SellerDashboard.js** - Main dashboard with stats and recent products
- **AddProduct.js** - Add new product form
- **ManageProducts.js** - View, edit, and delete products
- **SellerProfile.js** - View seller profile

## Setup

1. Install dependencies in your main React app:
```bash
npm install react-router-dom
```

2. Import these components in your main App.js and set up routes:

```javascript
import SellerRegister from './seller-frontend/components/SellerRegister';
import SellerLogin from './seller-frontend/components/SellerLogin';
import SellerDashboard from './seller-frontend/components/SellerDashboard';
import AddProduct from './seller-frontend/components/AddProduct';
import ManageProducts from './seller-frontend/components/ManageProducts';
import SellerProfile from './seller-frontend/components/SellerProfile';

// Add routes
<Route path="/seller/register" element={<SellerRegister />} />
<Route path="/seller/login" element={<SellerLogin />} />
<Route path="/seller/dashboard" element={<SellerDashboard />} />
<Route path="/seller/add-product" element={<AddProduct />} />
<Route path="/seller/products" element={<ManageProducts />} />
<Route path="/seller/profile" element={<SellerProfile />} />
```

3. Make sure the seller backend is running on port 5001

## Features

- ✅ Seller registration and authentication
- ✅ Dashboard with product statistics
- ✅ Add new products with images
- ✅ Edit and delete existing products
- ✅ View seller profile
- ✅ Responsive design

## API Integration

All components connect to the seller backend API at `http://localhost:5001/api/seller/*`

Make sure CORS is properly configured in the backend.
