// Example App.js integration for seller routes

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Import your existing components
// import YourExistingComponents...

// Import seller components
import SellerRegister from './seller-frontend/components/SellerRegister';
import SellerLogin from './seller-frontend/components/SellerLogin';
import SellerDashboard from './seller-frontend/components/SellerDashboard';
import AddProduct from './seller-frontend/components/AddProduct';
import ManageProducts from './seller-frontend/components/ManageProducts';
import SellerProfile from './seller-frontend/components/SellerProfile';
import ManageStores from './seller-frontend/components/ManageStores';
import StoreDetails from './seller-frontend/components/StoreDetails';

function App() {
  return (
    <Router>
      <Routes>
        {/* Your existing routes */}
        
        {/* Seller routes */}
        <Route path="/seller/register" element={<SellerRegister />} />
        <Route path="/seller/login" element={<SellerLogin />} />
        <Route path="/seller/dashboard" element={<SellerDashboard />} />
        <Route path="/seller/stores" element={<ManageStores />} />
        <Route path="/seller/stores/:storeId" element={<StoreDetails />} />
        <Route path="/seller/add-product" element={<AddProduct />} />
        <Route path="/seller/products" element={<ManageProducts />} />
        <Route path="/seller/profile" element={<SellerProfile />} />
      </Routes>
    </Router>
  );
}

export default App;

