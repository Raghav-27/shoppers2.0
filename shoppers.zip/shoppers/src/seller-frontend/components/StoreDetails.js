import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './StoreDetails.css';
import SELLER_API_URL from '../config';

const StoreDetails = () => {
  const { storeId } = useParams();
  const navigate = useNavigate();
  const [store, setStore] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchStoreDetails = useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetch(`${SELLER_API_URL}/api/seller/stores/${storeId}`, {
        credentials: 'include'
      });

      if (!response.ok) {
        if (response.status === 401) {
          navigate('/seller/login');
          return;
        }
        throw new Error('Failed to fetch store details');
      }

      const data = await response.json();
      setStore(data.store);
    } catch (error) {
      console.error('Error fetching store:', error);
      setError('Failed to load store details');
    } finally {
      setLoading(false);
    }
  }, [storeId, navigate]);

  useEffect(() => {
    fetchStoreDetails();
  }, [storeId, fetchStoreDetails]);

  if (loading) {
    return (
      <div className="store-details-container">
        <div className="loading">Loading store details...</div>
      </div>
    );
  }

  if (error || !store) {
    return (
      <div className="store-details-container">
        <div className="error-message">{error || 'Store not found'}</div>
        <button className="back-btn" onClick={() => navigate('/seller/stores')}>
          ← Back to Stores
        </button>
      </div>
    );
  }

  return (
    <div className="store-details-container">
      <div className="store-details-header">
        <button className="back-btn" onClick={() => navigate('/seller/stores')}>
          ← Back to Stores
        </button>
        <button className="edit-store-btn" onClick={() => navigate('/seller/stores')}>
          Edit Store
        </button>
      </div>

      <div className="store-header-section">
        <div className="store-image-large">
          {store.image_url ? (
            <img src={store.image_url} alt={store.name} />
          ) : (
            <div className="no-image-large">No Image</div>
          )}
        </div>
        
        <div className="store-header-info">
          <h1>{store.name}</h1>
          <p className="store-description-full">{store.description || 'No description'}</p>
          
          <div className="store-contact-info">
            {store.address && (
              <div className="contact-item">
                <span className="icon">📍</span>
                <span>{store.address}</span>
              </div>
            )}
            {store.phone && (
              <div className="contact-item">
                <span className="icon">📞</span>
                <span>{store.phone}</span>
              </div>
            )}
            {store.email && (
              <div className="contact-item">
                <span className="icon">✉️</span>
                <span>{store.email}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="store-products-section">
        <div className="section-header">
          <h2>Products in this Store ({store.products?.length || 0})</h2>
          <button 
            className="add-product-btn"
            onClick={() => navigate(`/seller/add-product?store=${storeId}`)}
          >
            + Add Product to Store
          </button>
        </div>

        {(!store.products || store.products.length === 0) ? (
          <div className="no-products">
            <p>No products in this store yet.</p>
            <button 
              className="add-first-product-btn"
              onClick={() => navigate(`/seller/add-product?store=${storeId}`)}
            >
              Add Your First Product
            </button>
          </div>
        ) : (
          <div className="products-grid">
            {store.products.map(product => (
              <div key={product.id} className="product-card">
                <div className="product-image">
                  {product.image_url ? (
                    <img src={product.image_url} alt={product.name} />
                  ) : (
                    <div className="no-product-image">No Image</div>
                  )}
                </div>
                
                <div className="product-info">
                  <h3>{product.name}</h3>
                  <p className="product-description">
                    {product.description?.substring(0, 100)}
                    {product.description?.length > 100 ? '...' : ''}
                  </p>
                  <div className="product-price">₹{product.price}</div>
                  <div className="product-meta">
                    <span className="category">{product.category}</span>
                    <span className="stock">Stock: {product.stock}</span>
                  </div>
                </div>
                
                <div className="product-actions">
                  <button 
                    className="edit-product-btn"
                    onClick={() => navigate(`/seller/manage-products?edit=${product.id}`)}
                  >
                    Edit
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default StoreDetails;
