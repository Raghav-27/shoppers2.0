import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './SellerAuth.css';
import SELLER_API_URL from '../config';

const SellerRegister = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    business_name: '',
    contact_person: '',
    phone: '',
    address: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Validate passwords match
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);

    try {
      console.log('Attempting registration to:', `${SELLER_API_URL}/api/seller/register`);
      console.log('Registration data:', {
        email: formData.email,
        business_name: formData.business_name
      });

      const response = await fetch(`${SELLER_API_URL}/api/seller/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({
          email: formData.email,
          password: formData.password,
          business_name: formData.business_name,
          contact_person: formData.contact_person,
          phone: formData.phone,
          address: formData.address
        })
      });

      const data = await response.json();
      console.log('Registration response:', data);

      if (response.ok) {
        // Store seller info in localStorage
        localStorage.setItem('seller', JSON.stringify(data.seller));
        console.log('Registration successful, redirecting to dashboard');
        alert(`Registration successful! Welcome ${formData.business_name}!\n\nYou can now login with:\nEmail: ${formData.email}`);
        navigate('/seller/login');
      } else {
        setError(data.error || 'Registration failed');
        console.error('Registration failed:', data.error);
      }
    } catch (err) {
      console.error('Registration error:', err);
      setError(`Failed to connect to server: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="seller-auth-container">
      <div className="seller-auth-card">
        <div className="seller-auth-header">
          <h1>Seller Registration</h1>
          <p>Start selling your products today</p>
        </div>

        {error && (
          <div className="error-message">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="seller-auth-form">
          <div className="form-group">
            <label htmlFor="email">Email *</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              disabled={loading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="business_name">Business Name *</label>
            <input
              type="text"
              id="business_name"
              name="business_name"
              value={formData.business_name}
              onChange={handleChange}
              required
              disabled={loading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="contact_person">Contact Person</label>
            <input
              type="text"
              id="contact_person"
              name="contact_person"
              value={formData.contact_person}
              onChange={handleChange}
              disabled={loading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="phone">Phone</label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              disabled={loading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="address">Address</label>
            <textarea
              id="address"
              name="address"
              value={formData.address}
              onChange={handleChange}
              rows="3"
              disabled={loading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password *</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
              disabled={loading}
            />
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">Confirm Password *</label>
            <input
              type="password"
              id="confirmPassword"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              required
              disabled={loading}
            />
          </div>

          <button type="submit" className="seller-auth-btn" disabled={loading}>
            {loading ? 'Registering...' : 'Register'}
          </button>
        </form>

        <div className="seller-auth-footer">
          <p>
            Already have an account?{' '}
            <Link to="/seller/login">Login here</Link>
          </p>
        </div>

        <div className="debug-info" style={{ marginTop: '20px', padding: '10px', background: '#f5f5f5', fontSize: '12px' }}>
          <strong>Debug Info:</strong><br />
          API URL: {SELLER_API_URL}<br />
          Register Endpoint: {SELLER_API_URL}/api/seller/register
        </div>
      </div>
    </div>
  );
};

export default SellerRegister;
