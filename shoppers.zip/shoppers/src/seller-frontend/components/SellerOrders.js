import React, { useState, useEffect } from 'react';
import './SellerOrders.css';

const SellerOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sellerId, setSellerId] = useState('');

  useEffect(() => {
    // Get seller ID from localStorage
    const sellerData = JSON.parse(localStorage.getItem('seller') || '{}');
    if (sellerData.id) {
      setSellerId(sellerData.id);
      fetchOrders(sellerData.id);
    } else {
      setLoading(false);
    }
  }, []);

  const fetchOrders = async (seller_id) => {
    try {
      const response = await fetch(`http://localhost:5001/api/seller/orders`, {
        credentials: 'include'
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setOrders(data.orders || []);
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateOrderStatus = async (orderId, newSellerStatus) => {
    try {
      const response = await fetch(`http://localhost:5001/api/seller/orders/${orderId}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          seller_status: newSellerStatus
        })
      });

      const data = await response.json();

      if (response.ok && data.success) {
        alert('Order status updated to: ' + newSellerStatus);
        fetchOrders(sellerId);
      } else {
        alert(data.error || 'Failed to update status');
      }
    } catch (error) {
      console.error('Error updating status:', error);
      alert('Failed to update status');
    }
  };

  const getStatusBadgeClass = (status) => {
    switch (status?.toLowerCase()) {
      case 'pending':
        return 'status-pending';
      case 'confirmed':
        return 'status-confirmed';
      case 'processing':
        return 'status-processing';
      case 'shipped':
        return 'status-shipped';
      case 'delivered':
        return 'status-delivered';
      case 'cancelled':
        return 'status-cancelled';
      default:
        return 'status-pending';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!sellerId) {
    return (
      <div className="seller-orders-page">
        <div className="seller-orders-container">
          <p>Please login as a seller to view orders.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="seller-orders-page">
      <div className="seller-orders-container">
        <h1>My Orders</h1>

        {loading ? (
          <div className="loading-state">
            <p>Loading orders...</p>
          </div>
        ) : orders.length === 0 ? (
          <div className="empty-orders">
            <p>No orders yet</p>
          </div>
        ) : (
          <div className="orders-list">
            {orders.map((order) => (
              <div key={order.order_id} className="order-card">
                <div className="order-header">
                  <div className="order-info">
                    <h3>Order #{order.order_id.substring(0, 20)}...</h3>
                    <p className="order-date">{formatDate(order.order_date)}</p>
                    <div className="status-info">
                      <p><strong>Seller Status:</strong> {order.seller_status}</p>
                      <p><strong>Buyer Status:</strong> {order.buyer_status}</p>
                      {order.delivery_status && <p><strong>Delivery:</strong> {order.delivery_status}</p>}
                    </div>
                  </div>
                  <span className={`status-badge ${getStatusBadgeClass(order.seller_status)}`}>
                    {order.seller_status}
                  </span>
                </div>

                <div className="order-items">
                  {order.items?.map((item, index) => (
                    <div key={index} className="order-item">
                      <img 
                        src={item.image || '/placeholder-image.svg'} 
                        alt={item.product_name}
                        onError={(e) => e.target.src = '/placeholder-image.svg'}
                      />
                      <div className="item-info">
                        <h4>{item.product_name}</h4>
                        <p>Category: {item.category}</p>
                        <p>Quantity: {item.quantity}</p>
                        <p>Price: ₹{parseFloat(item.price).toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="order-actions">
                  <button 
                    onClick={() => updateOrderStatus(order.order_id, 'confirmed')}
                    disabled={order.seller_status === 'confirmed' || order.seller_status === 'processing' || order.seller_status === 'shipped' || order.seller_status === 'delivered'}
                    className="btn-status"
                  >
                    ✓ Confirm
                  </button>
                  <button 
                    onClick={() => updateOrderStatus(order.order_id, 'processing')}
                    disabled={order.seller_status === 'processing' || order.seller_status === 'shipped' || order.seller_status === 'delivered'}
                    className="btn-status"
                  >
                    ⚙ Processing
                  </button>
                  <button 
                    onClick={() => updateOrderStatus(order.order_id, 'shipped')}
                    disabled={order.seller_status === 'shipped' || order.seller_status === 'delivered'}
                    className="btn-status"
                  >
                    📦 Ship
                  </button>
                  <button 
                    onClick={() => updateOrderStatus(order.order_id, 'delivered')}
                    disabled={order.seller_status === 'delivered'}
                    className="btn-status btn-primary"
                  >
                    🎉 Delivered
                  </button>
                </div>

                <div className="order-footer">
                  <div className="customer-info">
                    <h4>Customer Details</h4>
                    <p><strong>Name:</strong> {order.user_name}</p>
                    <p><strong>Email:</strong> {order.user_email}</p>
                    <p><strong>Phone:</strong> {order.phone}</p>
                    <p><strong>Address:</strong> {order.address}</p>
                    <p><strong>Payment:</strong> {order.payment_method?.toUpperCase()}</p>
                  </div>
                  
                  <div className="order-total">
                    <h3>Your Total: ₹{parseFloat(order.seller_total).toFixed(2)}</h3>
                  </div>
                </div>

                {order.buyer_status === 'completed' && (
                  <div className="order-completion">
                    <p className="completion-message">✓ Buyer has confirmed delivery</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default SellerOrders;
