import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import './ManageProducts.css';
import SELLER_API_URL from '../config';

const ManageProducts = () => {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingProduct, setEditingProduct] = useState(null);
  const [formData, setFormData] = useState({});

  const fetchProducts = useCallback(async () => {
    try {
      const response = await fetch(`${SELLER_API_URL}/api/seller/products`, {
        credentials: 'include'
      });

      if (!response.ok) {
        if (response.status === 401) {
          navigate('/seller/login');
          return;
        }
        throw new Error('Failed to fetch products');
      }

      const data = await response.json();
      console.log('Fetched products:', data); // Debug log
      setProducts(data.products || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      setProducts([]);
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  const handleEdit = (product) => {
    setEditingProduct(product.id);
    setFormData(product);
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleUpdate = async (productId) => {
    try {
      const response = await fetch(`${SELLER_API_URL}/api/seller/products/${productId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({
          name: formData.name,
          description: formData.description,
          price: parseFloat(formData.price),
          category: formData.category,
          image_url: formData.image_url,
          stock: parseInt(formData.stock) || 0,
          store_id: formData.store_id
        })
      });

      if (!response.ok) {
        throw new Error('Failed to update product');
      }

      setEditingProduct(null);
      fetchProducts();
    } catch (error) {
      console.error('Error updating product:', error);
      alert('Failed to update product');
    }
  };

  const handleDelete = async (productId) => {
    if (!window.confirm('Are you sure you want to delete this product?')) {
      return;
    }

    try {
      const response = await fetch(`${SELLER_API_URL}/api/seller/products/${productId}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error('Failed to delete product');
      }

      fetchProducts();
    } catch (error) {
      console.error('Error deleting product:', error);
      alert('Failed to delete product');
    }
  };

  if (loading) {
    return <div className="loading">Loading products...</div>;
  }

  return (
    <div className="manage-products-page">
      <div className="manage-header">
        <button onClick={() => navigate('/seller/dashboard')} className="back-btn">
          ← Back to Dashboard
        </button>
        <h1>Manage Products</h1>
        <button onClick={() => navigate('/seller/add-product')} className="add-new-btn">
          + Add New Product
        </button>
      </div>

      <div className="manage-container">
        {products.length === 0 ? (
          <div className="empty-state">
            <p>No products found</p>
            <button onClick={() => navigate('/seller/add-product')} className="add-first-btn">
              Add Your First Product
            </button>
          </div>
        ) : (
          <div className="products-table">
            <table>
              <thead>
                <tr>
                  <th>Image</th>
                  <th>Name</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Stock</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {products.map(product => (
                  <tr key={product.id}>
                    <td>
                      <div className="table-image">
                        {product.image_url ? (
                          <img src={product.image_url} alt={product.name} />
                        ) : (
                          <div className="placeholder">📦</div>
                        )}
                      </div>
                    </td>
                    <td>
                      {editingProduct === product.id ? (
                        <input
                          type="text"
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          className="edit-input"
                        />
                      ) : (
                        <div>
                          <strong>{product.name}</strong>
                          {product.description && (
                            <p className="description">{product.description.substring(0, 50)}...</p>
                          )}
                        </div>
                      )}
                    </td>
                    <td>
                      {editingProduct === product.id ? (
                        <input
                          type="text"
                          name="category"
                          value={formData.category}
                          onChange={handleChange}
                          className="edit-input"
                        />
                      ) : (
                        product.category || 'N/A'
                      )}
                    </td>
                    <td>
                      {editingProduct === product.id ? (
                        <input
                          type="number"
                          name="price"
                          value={formData.price}
                          onChange={handleChange}
                          step="0.01"
                          className="edit-input"
                        />
                      ) : (
                        `$${product.price}`
                      )}
                    </td>
                    <td>
                      {editingProduct === product.id ? (
                        <input
                          type="number"
                          name="stock"
                          value={formData.stock}
                          onChange={handleChange}
                          className="edit-input"
                        />
                      ) : (
                        product.stock || 0
                      )}
                    </td>
                    <td>
                      <span className={`status-badge ${product.is_active === '1' ? 'active' : 'inactive'}`}>
                        {product.is_active === '1' ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td>
                      <div className="action-buttons">
                        {editingProduct === product.id ? (
                          <>
                            <button onClick={() => handleUpdate(product.id)} className="save-btn">
                              Save
                            </button>
                            <button onClick={() => setEditingProduct(null)} className="cancel-btn-small">
                              Cancel
                            </button>
                          </>
                        ) : (
                          <>
                            <button onClick={() => handleEdit(product)} className="edit-btn">
                              Edit
                            </button>
                            <button onClick={() => handleDelete(product.id)} className="delete-btn">
                              Delete
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default ManageProducts;
