import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './SellerAuth.css';
import SELLER_API_URL from '../config';

const SellerLogin = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    setError(''); // Clear error on input change
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      console.log('Attempting login to:', `${SELLER_API_URL}/api/seller/login`);
      console.log('Login data:', { email: formData.email });

      const response = await fetch(`${SELLER_API_URL}/api/seller/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({
          email: formData.email,
          password: formData.password
        })
      });

      const data = await response.json();
      console.log('Login response:', data);

      if (response.ok) {
        // Store seller info in localStorage
        localStorage.setItem('seller', JSON.stringify(data.seller));
        console.log('Login successful, redirecting to dashboard');
        navigate('/seller/dashboard');
      } else {
        setError(data.error || 'Login failed');
        console.error('Login failed:', data.error);
      }
    } catch (err) {
      console.error('Login error:', err);
      setError(`Failed to connect to server: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="seller-auth-container">
      <div className="seller-auth-card">
        <div className="seller-auth-header">
          <h1>Seller Login</h1>
          <p>Access your seller dashboard</p>
        </div>

        {error && (
          <div className="error-message">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="seller-auth-form">
          <div className="form-group">
            <label htmlFor="email">Email *</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              disabled={loading}
              placeholder="your@email.com"
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password *</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
              disabled={loading}
              placeholder="Enter your password"
            />
          </div>

          <button type="submit" className="seller-auth-btn" disabled={loading}>
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>

        <div className="seller-auth-footer">
          <p>
            Don't have an account?{' '}
            <Link to="/seller/register">Register here</Link>
          </p>
        </div>

        <div className="debug-info" style={{ marginTop: '20px', padding: '10px', background: '#f5f5f5', fontSize: '12px' }}>
          <strong>Debug Info:</strong><br />
          API URL: {SELLER_API_URL}<br />
          Login Endpoint: {SELLER_API_URL}/api/seller/login
        </div>
      </div>
    </div>
  );
};

export default SellerLogin;
