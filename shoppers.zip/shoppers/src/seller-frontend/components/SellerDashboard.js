import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import './SellerDashboard.css';
import SELLER_API_URL from '../config';

const SellerDashboard = () => {
  const navigate = useNavigate();
  const [seller, setSeller] = useState(null);
  const [products, setProducts] = useState([]);
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalProducts: 0,
    activeProducts: 0,
    totalValue: 0,
    totalStores: 0
  });

  const fetchSellerProfile = useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetch(`${SELLER_API_URL}/api/seller/profile`, {
        credentials: 'include'
      });

      if (!response.ok) {
        navigate('/seller/login');
        return;
      }

      const data = await response.json();
      setSeller(data);
    } catch (error) {
      console.error('Error fetching profile:', error);
      navigate('/seller/login');
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  const fetchProducts = useCallback(async () => {
    try {
      const response = await fetch(`${SELLER_API_URL}/api/seller/products`, {
        credentials: 'include'
      });

      if (!response.ok) {
        navigate('/seller/login');
        return;
      }

      const data = await response.json();
      setProducts(data.products || []);

      // Calculate stats
      const totalProducts = data.products?.length || 0;
      const activeProducts = data.products?.filter(p => p.is_active === '1').length || 0;
      const totalValue = data.products?.reduce((sum, p) => sum + (parseFloat(p.price) * parseInt(p.stock || 0)), 0) || 0;

      setStats(prev => ({
        ...prev,
        totalProducts,
        activeProducts,
        totalValue
      }));
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  }, [navigate]);

  const fetchStores = useCallback(async () => {
    try {
      const response = await fetch(`${SELLER_API_URL}/api/seller/stores`, {
        credentials: 'include'
      });

      if (!response.ok) {
        navigate('/seller/login');
        return;
      }

      const data = await response.json();
      setStores(data.stores || []);

      setStats(prev => ({
        ...prev,
        totalStores: data.stores?.length || 0
      }));
    } catch (error) {
      console.error('Error fetching stores:', error);
    }
  }, [navigate]);

  useEffect(() => {
    fetchSellerProfile();
    fetchProducts();
    fetchStores();
  }, [fetchSellerProfile, fetchProducts, fetchStores]);

  const handleLogout = async () => {
    try {
      await fetch(`${SELLER_API_URL}/api/seller/logout`, {
        method: 'POST',
        credentials: 'include'
      });
      navigate('/seller/login');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  if (loading) {
    return (
      <div className="seller-dashboard">
        <div className="loading">Loading...</div>
      </div>
    );
  }

  return (
    <div className="seller-dashboard">
      {/* Header */}
      <header className="seller-header">
        <div className="header-content">
          <h1>Seller Dashboard</h1>
          <div className="header-actions">
            <span className="seller-name">{seller?.business_name}</span>
            <button onClick={handleLogout} className="logout-btn">Logout</button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="seller-nav">
        <button onClick={() => navigate('/seller/dashboard')} className="nav-btn active">
          Dashboard
        </button>
        <button onClick={() => navigate('/seller/orders')} className="nav-btn">
          Orders
        </button>
        <button onClick={() => navigate('/seller/stores')} className="nav-btn">
          My Stores
        </button>
        <button onClick={() => navigate('/seller/manage-products')} className="nav-btn">
          My Products
        </button>
        <button onClick={() => navigate('/seller/add-product')} className="nav-btn">
          Add Product
        </button>
        <button onClick={() => navigate('/seller/profile')} className="nav-btn">
          Profile
        </button>
      </nav>

      {/* Stats Cards */}
      <div className="dashboard-content">
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-icon">🏪</div>
            <div className="stat-info">
              <h3>{stats.totalStores}</h3>
              <p>Total Stores</p>
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-icon">📦</div>
            <div className="stat-info">
              <h3>{stats.totalProducts}</h3>
              <p>Total Products</p>
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-icon">✅</div>
            <div className="stat-info">
              <h3>{stats.activeProducts}</h3>
              <p>Active Products</p>
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-icon">💰</div>
            <div className="stat-info">
              <h3>${stats.totalValue.toFixed(2)}</h3>
              <p>Total Inventory Value</p>
            </div>
          </div>
        </div>

        {/* Stores Section */}
        <div className="recent-stores">
          <div className="section-header">
            <h2>Your Stores</h2>
            <button onClick={() => navigate('/seller/stores')} className="view-all-btn">
              Manage Stores
            </button>
          </div>

          {stores.length === 0 ? (
            <div className="empty-state">
              <p>No stores yet</p>
              <button onClick={() => navigate('/seller/stores')} className="add-first-btn">
                Create Your First Store
              </button>
            </div>
          ) : (
            <div className="stores-preview">
              {stores.slice(0, 3).map(store => (
                <div key={store.id} className="store-preview-card" onClick={() => navigate(`/seller/stores/${store.id}`)}>
                  <div className="store-preview-image">
                    {store.image_url ? (
                      <img src={store.image_url} alt={store.name} />
                    ) : (
                      <div className="placeholder-store-image">🏪</div>
                    )}
                  </div>
                  <div className="store-preview-info">
                    <h4>{store.name}</h4>
                    <p className="store-products-count">{store.product_count || 0} products</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Products */}
        <div className="recent-products">
          <div className="section-header">
            <h2>Recent Products</h2>
            <button onClick={() => navigate('/seller/manage-products')} className="view-all-btn">
              View All
            </button>
          </div>

          {products.length === 0 ? (
            <div className="empty-state">
              <p>No products yet</p>
              <button onClick={() => navigate('/seller/add-product')} className="add-first-btn">
                Add Your First Product
              </button>
            </div>
          ) : (
            <div className="products-list">
              {products.slice(0, 5).map(product => (
                <div key={product.id} className="product-item">
                  <div className="product-image">
                    {product.image_url ? (
                      <img src={product.image_url} alt={product.name} />
                    ) : (
                      <div className="placeholder-image">📦</div>
                    )}
                  </div>
                  <div className="product-details">
                    <h4>{product.name}</h4>
                    <p className="product-category">{product.category || 'Uncategorized'}</p>
                  </div>
                  <div className="product-stats">
                    <span className="price">${product.price}</span>
                    <span className="stock">Stock: {product.stock || 0}</span>
                  </div>
                  <div className="product-status">
                    <span className={`status-badge ${product.is_active === '1' ? 'active' : 'inactive'}`}>
                      {product.is_active === '1' ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SellerDashboard;
