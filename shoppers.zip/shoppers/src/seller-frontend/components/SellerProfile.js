import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import './SellerProfile.css';
import SELLER_API_URL from '../config';

const SellerProfile = () => {
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = useCallback(async () => {
    try {
      const response = await fetch(`${SELLER_API_URL}/api/seller/profile`, {
        credentials: 'include'
      });

      if (!response.ok) {
        navigate('/seller/login');
        return;
      }

      const data = await response.json();
      setProfile(data);
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  if (loading) {
    return <div className="loading">Loading profile...</div>;
  }

  return (
    <div className="seller-profile-page">
      <div className="profile-header">
        <button onClick={() => navigate('/seller/dashboard')} className="back-btn">
          ← Back to Dashboard
        </button>
        <h1>Seller Profile</h1>
      </div>

      <div className="profile-container">
        <div className="profile-card">
          <div className="profile-icon">👤</div>
          
          <div className="profile-section">
            <h3>Business Information</h3>
            <div className="profile-field">
              <label>Business Name</label>
              <p>{profile?.business_name || 'N/A'}</p>
            </div>
            
            <div className="profile-field">
              <label>Email</label>
              <p>{profile?.email || 'N/A'}</p>
            </div>
          </div>

          <div className="profile-section">
            <h3>Contact Information</h3>
            <div className="profile-field">
              <label>Contact Person</label>
              <p>{profile?.contact_person || 'Not provided'}</p>
            </div>
            
            <div className="profile-field">
              <label>Phone</label>
              <p>{profile?.phone || 'Not provided'}</p>
            </div>
            
            <div className="profile-field">
              <label>Address</label>
              <p>{profile?.address || 'Not provided'}</p>
            </div>
          </div>

          <div className="profile-section">
            <h3>Account Details</h3>
            <div className="profile-field">
              <label>Member Since</label>
              <p>{profile?.created_at ? new Date(profile.created_at).toLocaleDateString() : 'N/A'}</p>
            </div>
          </div>

          <div className="profile-actions">
            <button className="edit-profile-btn" onClick={() => alert('Edit profile feature coming soon!')}>
              Edit Profile
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SellerProfile;
