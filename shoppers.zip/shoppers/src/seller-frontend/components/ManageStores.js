import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import './ManageStores.css';
import SELLER_API_URL from '../config';

const ManageStores = () => {
  const navigate = useNavigate();
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingStore, setEditingStore] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    image_url: '',
    address: '',
    phone: '',
    email: ''
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const fetchStores = useCallback(async () => {
    try {
      setLoading(true);
      const response = await fetch(`${SELLER_API_URL}/api/seller/stores`, {
        credentials: 'include'
      });

      if (!response.ok) {
        if (response.status === 401) {
          navigate('/seller/login');
          return;
        }
        throw new Error('Failed to fetch stores');
      }

      const data = await response.json();
      setStores(data.stores || []);
    } catch (error) {
      console.error('Error fetching stores:', error);
      setError('Failed to load stores');
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    fetchStores();
  }, [fetchStores]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    try {
      const url = editingStore
        ? `${SELLER_API_URL}/api/seller/stores/${editingStore.id}`
        : `${SELLER_API_URL}/api/seller/stores`;

      const method = editingStore ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to save store');
      }

      const data = await response.json();
      setSuccess(data.message);
      
      // Reset form
      setFormData({
        name: '',
        description: '',
        image_url: '',
        address: '',
        phone: '',
        email: ''
      });
      setShowForm(false);
      setEditingStore(null);
      
      // Refresh stores list
      fetchStores();
    } catch (error) {
      console.error('Error saving store:', error);
      setError(error.message);
    }
  };

  const handleEdit = (store) => {
    setEditingStore(store);
    setFormData({
      name: store.name || '',
      description: store.description || '',
      image_url: store.image_url || '',
      address: store.address || '',
      phone: store.phone || '',
      email: store.email || ''
    });
    setShowForm(true);
    setError('');
    setSuccess('');
  };

  const handleDelete = async (storeId) => {
    if (!window.confirm('Are you sure you want to delete this store?')) {
      return;
    }

    try {
      const response = await fetch(`${SELLER_API_URL}/api/seller/stores/${storeId}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error('Failed to delete store');
      }

      setSuccess('Store deleted successfully');
      fetchStores();
    } catch (error) {
      console.error('Error deleting store:', error);
      setError('Failed to delete store');
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingStore(null);
    setFormData({
      name: '',
      description: '',
      image_url: '',
      address: '',
      phone: '',
      email: ''
    });
    setError('');
    setSuccess('');
  };

  const viewStoreDetails = (storeId) => {
    navigate(`/seller/stores/${storeId}`);
  };

  if (loading) {
    return (
      <div className="manage-stores-container">
        <div className="loading">Loading stores...</div>
      </div>
    );
  }

  return (
    <div className="manage-stores-container">
      <div className="manage-stores-header">
        <h1>Manage Stores</h1>
        <button className="back-btn" onClick={() => navigate('/seller/dashboard')}>
          ← Back to Dashboard
        </button>
      </div>

      {error && <div className="error-message">{error}</div>}
      {success && <div className="success-message">{success}</div>}

      {!showForm ? (
        <>
          <div className="stores-actions">
            <button className="add-store-btn" onClick={() => setShowForm(true)}>
              + Add New Store
            </button>
          </div>

          <div className="stores-grid">
            {stores.length === 0 ? (
              <div className="no-stores">
                <p>You haven't created any stores yet.</p>
                <button className="create-first-store-btn" onClick={() => setShowForm(true)}>
                  Create Your First Store
                </button>
              </div>
            ) : (
              stores.map(store => (
                <div key={store.id} className="store-card">
                  <div className="store-image">
                    {store.image_url ? (
                      <img src={store.image_url} alt={store.name} />
                    ) : (
                      <div className="no-image">No Image</div>
                    )}
                  </div>
                  
                  <div className="store-info">
                    <h3>{store.name}</h3>
                    <p className="store-description">
                      {store.description || 'No description provided'}
                    </p>
                    
                    <div className="store-details">
                      {store.address && (
                        <div className="detail-item">
                          <span className="detail-label">📍</span>
                          <span>{store.address}</span>
                        </div>
                      )}
                      {store.phone && (
                        <div className="detail-item">
                          <span className="detail-label">📞</span>
                          <span>{store.phone}</span>
                        </div>
                      )}
                      {store.email && (
                        <div className="detail-item">
                          <span className="detail-label">✉️</span>
                          <span>{store.email}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="store-stats">
                      <span className="product-count">
                        {store.product_count || 0} products
                      </span>
                    </div>
                  </div>
                  
                  <div className="store-actions">
                    <button className="view-btn" onClick={() => viewStoreDetails(store.id)}>
                      View Details
                    </button>
                    <button className="edit-btn" onClick={() => handleEdit(store)}>
                      Edit
                    </button>
                    <button className="delete-btn" onClick={() => handleDelete(store.id)}>
                      Delete
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </>
      ) : (
        <div className="store-form-container">
          <h2>{editingStore ? 'Edit Store' : 'Create New Store'}</h2>
          
          <form onSubmit={handleSubmit} className="store-form">
            <div className="form-group">
              <label htmlFor="name">Store Name *</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required
                placeholder="Enter store name"
              />
            </div>

            <div className="form-group">
              <label htmlFor="description">Description</label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                rows="4"
                placeholder="Describe your store..."
              />
            </div>

            <div className="form-group">
              <label htmlFor="image_url">Store Image URL</label>
              <input
                type="url"
                id="image_url"
                name="image_url"
                value={formData.image_url}
                onChange={handleInputChange}
                placeholder="https://example.com/store-image.jpg"
              />
              {formData.image_url && (
                <div className="image-preview">
                  <img src={formData.image_url} alt="Store preview" />
                </div>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="address">Address</label>
              <input
                type="text"
                id="address"
                name="address"
                value={formData.address}
                onChange={handleInputChange}
                placeholder="Store address"
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="phone">Phone</label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  placeholder="Contact phone"
                />
              </div>

              <div className="form-group">
                <label htmlFor="email">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="store@example.com"
                />
              </div>
            </div>

            <div className="form-actions">
              <button type="submit" className="submit-btn">
                {editingStore ? 'Update Store' : 'Create Store'}
              </button>
              <button type="button" className="cancel-btn" onClick={handleCancel}>
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

export default ManageStores;
