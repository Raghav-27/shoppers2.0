import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../contexts/ThemeContext';
import './OrderHistory.css';

const OrderHistory = ({ isSignedIn }) => {
  const navigate = useNavigate();
  const { isDarkMode } = useTheme();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isSignedIn) {
      navigate('/signin');
      return;
    }

    fetchOrders();
  }, [isSignedIn, navigate]);

  const fetchOrders = async () => {
    try {
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const response = await fetch(`${apiUrl}/api/orders/user`, {
        credentials: 'include'
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setOrders(data.orders || []);
      }
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCancelOrder = async (orderId) => {
    if (!window.confirm('Are you sure you want to cancel this order?')) {
      return;
    }

    try {
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const response = await fetch(`${apiUrl}/api/orders/${orderId}/cancel`, {
        method: 'POST',
        credentials: 'include'
      });

      const data = await response.json();

      if (response.ok && data.success) {
        alert('Order cancelled successfully');
        fetchOrders();
      } else {
        alert(data.detail || 'Failed to cancel order');
      }
    } catch (error) {
      console.error('Error cancelling order:', error);
      alert('Failed to cancel order');
    }
  };

  const handleMarkCompleted = async (orderId) => {
    if (!window.confirm('Confirm that you have received this order?')) {
      return;
    }

    try {
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const response = await fetch(`${apiUrl}/api/orders/${orderId}/mark-completed`, {
        method: 'POST',
        credentials: 'include'
      });

      const data = await response.json();

      if (response.ok && data.success) {
        alert('Order marked as completed');
        fetchOrders();
      } else {
        alert(data.detail || 'Failed to mark order as completed');
      }
    } catch (error) {
      console.error('Error marking order as completed:', error);
      alert('Failed to mark order as completed');
    }
  };

  const getStatusBadgeClass = (status) => {
    switch (status?.toLowerCase()) {
      case 'pending':
        return 'status-pending';
      case 'confirmed':
        return 'status-confirmed';
      case 'processing':
        return 'status-processing';
      case 'shipped':
        return 'status-shipped';
      case 'delivered':
        return 'status-delivered';
      case 'completed':
        return 'status-completed';
      case 'cancelled':
        return 'status-cancelled';
      default:
        return 'status-pending';
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!isSignedIn) {
    return null;
  }

  return (
    <div className={`order-history-page ${isDarkMode ? 'dark' : ''}`}>
      <div className="order-history-container">
        <h1>My Orders</h1>

        {loading ? (
          <div className="loading-state">
            <p>Loading your orders...</p>
          </div>
        ) : orders.length === 0 ? (
          <div className="empty-orders">
            <p>No orders yet</p>
            <button onClick={() => navigate('/products')}>Start Shopping</button>
          </div>
        ) : (
          <div className="orders-list">
            {orders.map((order) => (
              <div key={order.order_id} className="order-card">
                <div className="order-header">
                  <div className="order-info">
                    <h3>Order #{order.order_id.substring(0, 20)}...</h3>
                    <p className="order-date">{formatDate(order.order_date)}</p>
                    <div className="status-info">
                      <p><strong>Status:</strong> {order.status}</p>
                      {order.seller_status && <p><strong>Seller Status:</strong> {order.seller_status}</p>}
                      {order.delivery_status && <p><strong>Delivery Status:</strong> {order.delivery_status}</p>}
                    </div>
                  </div>
                  <span className={`status-badge ${getStatusBadgeClass(order.seller_status || order.status)}`}>
                    {order.seller_status || order.status}
                  </span>
                </div>

                <div className="order-items">
                  {order.items?.map((item, index) => (
                    <div key={index} className="order-item">
                      <img 
                        src={item.image || '/placeholder-image.svg'} 
                        alt={item.product_name}
                        onError={(e) => e.target.src = '/placeholder-image.svg'}
                      />
                      <div className="item-info">
                        <h4>{item.product_name}</h4>
                        <p>Seller: {item.seller_name}</p>
                        <p>Quantity: {item.quantity}</p>
                      </div>
                      <div className="item-price">
                        ₹{(parseFloat(item.price) * parseInt(item.quantity)).toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="order-footer">
                  <div className="delivery-info">
                    <p><strong>Phone:</strong> {order.phone}</p>
                    <p><strong>Address:</strong> {order.address}</p>
                    <p><strong>Payment:</strong> {order.payment_method?.toUpperCase()}</p>
                  </div>
                  
                  <div className="order-total">
                    <h3>Total: ₹{parseFloat(order.total_amount).toFixed(2)}</h3>
                  </div>
                </div>

                {(order.status === 'pending' || order.status === 'confirmed') && (
                  <div className="order-actions">
                    <button 
                      className="btn-cancel"
                      onClick={() => handleCancelOrder(order.order_id)}
                    >
                      Cancel Order
                    </button>
                  </div>
                )}

                {order.seller_status === 'delivered' && order.buyer_status !== 'completed' && (
                  <div className="order-actions">
                    <button 
                      className="btn-primary"
                      onClick={() => handleMarkCompleted(order.order_id)}
                    >
                      ✓ Mark as Completed
                    </button>
                    <p className="delivery-note">Order delivered! Confirm receipt to complete the order.</p>
                  </div>
                )}

                {order.buyer_status === 'completed' && (
                  <div className="order-actions completed">
                    <p className="completion-message">✓ Order Completed</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default OrderHistory;
