// WishlistPage.jsx
import React, { useState, useEffect } from 'react';
import ProductCard from './ProductCard';
import { useTheme } from '../contexts/ThemeContext';
import './WishlistPage.css'; // Make sure to create this CSS file

const WishlistPage = ({ user, userLists, onUpdateLists, isSignedIn }) => {
  const { isDarkMode } = useTheme();
  const [wishlist, setWishlist] = useState([]);

  // Sync wishlist from userLists
  useEffect(() => {
    if (userLists?.wishlist && Array.isArray(userLists.wishlist)) {
      setWishlist(userLists.wishlist);
    }
  }, [userLists]);

  // Remove item from wishlist
  const handleRemove = (productId) => {
    const updatedWishlist = wishlist.filter(item => {
      const id = item.id || item.product_id || item.code;
      return id !== productId;
    });
    setWishlist(updatedWishlist);
    onUpdateLists?.('wishlist', updatedWishlist);
  };

  // Empty state
  if (wishlist.length === 0) {
    return (
      <div className={`wishlist-empty ${isDarkMode ? 'dark' : 'light'}`}>
        <div className="empty-content">
          <span className="heart-icon">Heart</span>
          <h2>Your Wishlist is Empty</h2>
          <p>Start adding products you love!</p>
        </div>
      </div>
    );
  }

  // Main wishlist with full responsive grid
  return (
    <div className={`wishlist-page ${isDarkMode ? 'dark' : 'light'}`}>

      {/* Full-width Responsive Grid */}
      <div className="wishlist-grid">
        {wishlist.map((product) => {
          const productId = product.id || product.product_id || product.code;

          return (
            <div key={productId} className="grid-item">
              <ProductCard
                product={product}
                isSignedIn={isSignedIn}
                user={user}
                userLists={userLists}
                onUpdateLists={onUpdateLists}
                isDarkMode={isDarkMode}
                onRemoveFromWishlist={() => handleRemove(productId)}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default WishlistPage;