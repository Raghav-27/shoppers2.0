import React, { useState } from 'react';
import './SearchBar.css';
import ProductCard from './ProductCard';

const SearchBar = ({ onSearch }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('relevance');
  const [selectedPlatforms, setSelectedPlatforms] = useState({
    //amazon: true,
    flipkart: true,
    meesho: true,
    shopsy: true,
    myntra: true,
    ajio: true
  });

  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [totalProducts, setTotalProducts] = useState(0);

  const handlePlatformChange = (platform) => {
    setSelectedPlatforms(prev => ({
      ...prev,
      [platform]: !prev[platform]
    }));
  };

  const handleSearch = async (e, page = 1) => {
    if (e) e.preventDefault();
    setError(null);

    // If onSearch prop is provided, use it instead of internal search
    if (onSearch) {
      onSearch({
        query: searchQuery,
        sort: selectedCategory,
        platforms: selectedPlatforms
      });
      return;
    }

    const activePlatforms = Object.keys(selectedPlatforms).filter(
      platform => selectedPlatforms[platform]
    );

    // Build query params
    const params = new URLSearchParams();
    params.append('query', searchQuery || '');
    params.append('sort', selectedCategory || 'relevance');
    params.append('page', page.toString());
    params.append('per_page', '10');
    if (activePlatforms.length) {
      params.append('platforms', activePlatforms.join(','));
    }

    setLoading(true);
    try {
      // Use environment variable for API URL, fallback to relative path
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const url = `${apiUrl}/api/search?${params.toString()}`;
      
      const res = await fetch(url);
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Server error: ${res.status} ${text}`);
      }
      const json = await res.json();
      setResults(json.products || []);
      setCurrentPage(json.page || 1);
      setTotalPages(json.total_pages || 0);
      setTotalProducts(json.total || 0);
    } catch (err) {
      console.error('Search error', err);
      setError(err.message || 'Unknown error');
      setResults([]);
      setCurrentPage(1);
      setTotalPages(0);
      setTotalProducts(0);
    } finally {
      setLoading(false);
    }
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= totalPages && !loading) {
      handleSearch(null, newPage);
    }
  };

  return (
    <div className="search-bar-container">
      <form onSubmit={handleSearch} className="search-form">
        <div className="search-input-wrapper">
          <select 
            value={selectedCategory} 
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="filters"
          >
            <option value="relevance">Relevance</option>
            <option value="asc">Price: Low to High</option>
            <option value="desc">Price: High to Low</option>
          </select>
          
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for products across multiple stores..."
            className="search-input"
          />
          
          <button type="submit" className="search-button" disabled={loading}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M21 21L16.514 16.506L21 21ZM19 10.5C19 15.194 15.194 19 10.5 19C5.806 19 2 15.194 2 10.5C2 5.806 5.806 2 10.5 2C15.194 2 19 5.806 19 10.5Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            {loading ? 'Searching...' : 'Search'}
          </button>
        </div>
        
        <div className="popular-searches">
          <span className="popular-label">Popular:</span>
          <button type="button" className="popular-tag" onClick={() => { setSearchQuery('iPhone'); }}>
            iPhone
          </button>
          <button type="button" className="popular-tag" onClick={() => { setSearchQuery('Laptop'); }}>
            Laptop
          </button>
          <button type="button" className="popular-tag" onClick={() => { setSearchQuery('Shoes'); }}>
            Shoes
          </button>
          <button type="button" className="popular-tag" onClick={() => { setSearchQuery('Watch'); }}>
            Watch
          </button>
        </div>

        <div className="platform-checkboxes">
          <span className="platform-label">Search on:</span>
          <div className="checkbox-group">
            <label className="checkbox-item">
              <input
                type="checkbox"
                checked={selectedPlatforms.amazon}
                onChange={() => handlePlatformChange('amazon')}
              />
              {/* <span className="checkbox-text">Amazon</span> */}
            </label>
            <label className="checkbox-item">
              <input
                type="checkbox"
                checked={selectedPlatforms.flipkart}
                onChange={() => handlePlatformChange('flipkart')}
              />
              <span className="checkbox-text">Flipkart</span>
            </label>
            <label className="checkbox-item">
              <input
                type="checkbox"
                checked={selectedPlatforms.meesho}
                onChange={() => handlePlatformChange('meesho')}
              />
              <span className="checkbox-text">Meesho</span>
            </label>
            <label className="checkbox-item">
              <input
                type="checkbox"
                checked={selectedPlatforms.shopsy}
                onChange={() => handlePlatformChange('shopsy')}
              />
              <span className="checkbox-text">Shopsy</span>
            </label>
            <label className="checkbox-item">
              <input
                type="checkbox"
                checked={selectedPlatforms.myntra}
                onChange={() => handlePlatformChange('myntra')}
              />
              <span className="checkbox-text">Myntra</span>
            </label>
            <label className="checkbox-item">
              <input
                type="checkbox"
                checked={selectedPlatforms.ajio}
                onChange={() => handlePlatformChange('ajio')}
              />
              <span className="checkbox-text">Ajio</span>
            </label>
          </div>
        </div>
      </form>

      <div className="search-results-wrapper">
        {error && <div className="error">Error: {error}</div>}
        {!error && !loading && results.length === 0 && searchQuery && (
          <div className="no-results">No results found for "{searchQuery}"</div>
        )}
        {results.length > 0 && (
          <div className="search-results">
            <div className="results-header">
              <h3>Search Results ({totalProducts} total, showing page {currentPage} of {totalPages})</h3>
            </div>
            
            <div className="product-grid">
              {results
                .filter(product => {
                  // Filter products based on selected platforms
                  // For now, all products are from Meesho, so only show if Meesho is selected
                  const productPlatform = 'meesho'; // In future, get from product.platform or product.source
                  return selectedPlatforms[productPlatform];
                })
                .map((product, idx) => (
                  <ProductCard 
                    key={product.id || product.product_id || idx} 
                    product={product} 
                  />
                ))
              }
              {results.filter(product => {
                const productPlatform = 'meesho';
                return selectedPlatforms[productPlatform];
              }).length === 0 && Object.values(selectedPlatforms).some(selected => selected) && (
                <div className="no-platform-results">
                  <div className="no-platform-results-content">
                    <h4>No products from selected platforms</h4>
                    <p>
                      Currently showing products from: Meesho only. 
                      {!selectedPlatforms.meesho ? ' Please select "Meesho" to see results.' : 
                       ' Other platforms will be available soon.'}
                    </p>
                  </div>
                </div>
              )}
            </div>
            
            {totalPages > 1 && (
              <div className="pagination">
                <button 
                  className="pagination-btn"
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1 || loading}
                >
                  Previous
                </button>
                
                <div className="pagination-info">
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    let pageNum;
                    if (totalPages <= 5) {
                      pageNum = i + 1;
                    } else if (currentPage <= 3) {
                      pageNum = i + 1;
                    } else if (currentPage >= totalPages - 2) {
                      pageNum = totalPages - 4 + i;
                    } else {
                      pageNum = currentPage - 2 + i;
                    }
                    
                    return (
                      <button
                        key={pageNum}
                        className={`pagination-number ${currentPage === pageNum ? 'active' : ''}`}
                        onClick={() => handlePageChange(pageNum)}
                        disabled={loading}
                      >
                        {pageNum}
                      </button>
                    );
                  })}
                </div>
                
                <button 
                  className="pagination-btn"
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages || loading}
                >
                  Next
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchBar;