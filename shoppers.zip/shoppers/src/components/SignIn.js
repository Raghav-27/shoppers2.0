import React, { useState } from 'react';
import './SignIn.css';

const SignIn = ({ onSignUpClick, onSignIn }) => {
    const [formData, setFormData] = useState({
        username: '',
        password: ''
    });

    const [errors, setErrors] = useState({});
    const [isLoading, setIsLoading] = useState(false);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
        // Clear error when user starts typing
        if (errors[name]) {
            setErrors(prev => ({
                ...prev,
                [name]: ''
            }));
        }
    };

    const validateForm = () => {
        const newErrors = {};

        if (!formData.username.trim()) {
            newErrors.username = 'Username is required';
        }

        if (!formData.password) {
            newErrors.password = 'Password is required';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        if (!validateForm()) {
            return;
        }

        setIsLoading(true);
        
        try {
            const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
            
            const response = await fetch(`${apiUrl}/api/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'include', // Include cookies
                body: JSON.stringify({
                    email: formData.username, // assuming username is email
                    password: formData.password
                })
            });

            const result = await response.json();

            if (response.ok) {
                console.log('Login Success:', result);
                
                // Note: Token is now stored in HTTP-only cookie
                // No need to store in localStorage anymore
                
                // Call the parent's sign in handler with user data
                onSignIn({
                    firstName: result.user.first_name,
                    lastName: result.user.last_name,
                    email: result.user.email,
                    phone: result.user.phone,
                    country: result.user.country,
                    token: result.token // Keep this for compatibility
                });
                
                // Reset form
                setFormData({
                    username: '',
                    password: ''
                });
            } else {
                // Handle server errors
                if (result.error) {
                    if (result.error.includes('Invalid email or password')) {
                        setErrors({ 
                            username: 'Invalid email or password',
                            password: 'Invalid email or password'
                        });
                    } else {
                        alert(`Login failed: ${result.error}`);
                    }
                } else {
                    alert('Login failed. Please try again.');
                }
            }
        } catch (error) {
            console.error('Sign in error:', error);
            alert('Network error. Please check your connection and try again.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="signin-container">
            <div className="signin-card">
                <div className="signin-header">
                    <h1>Sign In</h1>
                    <p>Welcome back to Shoppers</p>
                </div>

                <form onSubmit={handleSubmit} className="signin-form">
                    <div className="form-group">
                        <label htmlFor="username">Email *</label>
                        <input
                            type="email"
                            id="username"
                            name="username"
                            value={formData.username}
                            onChange={handleInputChange}
                            className={errors.username ? 'error' : ''}
                            placeholder="Enter your email address"
                        />
                        {errors.username && <span className="error-message">{errors.username}</span>}
                    </div>

                    <div className="form-group">
                        <label htmlFor="password">Password *</label>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            value={formData.password}
                            onChange={handleInputChange}
                            className={errors.password ? 'error' : ''}
                            placeholder="Enter your password"
                        />
                        {errors.password && <span className="error-message">{errors.password}</span>}
                    </div>

                    <button
                        type="submit"
                        className="signin-button"
                        disabled={isLoading}
                    >
                        {isLoading ? (
                            <div className="loading-spinner">
                                <div className="spinner"></div>
                                Signing In...
                            </div>
                        ) : (
                            'Sign In'
                        )}
                    </button>

                    <div className="signin-footer">
                        <p>Don't have an account? <button className="link-button" onClick={onSignUpClick}>Sign Up</button></p>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default SignIn;
