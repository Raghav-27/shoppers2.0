import React, { useState, useEffect, useCallback } from 'react';
import ProductCard from './ProductCard';
import './ProductsPage.css';
import { useTheme } from '../contexts/ThemeContext';

const ProductsPage = ({ searchQuery, sortOrder, selectedPlatforms, isSignedIn, user, userLists, onUpdateLists, onSearch }) => {
  const PER_PAGE = 20;

  const [productsByPlatform, setProductsByPlatform] = useState({});
  const [sellerProducts, setSellerProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const { isDarkMode } = useTheme();
  const [includeSellers, setIncludeSellers] = useState(true);
  
  // Secondary navbar state
  const [localSearchQuery, setLocalSearchQuery] = useState(searchQuery || '');
  const [localSortOrder, setLocalSortOrder] = useState(sortOrder || 'relevance');
  const [localPlatforms, setLocalPlatforms] = useState(selectedPlatforms || {});

  const searchProducts = useCallback(async (page = 1, overrides = {}) => {
    const query = overrides.query ?? searchQuery;
    const sort = overrides.sort ?? sortOrder ?? 'relevance';
    const platformsOverride = overrides.platforms ?? selectedPlatforms;

    if (!query?.trim()) return;

    setError(null);
    setLoading(true);

    const activePlatforms = Object.keys(platformsOverride || {}).filter(
      platform => platformsOverride[platform]
    );

    const params = new URLSearchParams();
    params.append('query', query);
    params.append('sort', sort);
    params.append('page', page.toString());
    params.append('per_page', String(PER_PAGE));
    params.append('include_sellers', includeSellers.toString());
    if (activePlatforms.length) {
      params.append('platforms', activePlatforms.join(','));
    }

    try {
      const apiUrl = process.env.REACT_APP_API_URL || '';
      const url = `${apiUrl}/api/search?${params.toString()}`;

      const res = await fetch(url, { credentials: 'include' });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Server error: ${res.status} ${text}`);
      }
      const json = await res.json();
      setProductsByPlatform(json.products || {});
      setSellerProducts(json.seller_products || []);
      setCurrentPage(json.page || page);
      setTotalPages(json.total_pages || 0);
    } catch (err) {
      console.error('Search error', err);
      setError(err.message || 'Unknown error');
      setProductsByPlatform({});
      setSellerProducts([]);
      setCurrentPage(1);
      setTotalPages(0);
    } finally {
      setLoading(false);
    }
  }, [searchQuery, sortOrder, selectedPlatforms, includeSellers]);

  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= totalPages && !loading) {
      searchProducts(newPage);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  useEffect(() => {
    searchProducts(1);
  }, [searchProducts]);

  // Sync local state with props
  useEffect(() => setLocalSearchQuery(searchQuery || ''), [searchQuery]);
  useEffect(() => setLocalSortOrder(sortOrder || 'relevance'), [sortOrder]);
  useEffect(() => setLocalPlatforms(selectedPlatforms || {}), [selectedPlatforms]);

  const handleSecondarySearch = (e) => {
    e.preventDefault();
    const queryTrimmed = localSearchQuery.trim();
    if (!queryTrimmed) return;

    if (onSearch) {
      onSearch({
        query: localSearchQuery,
        sort: localSortOrder,
        platforms: localPlatforms
      });
    } else {
      searchProducts(1, {
        query: localSearchQuery,
        sort: localSortOrder,
        platforms: localPlatforms
      });
    }
    setCurrentPage(1);
  };

  const handlePlatformToggle = (platform) => {
    const newPlatforms = {
      ...localPlatforms,
      [platform]: !localPlatforms[platform]
    };
    setLocalPlatforms(newPlatforms);
  };

  const handleSortChange = (e) => {
    const newSort = e.target.value;
    setLocalSortOrder(newSort);
  };

  // Helper function to extract price from different product structures
  const getProductPrice = (product) => {
    return (
      product.min_catalog_price ||
      product.min_product_price ||
      product.price ||
      product.pricing?.finalPrice?.value ||
      0
    );
  };

  // Helper function to extract rating from different product structures
  const getProductRating = (product) => {
    return (
      product.catalog_reviews_summary?.average_rating ||
      product.rating?.average ||
      product.rating ||
      0
    );
  };

  // Helper function to calculate discount from different product structures
  const getProductDiscount = (product) => {
    // For products with explicit discount
    if (product.discount_percent) return product.discount_percent;
    if (product.pricing?.totalDiscount) return product.pricing.totalDiscount;

    // Calculate discount from price and original price
    const price = getProductPrice(product);
    const originalPrice = 
      product.max_product_price ||
      product.original_price ||
      product.mrp ||
      product.pricing?.mrp?.value ||
      product.wasPriceData?.value;

    if (originalPrice && price && originalPrice > price) {
      return Math.round(((originalPrice - price) / originalPrice) * 100);
    }

    return 0;
  };

  // Sorting function
  const sortProducts = (products, sortType) => {
    const sorted = [...products];

    switch (sortType) {
      case 'price_asc':
      case 'asc':
        return sorted.sort((a, b) => getProductPrice(a) - getProductPrice(b));
      
      case 'price_desc':
      case 'desc':
        return sorted.sort((a, b) => getProductPrice(b) - getProductPrice(a));
      
      case 'rating':
        return sorted.sort((a, b) => getProductRating(b) - getProductRating(a));
      
      case 'discount':
        return sorted.sort((a, b) => getProductDiscount(b) - getProductDiscount(a));
      
      case 'random':
        return sorted.sort(() => Math.random() - 0.5);
      
      case 'relevance':
      default:
        return sorted;
    }
  };

  // Flatten products from SELECTED platforms only
  let allProducts = [];
  
  // Add products from selected scraped platforms
  Object.keys(productsByPlatform).forEach(platform => {
    if (localPlatforms[platform]) {
      allProducts.push(...productsByPlatform[platform]);
    }
  });
  
  // Add seller products if included
  if (includeSellers) {
    allProducts.push(...sellerProducts.map(p => ({ ...p, isSellerProduct: true })));
  }
  
  // Apply sorting to products
  const sortedProducts = sortProducts(allProducts, localSortOrder);

  const platformDisplayNames = {
    meesho: 'Meesho',
   // amazon: 'Amazon',
    flipkart: 'Flipkart',
    myntra: 'Myntra',
    shopsy: 'Shopsy',
    ajio: 'Ajio'
  };

  const platformColors = {
    meesho: '#ff6b6b',
   // amazon: '#ff9500',
    flipkart: '#2874f0',
    myntra: '#ff3e6c',
    shopsy: '#00d4aa',
    ajio: '#3b3b3bff'
  };

  // Dynamic height adjustment
  useEffect(() => {
    const setProductsHeight = () => {
      const navbar = document.querySelector('.navbar');
      const secondary = document.querySelector('.secondary-navbar');
      const header = document.querySelector('.products-header');
      const topSpace = (navbar?.offsetHeight || 0) + (secondary?.offsetHeight || 0) + (header?.offsetHeight || 0) + 50;
      const height = Math.max(400, window.innerHeight - topSpace);
      const el = document.querySelector('.products-content');
      if (el) el.style.maxHeight = `${height}px`;
    };

    setProductsHeight();
    window.addEventListener('resize', setProductsHeight);
    return () => window.removeEventListener('resize', setProductsHeight);
  }, []);

  const themeClass = isDarkMode ? 'dark-mode' : 'light';

  if (loading && allProducts.length === 0) {
    return (
      <div className={`products-page ${themeClass}`}>
        <div className={`secondary-navbar ${themeClass}`}>
          <div className="secondary-search-container">
            <form onSubmit={handleSecondarySearch} className="secondary-search-form">
              <input
                type="text"
                className={`secondary-search-input ${themeClass}`}
                placeholder="Search products..."
                value={localSearchQuery}
                onChange={(e) => setLocalSearchQuery(e.target.value)}
              />
              <button type="submit" className={`secondary-search-btn ${themeClass}`}>
                🔍
              </button>
            </form>

            <div className={`secondary-filters ${themeClass}`}>
              <select value={localSortOrder} onChange={handleSortChange} className={`sort-select ${themeClass}`}>
                <option value="relevance">Relevance</option>
                <option value="price_asc">Price: Low to High</option>
                <option value="price_desc">Price: High to Low</option>
                <option value="rating">Rating: High to Low</option>
                <option value="discount">Discount: High to Low</option>
                <option value="random">Random Order</option>
              </select>

              <div className={`platform-filters ${themeClass}`}>
                {Object.keys(localPlatforms).map(platform => (
                  <label key={platform} className={`platform-checkbox ${themeClass}`}>
                    <input
                      type="checkbox"
                      checked={localPlatforms[platform]}
                      onChange={() => handlePlatformToggle(platform)}
                    />
                    <span>{platformDisplayNames[platform]}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className={`loading-container ${themeClass}`}>
          <div className="loading-spinner"></div>
          <p>Searching for products...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`products-page ${themeClass}`}>
      {/* Secondary Navbar */}
      <div className={`secondary-navbar ${themeClass}`}>
        <div className="secondary-search-container">
          <form onSubmit={handleSecondarySearch} className="secondary-search-form">
            <input
              type="text"
              className={`secondary-search-input ${themeClass}`}
              placeholder="Search products..."
              value={localSearchQuery}
              onChange={(e) => setLocalSearchQuery(e.target.value)}
            />
            <button type="submit" className={`secondary-search-btn ${themeClass}`}>
              🔍
            </button>
          </form>

          <div className={`secondary-filters ${themeClass}`}>
            <select value={localSortOrder} onChange={handleSortChange} className={`sort-select ${themeClass}`}>
              <option value="relevance">Relevance</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="rating">Rating: High to Low</option>
              <option value="discount">Discount: High to Low</option>
              <option value="random">Random Order</option>
            </select>

            <div className={`platform-filters ${themeClass}`}>
              {Object.keys(localPlatforms).map(platform => (
                <label key={platform} className={`platform-checkbox ${themeClass}`}>
                  <input
                    type="checkbox"
                    checked={localPlatforms[platform]}
                    onChange={() => handlePlatformToggle(platform)}
                  />
                  <span style={{ color: localPlatforms[platform] ? platformColors[platform] : '' }}>
                    {platformDisplayNames[platform]}
                  </span>
                </label>
              ))}
              <label className={`platform-checkbox ${themeClass}`} style={{ marginTop: '10px', paddingTop: '10px', borderTop: '1px solid #ddd' }}>
                <input
                  type="checkbox"
                  checked={includeSellers}
                  onChange={(e) => setIncludeSellers(e.target.checked)}
                />
                <span style={{ color: includeSellers ? '#4CAF50' : '', fontWeight: includeSellers ? 'bold' : 'normal' }}>
                  🏪 Shoppers Marketplace {sellerProducts.length > 0 && `(${sellerProducts.length})`}
                </span>
              </label>
            </div>
          </div>

          {/* Pagination */}
          {sortedProducts.length > 0 && totalPages > 1 && (
            <div className={`pagination ${themeClass}`}>
              <button
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1 || loading}
                className="pagination-btn"
              >
                Previous
              </button>

              <div className="pagination-info">
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  let pageNum;
                  if (totalPages <= 5) pageNum = i + 1;
                  else if (currentPage <= 3) pageNum = i + 1;
                  else if (currentPage >= totalPages - 2) pageNum = totalPages - 4 + i;
                  else pageNum = currentPage - 2 + i;

                  return (
                    <button className={`pagination-number ${currentPage === pageNum ? 'active' : ''}`}
                      key={pageNum}
                      onClick={() => handlePageChange(pageNum)}
                      disabled={loading}
                    >
                      {pageNum}
                    </button>
                  );
                })}
              </div>

              <button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages || loading}
                className="pagination-btn"
              >
                Next
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Error State */}
      {error && (
        <div className={`error-container ${themeClass}`}>
          <div className={`error-message ${themeClass}`}>
            <h3>Oops! Something went wrong</h3>
            <p>{error}</p>
            <button className={`retry-button ${themeClass}`} onClick={() => searchProducts(currentPage)}>
              Try Again
            </button>
          </div>
        </div>
      )}

      {/* No Results */}
      {!error && sortedProducts.length === 0 && !loading && (
        <div className={`no-results ${themeClass}`}>
          <h3>No products found</h3>
          <p>Try adjusting your search terms or filters</p>
        </div>
      )}

      {/* Products Grid */}
      {sortedProducts.length > 0 && (
        <div className={`products-content ${themeClass}`}>
          <div className={`all-products-grid ${themeClass}`}>
            {sortedProducts.map((product, idx) => (
              <ProductCard
                key={product.id || product.product_id || product.code || idx}
                product={product}
                isSignedIn={isSignedIn}
                user={user}
                userLists={userLists}
                onUpdateLists={onUpdateLists}
                isDarkMode={isDarkMode}
              />
            ))}
          </div>
        </div>
      )}

    </div>
  );
};

export default ProductsPage;