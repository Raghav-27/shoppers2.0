// CartPage.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import ProductCard from './ProductCard';
import { useTheme } from '../contexts/ThemeContext';
import './CartPage.css';

const CartPage = ({ user, userLists, onUpdateLists, isSignedIn }) => {
  const { isDarkMode } = useTheme();
  const navigate = useNavigate();
  const [cart, setCart] = useState([]);

  // Initialize cart from userLists only on mount
  useEffect(() => {
    if (userLists?.cart && Array.isArray(userLists.cart)) {
      setCart(userLists.cart);
    }
  }, []); // Empty dependency array - only run on mount

  // Update quantity
  const updateQuantity = (productId, newQty) => {
    if (newQty < 1) return handleRemove(productId);

    const updatedCart = cart.map(item => {
      const id = item.id || item.product_id || item.code;
      if (id === productId) {
        return { ...item, quantity: newQty };
      }
      return item;
    });
    setCart(updatedCart);
    
    // Update on API
    updateCartQuantityOnAPI(productId, newQty);
    
    // Update parent state
    onUpdateLists?.('cart', updatedCart);
  };

  // Update quantity on API
  const updateCartQuantityOnAPI = async (productId, newQuantity) => {
    try {
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const response = await fetch(`${apiUrl}/api/user/cart/${productId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ quantity: newQuantity })
      });

      if (!response.ok) {
        console.error('Failed to update cart quantity:', response.status);
      }
    } catch (error) {
      console.error('Error updating cart quantity:', error);
    }
  };

  // Remove item
  const handleRemove = (productId) => {
    const updatedCart = cart.filter(item => {
      const id = item.id || item.product_id || item.code;
      return id !== productId;
    });
    setCart(updatedCart);
    onUpdateLists?.('cart', updatedCart);
  };

  // Clear entire cart
  const handleClearCart = () => {
    setCart([]);
    onUpdateLists?.('cart', []);
  };

  // Calculate totals by source
  const sellerProducts = cart.filter(item => item.source === 'seller' || item.platform === 'Seller');
  const marketplaceProducts = cart.filter(item => !(item.source === 'seller' || item.platform === 'Seller'));

  const sellerTotal = sellerProducts.reduce((sum, item) => {
    const price = parseFloat(item.discounted_price || item.price || 0);
    const qty = item.quantity || 1;
    return sum + (price * qty);
  }, 0);

  const marketplaceTotal = marketplaceProducts.reduce((sum, item) => {
    const price = parseFloat(item.discounted_price || item.price || 0);
    const qty = item.quantity || 1;
    return sum + (price * qty);
  }, 0);

  const subtotal = sellerTotal + marketplaceTotal;
  const totalItems = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);

  // Empty state
  if (cart.length === 0) {
    return (
      <div className={`cart-empty ${isDarkMode ? 'dark' : ''}`}>
        <div className="empty-content">
          <span className="cart-icon">Shopping Bag</span>
          <h2>Your Cart is Empty</h2>
          <p>Add some amazing products and come back!</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`cart-container ${isDarkMode ? 'dark' : ''}`}>

      <div className="cart-content">
        {/* Cart Items Grid */}
        <div className="cart-grid">
          {cart.map((product) => {
            const productId = product.id || product.product_id || product.code;
            const qty = product.quantity || 1;
            const price = parseFloat(product.discounted_price || product.price || 0);
            const itemTotal = price * qty;

            return (
              <div key={productId} className="cart-item-wrapper">
                <div className="cart-item-container">
                  {/* Product Image */}
                  <div className="cart-item-image">
                    <img 
                      src={product.image || product.image_url || '/placeholder-image.svg'} 
                      alt={product.name || product.title}
                      onError={(e) => e.target.src = '/placeholder-image.svg'}
                    />
                  </div>
                  
                  {/* Product Info */}
                  <div className="cart-item-info">
                    <h3>{product.name || product.title}</h3>
                    <p className="cart-item-seller">by {product.seller_name || product.platform || 'Seller'}</p>
                    <p className="cart-item-category">{product.category}</p>
                    <p className="cart-item-price">₹{price.toFixed(2)}</p>
                  </div>
                  
                  {/* Quantity Control */}
                  <div className="cart-item-quantity">
                    <label>Quantity:</label>
                    <div className="quantity-control">
                      <button 
                        className="qty-btn qty-minus"
                        onClick={() => updateQuantity(productId, Math.max(1, qty - 1))}
                        title="Decrease quantity"
                      >
                        −
                      </button>
                      <input 
                        type="number" 
                        className="qty-input" 
                        value={qty}
                        onChange={(e) => {
                          const newQty = Math.max(1, parseInt(e.target.value) || 1);
                          updateQuantity(productId, newQty);
                        }}
                        min="1"
                      />
                      <button 
                        className="qty-btn qty-plus"
                        onClick={() => updateQuantity(productId, qty + 1)}
                        title="Increase quantity"
                      >
                        +
                      </button>
                    </div>
                  </div>
                  
                  {/* Item Total */}
                  <div className="cart-item-total">
                    <p className="label">Item Total:</p>
                    <p className="amount">₹{itemTotal.toFixed(2)}</p>
                  </div>
                  
                  {/* Remove Button */}
                  <button 
                    className="cart-item-remove"
                    onClick={() => handleRemove(productId)}
                    title="Remove from cart"
                  >
                    ✕
                  </button>
                </div>
              </div>
            );
          })}
        </div>
        
        {/* Cart Summary */}
        <div className="cart-summary">
          <h3>Cart Summary</h3>
          <div className="summary-row">
            <span>Total Items:</span>
            <span>{totalItems}</span>
          </div>
          
          {/* Separate totals by source */}
          {marketplaceProducts.length > 0 && (
            <div className="summary-row">
              <span>Marketplace Total ({marketplaceProducts.length} items):</span>
              <span className="marketplace-total">₹{marketplaceTotal.toFixed(2)}</span>
            </div>
          )}
          
          {sellerProducts.length > 0 && (
            <div className="summary-row">
              <span>Seller Products Total ({sellerProducts.length} items):</span>
              <span className="seller-total">₹{sellerTotal.toFixed(2)}</span>
            </div>
          )}
          
          <hr />
          <div className="summary-row total-amount">
            <span>Grand Total:</span>
            <span>₹{subtotal.toFixed(2)}</span>
          </div>
          
          <button 
            className="btn-checkout"
            onClick={() => navigate('/checkout')}
          >
            Proceed to Checkout
          </button>
          
          <button 
            className="btn-clear-cart"
            onClick={handleClearCart}
          >
            Clear Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default CartPage;