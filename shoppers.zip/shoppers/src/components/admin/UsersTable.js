import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import DataTable from './DataTable';
import './UsersTable.css';

const UsersTable = () => {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [offset, setOffset] = useState(0);
  const [search, setSearch] = useState('');
  const limit = 20;

  useEffect(() => {
    fetchUsers();
  }, [offset, search]);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        offset: offset.toString(),
        limit: limit.toString(),
        ...(search && { search })
      });

      const response = await fetch(`http://localhost:5002/api/admin/users?${params}`, {
        credentials: 'include'
      });

      if (response.status === 401 || response.status === 403) {
        navigate('/signin');
        return;
      }

      if (!response.ok) {
        throw new Error('Failed to fetch users');
      }

      const data = await response.json();
      setUsers(data.users);
      setTotal(data.total);
    } catch (err) {
      console.error('Error fetching users:', err);
    } finally {
      setLoading(false);
    }
  };

  const columns = [
    {
      key: 'first_name',
      label: 'First Name',
      sortable: true,
      width: '15%'
    },
    {
      key: 'last_name',
      label: 'Last Name',
      sortable: true,
      width: '15%'
    },
    {
      key: 'email',
      label: 'Email',
      sortable: true,
      width: '25%'
    },
    {
      key: 'phone',
      label: 'Phone',
      sortable: false,
      width: '15%'
    },
    {
      key: 'country',
      label: 'Country',
      sortable: true,
      width: '12%'
    },
    {
      key: 'is_admin',
      label: 'Role',
      sortable: true,
      width: '10%',
      render: (value) => (
        <span className={`role-badge ${value ? 'admin' : 'user'}`}>
          {value ? 'Admin' : 'User'}
        </span>
      )
    },
    {
      key: 'created_at',
      label: 'Joined',
      sortable: true,
      width: '18%',
      render: (value) => {
        if (!value) return '-';
        const date = new Date(value);
        return date.toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric'
        });
      }
    }
  ];

  const handlePageChange = (newOffset) => {
    setOffset(newOffset);
  };

  const handleSearch = (searchTerm) => {
    setSearch(searchTerm);
    setOffset(0);
  };

  return (
    <div className="users-table-page">
      <div className="page-header">
        <div>
          <h1>User Management</h1>
          <p>View and manage all registered users</p>
        </div>
        <button onClick={() => navigate('/admin')} className="btn-back">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M19 12H5M5 12l7 7M5 12l7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Back to Dashboard
        </button>
      </div>

      <DataTable
        columns={columns}
        data={users}
        loading={loading}
        total={total}
        offset={offset}
        limit={limit}
        onPageChange={handlePageChange}
        onSearch={handleSearch}
        searchPlaceholder="Search by name or email..."
        emptyMessage="No users found"
      />
    </div>
  );
};

export default UsersTable;
