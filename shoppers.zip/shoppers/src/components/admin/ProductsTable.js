import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import DataTable from './DataTable';
import './ProductsTable.css';

const ProductsTable = () => {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [offset, setOffset] = useState(0);
  const [search, setSearch] = useState('');
  const limit = 20;

  useEffect(() => {
    fetchProducts();
  }, [offset, search]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        offset: offset.toString(),
        limit: limit.toString(),
        ...(search && { search })
      });

      const response = await fetch(`http://localhost:5002/api/admin/products?${params}`, {
        credentials: 'include'
      });

      if (response.status === 401 || response.status === 403) {
        navigate('/signin');
        return;
      }

      if (!response.ok) {
        throw new Error('Failed to fetch products');
      }

      const data = await response.json();
      setProducts(data.products);
      setTotal(data.total);
    } catch (err) {
      console.error('Error fetching products:', err);
    } finally {
      setLoading(false);
    }
  };

  const columns = [
    {
      key: 'image_url',
      label: 'Image',
      sortable: false,
      width: '80px',
      render: (value) => (
        <div className="product-image">
          {value ? (
            <img src={value} alt="Product" onError={(e) => e.target.src = '/placeholder.png'} />
          ) : (
            <div className="image-placeholder">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="2"/>
                <circle cx="8.5" cy="8.5" r="1.5" fill="currentColor"/>
                <path d="M3 15l5-5 3 3 6-6 4 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          )}
        </div>
      )
    },
    {
      key: 'name',
      label: 'Product Name',
      sortable: true,
      width: '25%'
    },
    {
      key: 'seller_id',
      label: 'Seller ID',
      sortable: true,
      width: '10%'
    },
    {
      key: 'category',
      label: 'Category',
      sortable: true,
      width: '12%'
    },
    {
      key: 'price',
      label: 'Price',
      sortable: true,
      width: '10%',
      render: (value) => `₹${value?.toLocaleString() || 0}`
    },
    {
      key: 'stock',
      label: 'Stock',
      sortable: true,
      width: '8%',
      render: (value) => (
        <span className={`stock-badge ${value > 10 ? 'in-stock' : value > 0 ? 'low-stock' : 'out-of-stock'}`}>
          {value || 0}
        </span>
      )
    },
    {
      key: 'is_active',
      label: 'Status',
      sortable: true,
      width: '10%',
      render: (value) => (
        <span className={`product-status ${value ? 'active' : 'inactive'}`}>
          {value ? 'Active' : 'Inactive'}
        </span>
      )
    },
    {
      key: 'created_at',
      label: 'Added',
      sortable: true,
      width: '15%',
      render: (value) => {
        if (!value) return '-';
        const date = new Date(value);
        return date.toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric'
        });
      }
    }
  ];

  const handlePageChange = (newOffset) => {
    setOffset(newOffset);
  };

  const handleSearch = (searchTerm) => {
    setSearch(searchTerm);
    setOffset(0);
  };

  return (
    <div className="products-table-page">
      <div className="page-header">
        <div>
          <h1>Product Management</h1>
          <p>View and monitor all seller products</p>
        </div>
        <button onClick={() => navigate('/admin')} className="btn-back">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M19 12H5M5 12l7 7M5 12l7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Back to Dashboard
        </button>
      </div>

      <DataTable
        columns={columns}
        data={products}
        loading={loading}
        total={total}
        offset={offset}
        limit={limit}
        onPageChange={handlePageChange}
        onSearch={handleSearch}
        searchPlaceholder="Search by product name..."
        emptyMessage="No products found"
      />
    </div>
  );
};

export default ProductsTable;
