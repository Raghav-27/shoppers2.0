import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import DataTable from './DataTable';
import './OrdersTable.css';

const OrdersTable = () => {
  const navigate = useNavigate();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [offset, setOffset] = useState(0);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const limit = 20;

  useEffect(() => {
    fetchOrders();
  }, [offset, search, statusFilter]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        offset: offset.toString(),
        limit: limit.toString(),
        ...(search && { search }),
        ...(statusFilter && { status_filter: statusFilter })
      });

      const response = await fetch(`http://localhost:5002/api/admin/orders?${params}`, {
        credentials: 'include'
      });

      if (response.status === 401 || response.status === 403) {
        navigate('/signin');
        return;
      }

      if (!response.ok) {
        throw new Error('Failed to fetch orders');
      }

      const data = await response.json();
      setOrders(data.orders);
      setTotal(data.total);
    } catch (err) {
      console.error('Error fetching orders:', err);
    } finally {
      setLoading(false);
    }
  };

  const columns = [
    {
      key: 'order_id',
      label: 'Order ID',
      sortable: true,
      width: '15%',
      render: (value) => (
        <span className="order-id">{value?.slice(0, 12)}...</span>
      )
    },
    {
      key: 'user_email',
      label: 'Customer',
      sortable: true,
      width: '20%'
    },
    {
      key: 'phone',
      label: 'Phone',
      sortable: false,
      width: '13%'
    },
    {
      key: 'total_amount',
      label: 'Amount',
      sortable: true,
      width: '10%',
      render: (value) => `₹${value?.toLocaleString() || 0}`
    },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
      width: '12%',
      render: (value) => (
        <span className={`order-status-badge ${value}`}>
          {value?.charAt(0).toUpperCase() + value?.slice(1)}
        </span>
      )
    },
    {
      key: 'payment_status',
      label: 'Payment',
      sortable: true,
      width: '12%',
      render: (value) => (
        <span className={`payment-badge ${value}`}>
          {value?.charAt(0).toUpperCase() + value?.slice(1)}
        </span>
      )
    },
    {
      key: 'order_date',
      label: 'Order Date',
      sortable: true,
      width: '18%',
      render: (value) => {
        if (!value) return '-';
        const date = new Date(value);
        return date.toLocaleString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });
      }
    }
  ];

  const handlePageChange = (newOffset) => {
    setOffset(newOffset);
  };

  const handleSearch = (searchTerm) => {
    setSearch(searchTerm);
    setOffset(0);
  };

  return (
    <div className="orders-table-page">
      <div className="page-header">
        <div>
          <h1>Order Management</h1>
          <p>View and monitor all customer orders</p>
        </div>
        <div className="header-actions">
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setOffset(0);
            }}
            className="status-filter"
          >
            <option value="">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="confirmed">Confirmed</option>
            <option value="processing">Processing</option>
            <option value="shipped">Shipped</option>
            <option value="delivered">Delivered</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <button onClick={() => navigate('/admin')} className="btn-back">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M19 12H5M5 12l7 7M5 12l7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Back to Dashboard
          </button>
        </div>
      </div>

      <DataTable
        columns={columns}
        data={orders}
        loading={loading}
        total={total}
        offset={offset}
        limit={limit}
        onPageChange={handlePageChange}
        onSearch={handleSearch}
        searchPlaceholder="Search by order ID, customer email, or phone..."
        emptyMessage="No orders found"
      />
    </div>
  );
};

export default OrdersTable;
