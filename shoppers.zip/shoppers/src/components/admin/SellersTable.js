import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import DataTable from './DataTable';
import './SellersTable.css';

const SellersTable = () => {
  const navigate = useNavigate();
  const [sellers, setSellers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [offset, setOffset] = useState(0);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [selectedSeller, setSelectedSeller] = useState(null);
  const [actionType, setActionType] = useState('');
  const limit = 20;

  useEffect(() => {
    fetchSellers();
  }, [offset, search, statusFilter]);

  const fetchSellers = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        offset: offset.toString(),
        limit: limit.toString(),
        ...(search && { search }),
        ...(statusFilter && { status_filter: statusFilter })
      });

      const response = await fetch(`http://localhost:5002/api/admin/sellers?${params}`, {
        credentials: 'include'
      });

      if (response.status === 401 || response.status === 403) {
        navigate('/signin');
        return;
      }

      if (!response.ok) {
        throw new Error('Failed to fetch sellers');
      }

      const data = await response.json();
      setSellers(data.sellers);
      setTotal(data.total);
    } catch (err) {
      console.error('Error fetching sellers:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFreeze = (seller) => {
    setSelectedSeller(seller);
    setActionType('freeze');
    setShowConfirmModal(true);
  };

  const handleUnfreeze = (seller) => {
    setSelectedSeller(seller);
    setActionType('unfreeze');
    setShowConfirmModal(true);
  };

  const confirmAction = async () => {
    if (!selectedSeller) return;

    try {
      const endpoint = actionType === 'freeze' ? 'freeze' : 'unfreeze';
      const response = await fetch(
        `http://localhost:5002/api/admin/sellers/${selectedSeller.seller_id}/${endpoint}`,
        {
          method: 'PUT',
          credentials: 'include'
        }
      );

      if (!response.ok) {
        throw new Error(`Failed to ${actionType} seller`);
      }

      // Refresh the sellers list
      await fetchSellers();
      setShowConfirmModal(false);
      setSelectedSeller(null);
    } catch (err) {
      console.error(`Error ${actionType}ing seller:`, err);
      alert(`Failed to ${actionType} seller. Please try again.`);
    }
  };

  const columns = [
    {
      key: 'seller_id',
      label: 'ID',
      sortable: true,
      width: '8%'
    },
    {
      key: 'business_name',
      label: 'Business Name',
      sortable: true,
      width: '22%'
    },
    {
      key: 'email',
      label: 'Email',
      sortable: true,
      width: '22%'
    },
    {
      key: 'phone',
      label: 'Phone',
      sortable: false,
      width: '15%'
    },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
      width: '10%',
      render: (value) => (
        <span className={`status-badge ${value}`}>
          {value === 'active' ? 'Active' : 'Frozen'}
        </span>
      )
    },
    {
      key: 'total_products',
      label: 'Products',
      sortable: true,
      width: '10%',
      render: (value) => value || 0
    },
    {
      key: 'created_at',
      label: 'Joined',
      sortable: true,
      width: '13%',
      render: (value) => {
        if (!value) return '-';
        const date = new Date(value);
        return date.toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric'
        });
      }
    }
  ];

  const actions = (seller) => (
    <div className="action-buttons">
      {seller.status === 'active' ? (
        <button
          onClick={() => handleFreeze(seller)}
          className="btn-action freeze"
          title="Freeze seller account"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
            <path d="M12 6v6l4 2" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            <path d="M9 9l6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          </svg>
          Freeze
        </button>
      ) : (
        <button
          onClick={() => handleUnfreeze(seller)}
          className="btn-action unfreeze"
          title="Unfreeze seller account"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9 12l2 2 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
          </svg>
          Unfreeze
        </button>
      )}
    </div>
  );

  const handlePageChange = (newOffset) => {
    setOffset(newOffset);
  };

  const handleSearch = (searchTerm) => {
    setSearch(searchTerm);
    setOffset(0);
  };

  return (
    <div className="sellers-table-page">
      <div className="page-header">
        <div>
          <h1>Seller Management</h1>
          <p>Manage seller accounts and monitor their activity</p>
        </div>
        <div className="header-actions">
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value);
              setOffset(0);
            }}
            className="status-filter"
          >
            <option value="">All Statuses</option>
            <option value="active">Active</option>
            <option value="inactive">Frozen</option>
          </select>
          <button onClick={() => navigate('/admin')} className="btn-back">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M19 12H5M5 12l7 7M5 12l7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Back to Dashboard
          </button>
        </div>
      </div>

      <DataTable
        columns={columns}
        data={sellers}
        loading={loading}
        total={total}
        offset={offset}
        limit={limit}
        onPageChange={handlePageChange}
        onSearch={handleSearch}
        searchPlaceholder="Search by business name or email..."
        emptyMessage="No sellers found"
        actions={actions}
      />

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="modal-overlay" onClick={() => setShowConfirmModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h3>{actionType === 'freeze' ? 'Freeze Seller Account' : 'Unfreeze Seller Account'}</h3>
            <p>
              Are you sure you want to {actionType} <strong>{selectedSeller?.business_name}</strong>?
            </p>
            {actionType === 'freeze' && (
              <p className="warning-text">
                This will prevent the seller from accessing their account and their products will not be visible to customers.
              </p>
            )}
            <div className="modal-actions">
              <button onClick={() => setShowConfirmModal(false)} className="btn-cancel">
                Cancel
              </button>
              <button onClick={confirmAction} className={`btn-confirm ${actionType}`}>
                {actionType === 'freeze' ? 'Freeze' : 'Unfreeze'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SellersTable;
