import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { useTheme } from '../contexts/ThemeContext';
import './PaymentPage.css';

const PaymentPage = ({ isSignedIn, user }) => {
  const navigate = useNavigate();
  const { orderId } = useParams();
  const location = useLocation();
  const { isDarkMode } = useTheme();

  const [order, setOrder] = useState(null);
  const [paymentStatus, setPaymentStatus] = useState('processing');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [sessionId, setSessionId] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [showManualForm, setShowManualForm] = useState(false);

  const fetchOrderDetails = useCallback(async () => {
    try {
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const response = await fetch(`${apiUrl}/api/orders/${orderId}`, {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        setOrder(data.order);
      } else {
        setError('Failed to fetch order details');
        setLoading(false);
      }
    } catch (err) {
      console.error('Error fetching order:', err);
      setError('Failed to load order details');
      setLoading(false);
    }
  }, [orderId]);

  const initiatePayment = useCallback(async (orderData) => {
    try {
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const total = orderData.total_amount || 0;

      const response = await fetch(`${apiUrl}/api/payment/initiate`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          order_id: orderData.order_id,
          amount: total,
          payment_method: 'online'
        })
      });

      if (response.ok) {
        const data = await response.json();
        setSessionId(data.session_id);
        setTransactionId(data.transaction_id);
        setPaymentStatus('idle');
        setLoading(false);
      } else {
        setShowManualForm(true);
        setPaymentStatus('idle');
        setLoading(false);
      }
    } catch (error) {
      console.error('Payment initiation error:', error);
      setShowManualForm(true);
      setPaymentStatus('idle');
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!isSignedIn) {
      navigate('/signin');
      return;
    }

    // Get order data from state or fetch from API
    const stateOrder = location.state?.order;
    if (stateOrder) {
      setOrder(stateOrder);
      initiatePayment(stateOrder);
    } else {
      fetchOrderDetails();
    }
  }, [isSignedIn, orderId, navigate, location.state?.order, fetchOrderDetails, initiatePayment]);

  const handlePaymentSuccess = async () => {
    setLoading(true);
    setPaymentStatus('processing');

    try {
      // Generate transaction ID for demo
      const transId = `TXN${Date.now()}`;
      setTransactionId(transId);

      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const response = await fetch(`${apiUrl}/api/payment/confirm`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          session_id: sessionId,
          transaction_id: transId,
          status: 'success'
        })
      });

      if (response.ok) {
        setPaymentStatus('success');
        setLoading(false);
        
        // Redirect to order confirmation after 2 seconds
        setTimeout(() => {
          navigate('/orders');
        }, 2000);
      } else {
        setPaymentStatus('failed');
        setError('Payment confirmation failed');
        setLoading(false);
      }
    } catch (err) {
      console.error('Error confirming payment:', err);
      setPaymentStatus('failed');
      setError('Failed to confirm payment');
      setLoading(false);
    }
  };

  const handlePaymentFailed = async () => {
    setLoading(true);
    setPaymentStatus('processing');

    try {
      const transId = `TXN${Date.now()}`;
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';

      await fetch(`${apiUrl}/api/payment/confirm`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          session_id: sessionId,
          transaction_id: transId,
          status: 'failed'
        })
      });

      setPaymentStatus('failed');
      setError('Payment declined. Please try again or use another payment method.');
      setLoading(false);
    } catch (err) {
      console.error('Error processing failed payment:', err);
      setError('Error processing payment failure');
      setLoading(false);
    }
  };

  const handleRetryPayment = () => {
    setPaymentStatus('ready');
    setError('');
    setLoading(false);
  };

  if (!isSignedIn) {
    return null;
  }

  if (loading && paymentStatus === 'processing') {
    return (
      <div className={`payment-page ${isDarkMode ? 'dark' : ''}`}>
        <div className="payment-container">
          <div className="loading-spinner">
            <div className="spinner"></div>
            <p>Processing your payment...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`payment-page ${isDarkMode ? 'dark' : ''}`}>
      <div className="payment-container">
        {paymentStatus === 'ready' && (
          <div className="payment-form-section">
            <h1>Complete Payment</h1>

            {order && (
              <div className="order-summary">
                <h2>Order Summary</h2>
                <div className="summary-item">
                  <span>Order ID:</span>
                  <strong>{order.order_id}</strong>
                </div>
                <div className="summary-item">
                  <span>Total Amount:</span>
                  <strong className="amount">₹{order.total_amount?.toFixed(2)}</strong>
                </div>
                <div className="summary-item">
                  <span>Items:</span>
                  <strong>{order.items?.length} item(s)</strong>
                </div>
              </div>
            )}

            {!showManualForm ? (
              <div className="payment-methods">
                <button
                  className="btn-payment-gateway"
                  onClick={() => setShowManualForm(true)}
                >
                  💳 Pay with Card
                </button>
                <p className="demo-note">Demo: Click to enter test card details</p>
              </div>
            ) : (
              <form className="payment-form" onSubmit={(e) => {
                e.preventDefault();
                handlePaymentSuccess();
              }}>
                <div className="form-group">
                  <label>Card Number</label>
                  <input
                    type="text"
                    placeholder="4532 1234 5678 9010"
                    maxLength="16"
                    pattern="\d{16}"
                    required
                  />
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>Expiry Date</label>
                    <input
                      type="text"
                      placeholder="MM/YY"
                      maxLength="5"
                      pattern="\d{2}/\d{2}"
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label>CVV</label>
                    <input
                      type="text"
                      placeholder="123"
                      maxLength="3"
                      pattern="\d{3}"
                      required
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label>Cardholder Name</label>
                  <input
                    type="text"
                    placeholder="John Doe"
                    required
                  />
                </div>

                <div className="payment-buttons">
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={() => setShowManualForm(false)}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="btn-primary"
                  >
                    Pay ₹{order?.total_amount?.toFixed(2)}
                  </button>
                </div>
              </form>
            )}

            <div className="demo-buttons">
              <p className="demo-note">Demo Mode - Test Buttons:</p>
              <button
                className="btn-success"
                onClick={handlePaymentSuccess}
              >
                ✓ Simulate Success
              </button>
              <button
                className="btn-danger"
                onClick={handlePaymentFailed}
              >
                ✗ Simulate Failed
              </button>
            </div>
          </div>
        )}

        {paymentStatus === 'success' && (
          <div className="payment-success">
            <div className="success-icon">✓</div>
            <h1>Payment Successful!</h1>
            <p>Your payment has been processed successfully.</p>
            
            {order && (
              <div className="payment-confirmation">
                <div className="confirmation-item">
                  <span>Order ID:</span>
                  <strong>{order.order_id}</strong>
                </div>
                <div className="confirmation-item">
                  <span>Amount Paid:</span>
                  <strong className="amount">₹{order.total_amount?.toFixed(2)}</strong>
                </div>
                {transactionId && (
                  <div className="confirmation-item">
                    <span>Transaction ID:</span>
                    <strong>{transactionId}</strong>
                  </div>
                )}
              </div>
            )}

            <p className="redirect-message">Redirecting to your orders...</p>
          </div>
        )}

        {paymentStatus === 'failed' && (
          <div className="payment-failed">
            <div className="error-icon">✕</div>
            <h1>Payment Failed</h1>
            <p>{error}</p>

            {order && (
              <div className="payment-details">
                <div className="detail-item">
                  <span>Order ID:</span>
                  <strong>{order.order_id}</strong>
                </div>
                <div className="detail-item">
                  <span>Amount:</span>
                  <strong className="amount">₹{order.total_amount?.toFixed(2)}</strong>
                </div>
              </div>
            )}

            <div className="failed-actions">
              <button
                className="btn-primary"
                onClick={handleRetryPayment}
              >
                Retry Payment
              </button>
              <button
                className="btn-secondary"
                onClick={() => navigate('/cart')}
              >
                Back to Cart
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PaymentPage;
