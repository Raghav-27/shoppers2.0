import React, { useState, useEffect } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import './ProductCard.css';

const ProductCard = ({ product, isSignedIn, user, userLists, onUpdateLists }) => {
  const { isDarkMode } = useTheme();
  const [wishlistStatus, setWishlistStatus] = useState('idle');
  const [cartStatus, setCartStatus] = useState('idle');
  const [compareStatus, setCompareStatus] = useState('idle');
  const getSafeId = (item) =>
  item?.product_id ||
  item?.id ||
  item?.code ||
  item?.productId ||
  item?.itemId;

  
  useEffect(() => {
    checkInitialStatus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [product, isSignedIn, userLists]);

 const checkInitialStatus = () => {
  if (!isSignedIn || !userLists) return;

  const productId = getProductId();
  if (!productId) return;

  setWishlistStatus(
    userLists.wishlist?.some(item => String(getSafeId(item)) === String(productId))
      ? 'added'
      : 'idle'
  );

  setCartStatus(
    userLists.cart?.some(item => String(getSafeId(item)) === String(productId))
      ? 'added'
      : 'idle'
  );

  setCompareStatus(
    userLists.compare?.some(item => String(getSafeId(item)) === String(productId))
      ? 'added'
      : 'idle'
  );
};
  const apiCall = async (endpoint, method, data) => {
    const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
    const response = await fetch(`${apiUrl}${endpoint}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(data)
    });

    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return await response.json();
  };

  const getProductId = () => {
    return product.product_id || product.id || product.code || product.productId || product.itemId;
  };
  const getproduct =() =>{
    return product
  };

const handleListAction = async (listType, status, setStatus, endpoint) => {
  if (!isSignedIn) {
    alert(`Please sign in to add items to your ${listType}`);
    return;
  }

  const product = getproduct(); // get FULL product
  if (!product) {
    alert(`Unable to add this product to ${listType}`);
    return;
  }

  try {
    if (status === 'added') {
      setStatus('removing');
      await apiCall(endpoint, 'DELETE', {
        product_data: product
      });
      setStatus('idle');
    } else {
      setStatus('adding');
      await apiCall(endpoint, 'POST', {
        product_data: product
      });
      setStatus('added');
    }

    if (onUpdateLists) await onUpdateLists();
  } catch (error) {
    console.error(`${listType} error:`, error);
    setStatus('idle');
    alert(`Failed to update ${listType}. Please try again.`);
  }
};

  // Render the appropriate card based on platform
  const platform = product.source_platform?.toLowerCase();
  
  // Handle seller products
  if (product.isSellerProduct) {
    return <SellerProductCard {...{ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }} />;
  }
  
  switch (platform) {
    case 'meesho':
      return <MeeshoCard {...{ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }} />;
    case 'ajio':
      return <AjioCard {...{ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }} />;
    case 'shopsy':
      return <ShopsyCard {...{ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }} />;
    case 'myntra':
      return <MyntraCard {...{ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }} />;
    case 'flipkart':
      return <FlipkartCard {...{ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }} />;
    default:
      return <GenericCard {...{ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }} />;
  }
};

// Meesho Product Card
const MeeshoCard = ({ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }) => {
  const image = product.images?.[0] || product.product_images?.[0]?.url || '/placeholder-image.svg';
  const title = product.name || product.description || 'Product';
  const price = product.min_catalog_price || product.min_product_price || 0;
  const originalPrice = product.max_product_price;
  const discount = originalPrice && price ? Math.round(((originalPrice - price) / originalPrice) * 100) : 0;
  const rating = product.catalog_reviews_summary?.average_rating || 0;
  const ratingCount = product.catalog_reviews_summary?.rating_count || 0;
  const url = product.product_id ? `https://www.meesho.com/s/p/${product.product_id}` : '#';

  return (
    <div className={`product-card meesho-card ${isDarkMode ? 'dark' : ''}`}>
      <div className="product-image-container">
        <img src={image} alt={title} className="product-image" onError={(e) => e.target.src = '/placeholder-image.svg'} />
      </div>
      <div className="product-info">
        <h3 className="product-title">{title}</h3>
        <div className="product-pricing">
          <span className="current-price">₹{price}</span>
          {originalPrice && originalPrice > price && (
            <>
              <span className="original-price">₹{originalPrice}</span>
              <span className="discount-badge">{discount}% off</span>
            </>
          )}
        </div>
        {rating > 0 && (
          <div className="product-rating">
            <span className="stars">{renderStars(rating)}</span>
            <span className="rating-text">{rating.toFixed(1)} ({ratingCount.toLocaleString()})</span>
          </div>
        )}
      </div>
      <div className="product-actions">
        <ActionButton 
          icon={wishlistStatus === 'added' ? '❤️' : '🤍'}
          onClick={() => handleListAction('wishlist', wishlistStatus, setWishlistStatus, '/api/user/wishlist')}
          disabled={!isSignedIn || wishlistStatus === 'adding' || wishlistStatus === 'removing'}
          title={wishlistStatus === 'added' ? 'Remove from Wishlist' : 'Add to Wishlist'}
        />
        <ActionButton 
          icon={cartStatus === 'added' ? '🛍️' : '🛒'}
          onClick={() => handleListAction('cart', cartStatus, setCartStatus, '/api/user/cart')}
          disabled={!isSignedIn || cartStatus === 'adding' || cartStatus === 'removing'}
          title={cartStatus === 'added' ? 'Remove from Cart' : 'Add to Cart'}
          variant={cartStatus === 'added' ? 'added' : ''}
        />
        <ActionButton 
          icon={compareStatus === 'added' ? '🏷️' : '⚖️'}
          onClick={() => handleListAction('compare', compareStatus, setCompareStatus, '/api/user/compare')}
          disabled={!isSignedIn || compareStatus === 'adding' || compareStatus === 'removing'}
          title={compareStatus === 'added' ? 'Remove from Compare' : 'Add to Compare'}
          variant={compareStatus === 'added' ? 'added' : ''}
        />
        <ActionButton 
          text={`View on ${platformDisplayNames.meesho}`}
          onClick={() => window.open(url, '_blank')}
          primary
        />
      </div>
    </div>
  );
};

// Ajio Product Card
const AjioCard = ({ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }) => {
  const image = product.fnlColorVariantData?.outfitPictureURL || product.images?.[0]?.url || '/placeholder-image.svg';
  const title = product.name || 'Product';
  const price = product.price || 0;
  const originalPrice = product.original_price || product.wasPriceData?.value;
  const discount = product.discount_percent || 0;
  const rating = product.rating || 0;
  const ratingCount = product.num_ratings || product.ratingCount || 0;
  const url = product.product_url || '#';

  return (
    <div className={`product-card ajio-card ${isDarkMode ? 'dark' : ''}`}>
      <div className="product-image-container">
        <img src={image} alt={title} className="product-image" onError={(e) => e.target.src = '/placeholder-image.svg'} />
      </div>
      <div className="product-info">
        <h3 className="product-title">{title}</h3>
        <div className="product-pricing">
          <span className="current-price">₹{price.toLocaleString()}</span>
          {originalPrice && originalPrice > price && (
            <>
              <span className="original-price">₹{originalPrice.toLocaleString()}</span>
              <span className="discount-badge">{Math.round(discount)}% off</span>
            </>
          )}
        </div>
        {rating > 0 && (
          <div className="product-rating">
            <span className="stars">{renderStars(rating)}</span>
            <span className="rating-text">{rating.toFixed(1)} ({ratingCount.toLocaleString()})</span>
          </div>
        )}
      </div>
      <div className="product-actions">
        <ActionButton 
          icon={wishlistStatus === 'added' ? '❤️' : '🤍'}
          onClick={() => handleListAction('wishlist', wishlistStatus, setWishlistStatus, '/api/user/wishlist')}
          disabled={!isSignedIn || wishlistStatus === 'adding' || wishlistStatus === 'removing'}
          title={wishlistStatus === 'added' ? 'Remove from Wishlist' : 'Add to Wishlist'}
        />
        <ActionButton 
          icon={cartStatus === 'added' ? '🛍️' : '🛒'}
          onClick={() => handleListAction('cart', cartStatus, setCartStatus, '/api/user/cart')}
          disabled={!isSignedIn || cartStatus === 'adding' || cartStatus === 'removing'}
          title={cartStatus === 'added' ? 'Remove from Cart' : 'Add to Cart'}
          variant={cartStatus === 'added' ? 'added' : ''}
        />
        <ActionButton 
          icon={compareStatus === 'added' ? '🏷️' : '⚖️'}
          onClick={() => handleListAction('compare', compareStatus, setCompareStatus, '/api/user/compare')}
          disabled={!isSignedIn || compareStatus === 'adding' || compareStatus === 'removing'}
          title={compareStatus === 'added' ? 'Remove from Compare' : 'Add to Compare'}
          variant={compareStatus === 'added' ? 'added' : ''}
        />
        <ActionButton 
          text={`View on ${platformDisplayNames.ajio}`}
          onClick={() => window.open(url, '_blank')}
          primary
        />
      </div>
    </div>
  );
};

// Shopsy Product Card
const ShopsyCard = ({ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }) => {
  const constructImageUrl = (templateUrl, width = 300, height = 300, quality = 50) => {
    let url = decodeURIComponent(templateUrl);
    return url.replace('{@width}', width).replace('{@height}', height).replace('{@quality}', quality);
  };
  
  const image = product.media?.images?.[0]?.url ? constructImageUrl(product.media.images[0].url) : '/placeholder-image.svg';
  const title = product.titles?.title || 'Product';
  const price = product.pricing?.finalPrice?.value || 0;
  const originalPrice = product.pricing?.mrp?.value;
  const discount = product.pricing?.totalDiscount || 0;
  const rating = product.rating?.average || 0;
  const ratingCount = product.rating?.count || 0;
  const url = product.product_url || product.smartUrl || '#';

  return (
    <div className={`product-card shopsy-card ${isDarkMode ? 'dark' : ''}`}>
      <div className="product-image-container">
        <img src={image} alt={title} className="product-image" onError={(e) => e.target.src = '/placeholder-image.svg'} />
      </div>
      <div className="product-info">
        <h3 className="product-title">{title}</h3>
        <div className="product-pricing">
          <span className="current-price">₹{price.toLocaleString()}</span>
          {originalPrice && originalPrice > price && (
            <>
              <span className="original-price">₹{originalPrice.toLocaleString()}</span>
              <span className="discount-badge">{Math.round(discount)}% off</span>
            </>
          )}
        </div>
        {rating > 0 && (
          <div className="product-rating">
            <span className="stars">{renderStars(rating)}</span>
            <span className="rating-text">{rating.toFixed(1)} ({ratingCount.toLocaleString()})</span>
          </div>
        )}
      </div>
      <div className="product-actions">
        <ActionButton 
          icon={wishlistStatus === 'added' ? '❤️' : '🤍'}
          onClick={() => handleListAction('wishlist', wishlistStatus, setWishlistStatus, '/api/user/wishlist')}
          disabled={!isSignedIn || wishlistStatus === 'adding' || wishlistStatus === 'removing'}
          title={wishlistStatus === 'added' ? 'Remove from Wishlist' : 'Add to Wishlist'}
        />
        <ActionButton 
          icon={cartStatus === 'added' ? '🛍️' : '🛒'}
          onClick={() => handleListAction('cart', cartStatus, setCartStatus, '/api/user/cart')}
          disabled={!isSignedIn || cartStatus === 'adding' || cartStatus === 'removing'}
          title={cartStatus === 'added' ? 'Remove from Cart' : 'Add to Cart'}
          variant={cartStatus === 'added' ? 'added' : ''}
        />
        <ActionButton 
          icon={compareStatus === 'added' ? '🏷️' : '⚖️'}
          onClick={() => handleListAction('compare', compareStatus, setCompareStatus, '/api/user/compare')}
          disabled={!isSignedIn || compareStatus === 'adding' || compareStatus === 'removing'}
          title={compareStatus === 'added' ? 'Remove from Compare' : 'Add to Compare'}
          variant={compareStatus === 'added' ? 'added' : ''}
        />
        <ActionButton 
          text={`View on ${platformDisplayNames.shopsy}`}
          onClick={() => window.open(url, '_blank')}
          primary
        />
      </div>
    </div>
  );
};

// Myntra Product Card
const MyntraCard = ({ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }) => {
  const image = product.searchImage || product.images?.[0]?.src || '/placeholder-image.svg';
  const title = product.title || product.productName || 'Product';
  const price = product.price || 0;
  const originalPrice = product.mrp;
  const discount = originalPrice && price ? Math.round(((originalPrice - price) / originalPrice) * 100) : product.discount || 0;
  const rating = product.rating || 0;
  const ratingCount = product.ratingCount || 0;
  const url = product.product_url || `https://www.myntra.com/${product.landingPageUrl}` || '#';

  return (
    <div className={`product-card myntra-card ${isDarkMode ? 'dark' : ''}`}>
      <div className="product-image-container">
        <img src={image} alt={title} className="product-image" onError={(e) => e.target.src = '/placeholder-image.svg'} />
      </div>
      <div className="product-info">
        <h3 className="product-title">{title}</h3>
        <div className="product-pricing">
          <span className="current-price">₹{price.toLocaleString()}</span>
          {originalPrice && originalPrice > price && (
            <>
              <span className="original-price">₹{originalPrice.toLocaleString()}</span>
              <span className="discount-badge">{discount}% off</span>
            </>
          )}
        </div>
        {rating > 0 && (
          <div className="product-rating">
            <span className="stars">{renderStars(rating)}</span>
            <span className="rating-text">{rating.toFixed(1)} ({ratingCount.toLocaleString()})</span>
          </div>
        )}
      </div>
      <div className="product-actions">
        <ActionButton 
          icon={wishlistStatus === 'added' ? '❤️' : '🤍'}
          onClick={() => handleListAction('wishlist', wishlistStatus, setWishlistStatus, '/api/user/wishlist')}
          disabled={!isSignedIn || wishlistStatus === 'adding' || wishlistStatus === 'removing'}
          title={wishlistStatus === 'added' ? 'Remove from Wishlist' : 'Add to Wishlist'}
        />
        <ActionButton 
          icon={cartStatus === 'added' ? '🛍️' : '🛒'}
          onClick={() => handleListAction('cart', cartStatus, setCartStatus, '/api/user/cart')}
          disabled={!isSignedIn || cartStatus === 'adding' || cartStatus === 'removing'}
          title={cartStatus === 'added' ? 'Remove from Cart' : 'Add to Cart'}
          variant={cartStatus === 'added' ? 'added' : ''}
        />
        <ActionButton 
          icon={compareStatus === 'added' ? '🏷️' : '⚖️'}
          onClick={() => handleListAction('compare', compareStatus, setCompareStatus, '/api/user/compare')}
          disabled={!isSignedIn || compareStatus === 'adding' || compareStatus === 'removing'}
          title={compareStatus === 'added' ? 'Remove from Compare' : 'Add to Compare'}
          variant={compareStatus === 'added' ? 'added' : ''}
        />
        <ActionButton 
          text={`View on ${platformDisplayNames.myntra}`}
          onClick={() => window.open(url, '_blank')}
          primary
        />
      </div>
    </div>
  );
};

// Flipkart Product Card
const FlipkartCard = ({ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }) => {
  const constructImageUrl = (templateUrl, width = 300, height = 300, quality = 50) => {
    let url = decodeURIComponent(templateUrl);
    return url.replace('{@width}', width).replace('{@height}', height).replace('{@quality}', quality);
  };
  
  const image = product.media?.images?.[0]?.url ? constructImageUrl(product.media.images[0].url) : '/placeholder-image.svg';
  const title = product.name || product.raw_data?.titles?.title || 'Product';
  const price = product.pricing?.finalPrice?.value || 0;
  const originalPrice = product.pricing?.mrp?.value;
  const discount = product.pricing?.totalDiscount || 0;
  const rating = product.rating?.average || 0;
  const ratingCount = product.rating?.count || 0;
  const url = product.url || '#';

  return (
    <div className={`product-card flipkart-card ${isDarkMode ? 'dark' : ''}`}>
      <div className="product-image-container">
        <img src={image} alt={title} className="product-image" onError={(e) => e.target.src = '/placeholder-image.svg'} />
      </div>
      <div className="product-info">
        <h3 className="product-title">{title}</h3>
        <div className="product-pricing">
          <span className="current-price">₹{price.toLocaleString()}</span>
          {originalPrice && originalPrice > price && (
            <>
              <span className="original-price">₹{originalPrice.toLocaleString()}</span>
              <span className="discount-badge">{Math.round(discount)}% off</span>
            </>
          )}
        </div>
        {rating > 0 && (
          <div className="product-rating">
            <span className="stars">{renderStars(rating)}</span>
            <span className="rating-text">{rating.toFixed(1)} ({ratingCount.toLocaleString()})</span>
          </div>
        )}
      </div>
      <div className="product-actions">
        <ActionButton 
          icon={wishlistStatus === 'added' ? '❤️' : '🤍'}
          onClick={() => handleListAction('wishlist', wishlistStatus, setWishlistStatus, '/api/user/wishlist')}
          disabled={!isSignedIn || wishlistStatus === 'adding' || wishlistStatus === 'removing'}
          title={wishlistStatus === 'added' ? 'Remove from Wishlist' : 'Add to Wishlist'}
        />
        <ActionButton 
          icon={cartStatus === 'added' ? '🛍️' : '🛒'}
          onClick={() => handleListAction('cart', cartStatus, setCartStatus, '/api/user/cart')}
          disabled={!isSignedIn || cartStatus === 'adding' || cartStatus === 'removing'}
          title={cartStatus === 'added' ? 'Remove from Cart' : 'Add to Cart'}
          variant={cartStatus === 'added' ? 'added' : ''}
        />
        <ActionButton 
          icon={compareStatus === 'added' ? '🏷️' : '⚖️'}
          onClick={() => handleListAction('compare', compareStatus, setCompareStatus, '/api/user/compare')}
          disabled={!isSignedIn || compareStatus === 'adding' || compareStatus === 'removing'}
          title={compareStatus === 'added' ? 'Remove from Compare' : 'Add to Compare'}
          variant={compareStatus === 'added' ? 'added' : ''}
        />
        <ActionButton 
          text={`View on ${platformDisplayNames.flipkart}`}
          onClick={() => window.open(url, '_blank')}
          primary
        />
      </div>
    </div>
  );
};

// Generic fallback card
const GenericCard = ({ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }) => {
  return (
    <div className={`product-card generic-card ${isDarkMode ? 'dark' : ''}`}>
      <div className="product-info">
        <h3 className="product-title">Product from {product.source_platform || 'Unknown Platform'}</h3>
        <p>Data structure not recognized</p>
      </div>
    </div>
  );
};

// Seller Product Card (for Shoppers Marketplace)
const SellerProductCard = ({ product, isDarkMode, wishlistStatus, cartStatus, compareStatus, handleListAction, setWishlistStatus, setCartStatus, setCompareStatus, isSignedIn }) => {
  const image = product.image || product.image_url || '/placeholder-image.svg';
  const title = product.name || product.title || 'Product';
  const price = parseFloat(product.price) || 0;
  const stock = parseInt(product.stock) || 0;
  const category = product.category || '';
  const sellerName = product.seller_name || 'Shoppers Seller';
  const storeName = product.store_name || '';
  const productId = product.product_id || product.id;
  
  const handleViewProduct = () => {
    window.location.href = `/product/seller/${productId}`;
  };

  return (
    <div className={`product-card seller-product-card ${isDarkMode ? 'dark' : ''}`}>
      <div className="seller-badge">🏪 Shoppers Marketplace</div>
      <div className="product-image-container" onClick={handleViewProduct} style={{ cursor: 'pointer' }}>
        <img src={image} alt={title} className="product-image" onError={(e) => e.target.src = '/placeholder-image.svg'} />
      </div>
      <div className="product-info">
        <h3 className="product-title" onClick={handleViewProduct} style={{ cursor: 'pointer' }}>{title}</h3>
        <div className="product-pricing">
          <span className="current-price">₹{price.toFixed(2)}</span>
          <span className={`stock-badge ${stock > 0 ? 'in-stock' : 'out-of-stock'}`}>
            {stock > 0 ? `${stock} in stock` : 'Out of stock'}
          </span>
        </div>
        {category && <div className="product-category">{category}</div>}
        <div className="seller-info">
          <div className="seller-name">by {sellerName}</div>
          {storeName && <div className="store-name">📍 {storeName}</div>}
        </div>
        <div className="product-actions">
          <ActionButton
            icon={wishlistStatus === 'added' ? '❤️' : '🤍'}
            onClick={() => handleListAction('wishlist', wishlistStatus, setWishlistStatus, '/api/user/wishlist')}
            disabled={!isSignedIn || wishlistStatus === 'adding' || wishlistStatus === 'removing'}
            title={wishlistStatus === 'added' ? 'Remove from wishlist' : 'Add to wishlist'}
          />
          <ActionButton
            icon={cartStatus === 'added' ? '🛒✓' : '🛒'}
            onClick={() => handleListAction('cart', cartStatus, setCartStatus, '/api/user/cart')}
            disabled={!isSignedIn || cartStatus === 'adding' || cartStatus === 'removing' || stock === 0}
            title={cartStatus === 'added' ? 'Remove from cart' : 'Add to cart'}
          />
          <ActionButton
            icon={compareStatus === 'added' ? '⚖️✓' : '⚖️'}
            onClick={() => handleListAction('compare', compareStatus, setCompareStatus, '/api/user/compare')}
            disabled={!isSignedIn || compareStatus === 'adding' || compareStatus === 'removing'}
            title={compareStatus === 'added' ? 'Remove from comparison' : 'Add to comparison'}
          />
        </div>
        <button className="view-product-btn primary" onClick={handleViewProduct}>
          View Details
        </button>
      </div>
    </div>
  );
};

// Helper component for action buttons
const ActionButton = ({ icon, text, onClick, disabled, title, primary, variant }) => (
  <button 
    className={`action-btn ${primary ? 'primary' : ''} ${variant || ''}`}
    onClick={onClick}
    disabled={disabled}
    title={title}
  >
    {icon || text}
  </button>
);

// Helper function to render star ratings
const renderStars = (rating) => {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  const stars = [];
  
  for (let i = 0; i < fullStars; i++) {
    stars.push('★');
  }
  if (hasHalfStar) {
    stars.push('⯨');
  }
  while (stars.length < 5) {
    stars.push('☆');
  }
  
  return stars.join('');
};

const platformDisplayNames = {
  meesho: 'Meesho',
  amazon: 'Amazon',
  flipkart: 'Flipkart',
  myntra: 'Myntra',
  shopsy: 'Shopsy',
  ajio: 'Ajio'
};

export default ProductCard;