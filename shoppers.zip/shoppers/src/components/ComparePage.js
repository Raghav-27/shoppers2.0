// ComparePage.jsx
import React, { useState, useEffect } from 'react';
import ProductCard from './ProductCard';
import { useTheme } from '../contexts/ThemeContext';
import './ComparePage.css'; // Create this CSS file (similar layout to WishlistPage.css)

const ComparePage = ({ user, userLists, onUpdateLists, isSignedIn }) => {
  const { isDarkMode } = useTheme();
  const [compareList, setCompareList] = useState([]);

  // Sync compare list from userLists (assuming you store it as 'compare')
  useEffect(() => {
    if (userLists?.compare && Array.isArray(userLists.compare)) {
      setCompareList(userLists.compare);
    }
  }, [userLists]);

  // Remove item from compare list
  const handleRemove = (productId) => {
    const updatedCompareList = compareList.filter(item => {
      const id = item.id || item.product_id || item.code;
      return id !== productId;
    });
    setCompareList(updatedCompareList);
    onUpdateLists?.('compare', updatedCompareList);
  };

  // Empty state
  if (compareList.length === 0) {
    return (
      <div className={`compare-empty ${isDarkMode ? 'dark' : 'light'}`}>
        <div className="empty-content">
          <span className="compare-icon">Compare Arrows</span>
          <h2>No Products to Compare</h2>
          <p>Add up to 4 products to see how they stack up!</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`compare-page ${isDarkMode ? 'dark' : 'light'}`}>

      {/* Responsive Grid - Optimized for side-by-side comparison */}
      <div className={`compare-grid compare-grid-${compareList.length}`}>
        {compareList.map((product) => {
          const productId = product.id || product.product_id || product.code;

          return (
            <div key={productId} className="compare-grid-item">
              <button
                onClick={() => handleRemove(productId)}
                className="remove-from-compare"
                aria-label="Remove from comparison"
              >
                Remove
              </button>
              <ProductCard
                product={product}
                isSignedIn={isSignedIn}
                user={user}
                userLists={userLists}
                onUpdateLists={onUpdateLists}
                isDarkMode={isDarkMode}
                showCompareRemove={true}
                onRemoveFromCompare={() => handleRemove(productId)}
              />
            </div>
          );
        })}
      </div>

      {/* Optional: Add a comparison table below for specs (future enhancement) */}
      {compareList.length > 1 && (
        <div className="comparison-table-placeholder">
          <p>Feature comparison table coming soon...</p>
        </div>
      )}
    </div>
  );
};

export default ComparePage;