import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './SellerProductDetail.css';

const SellerProductDetail = ({ isSignedIn, user, userLists, onUpdateLists }) => {
  const { productId } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const fetchProductDetails = async () => {
      try {
        const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
        const response = await fetch(`${apiUrl}/api/seller/product/${productId}`, {
          credentials: 'include'
        });

        if (!response.ok) throw new Error('Failed to fetch product');

        const data = await response.json();
        setProduct(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchProductDetails();
  }, [productId]);

  const handleAddToCart = async () => {
    if (!isSignedIn) {
      alert('Please sign in to add items to cart');
      navigate('/signin');
      return;
    }

    if (product.stock < quantity) {
      alert('Not enough stock available');
      return;
    }

    try {
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const response = await fetch(`${apiUrl}/api/user/cart`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          product_data: {
            id: `seller_${product.seller.id}_${productId}`,
            product_id: productId,
            name: product.name,
            price: product.price,
            image_url: product.images[0],
            platform: 'Shoppers Marketplace',
            isSellerProduct: true,
            seller_name: product.seller.business_name,
            store_name: product.store?.name,
            quantity: quantity,
            stock: product.stock
          }
        })
      });

      if (response.ok) {
        await onUpdateLists();
        alert('Added to cart successfully!');
      }
    } catch (error) {
      console.error('Error adding to cart:', error);
      alert('Failed to add to cart');
    }
  };

  if (loading) {
    return (
      <div className="seller-product-detail">
        <div className="loading-container">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="seller-product-detail">
        <div className="error-container">Error: {error}</div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="seller-product-detail">
        <div className="not-found">Product not found</div>
      </div>
    );
  }

  return (
    <div className="seller-product-detail">
      <div className="product-detail-container">
        <div className="product-images">
          <div className="main-image">
            <img 
              src={product.images[selectedImage]} 
              alt={product.name}
              onError={(e) => e.target.src = '/placeholder-image.svg'}
            />
          </div>
          {product.images.length > 1 && (
            <div className="image-thumbnails">
              {product.images.map((img, index) => (
                <img
                  key={index}
                  src={img}
                  alt={`${product.name} ${index + 1}`}
                  className={selectedImage === index ? 'active' : ''}
                  onClick={() => setSelectedImage(index)}
                  onError={(e) => e.target.src = '/placeholder-image.svg'}
                />
              ))}
            </div>
          )}
        </div>

        <div className="product-details">
          <h1>{product.name}</h1>
          
          <div className="product-meta">
            {product.category && <span className="category">{product.category}</span>}
            <span className={`stock ${product.stock > 0 ? 'in-stock' : 'out-of-stock'}`}>
              {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
            </span>
          </div>

          <div className="price-section">
            <h2 className="price">₹{product.price.toFixed(2)}</h2>
          </div>

          {product.description && (
            <div className="description">
              <h3>Description</h3>
              <p>{product.description}</p>
            </div>
          )}

          <div className="seller-info-box">
            <h3>Seller Information</h3>
            <p><strong>{product.seller.business_name}</strong></p>
            {product.store && (
              <p>📍 {product.store.name}</p>
            )}
            {product.seller.email && <p>📧 {product.seller.email}</p>}
            {product.seller.phone && <p>📞 {product.seller.phone}</p>}
          </div>

          {product.stock > 0 && (
            <div className="purchase-section">
              <div className="quantity-selector">
                <label>Quantity:</label>
                <button onClick={() => setQuantity(Math.max(1, quantity - 1))}>-</button>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, Math.min(product.stock, parseInt(e.target.value) || 1)))}
                  min="1"
                  max={product.stock}
                />
                <button onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}>+</button>
              </div>

              <button className="add-to-cart-btn" onClick={handleAddToCart}>
                Add to Cart
              </button>
            </div>
          )}

          {product.stock === 0 && (
            <div className="out-of-stock-message">
              <p>This product is currently out of stock</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SellerProductDetail;
