import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../contexts/ThemeContext';
import './CheckoutPage.css';

const CheckoutPage = ({ isSignedIn, user, userLists, onUpdateLists }) => {
  const navigate = useNavigate();
  const { isDarkMode } = useTheme();
  const [loading, setLoading] = useState(false);
  const [addresses, setAddresses] = useState([]);
  const [selectedAddressId, setSelectedAddressId] = useState(null);
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [sellerItems, setSellerItems] = useState([]);
  const [formData, setFormData] = useState({
    label: '',
    phone: '',
    street: '',
    city: '',
    state: '',
    postal_code: '',
    country: '',
    is_default: false
  });
  const [formError, setFormError] = useState('');

  useEffect(() => {
    if (!isSignedIn) {
      navigate('/signin');
      return;
    }

    // Filter cart items to only include seller products
    // Update this every time userLists changes to get the latest quantities
    const sellerProducts = (userLists?.cart || []).filter(
      item => item.source === 'seller' || item.platform === 'Seller'
    );

    if (sellerProducts.length === 0) {
      alert('No seller products in cart');
      navigate('/cart');
      return;
    }

    setSellerItems(sellerProducts);
    
    // Fetch user addresses
    fetchAddresses();
  }, [isSignedIn, user, userLists, navigate]);

  const fetchAddresses = async () => {
    try {
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const response = await fetch(`${apiUrl}/api/user/addresses`, {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        setAddresses(data.addresses || []);
        
        // Auto-select default address or first address
        const defaultAddr = data.addresses?.find(addr => addr.is_default);
        if (defaultAddr) {
          setSelectedAddressId(defaultAddr.id);
        } else if (data.addresses && data.addresses.length > 0) {
          setSelectedAddressId(data.addresses[0].id);
        }
      }
    } catch (error) {
      console.error('Error fetching addresses:', error);
    }
  };

  const calculateTotal = () => {
    return sellerItems.reduce((total, item) => {
      const price = parseFloat(item.price) || 0;
      const quantity = parseInt(item.quantity) || 1;
      return total + (price * quantity);
    }, 0);
  };

  const handleAddressFormChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleAddAddress = async (e) => {
    e.preventDefault();
    setFormError('');

    // Validation
    if (!formData.label.trim() || !formData.phone.trim() || !formData.street.trim() ||
        !formData.city.trim() || !formData.state.trim() || !formData.postal_code.trim() ||
        !formData.country.trim()) {
      setFormError('All fields are required');
      return;
    }

    if (!/^\d{10}$/.test(formData.phone.trim())) {
      setFormError('Phone number must be 10 digits');
      return;
    }

    setLoading(true);

    try {
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const response = await fetch(`${apiUrl}/api/user/addresses`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setAddresses([...addresses, data.address]);
        setSelectedAddressId(data.address.id);
        setShowAddressForm(false);
        setFormData({
          label: '',
          phone: '',
          street: '',
          city: '',
          state: '',
          postal_code: '',
          country: '',
          is_default: false
        });
      } else {
        setFormError(data.detail || 'Failed to add address');
      }
    } catch (error) {
      console.error('Error adding address:', error);
      setFormError('Failed to add address. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handlePlaceOrder = async () => {
    if (!selectedAddressId) {
      alert('Please select or add a delivery address');
      return;
    }

    const selectedAddr = addresses.find(addr => addr.id === selectedAddressId);
    if (!selectedAddr) {
      alert('Invalid address selected');
      return;
    }

    setLoading(true);

    try {
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      
      // Prepare order items - ensure seller_id and product_id are correctly mapped
      const items = sellerItems.map(item => {
        // Extract seller_id (required for seller to see orders)
        // For seller products from the search API, this should be in seller_id field
        const sellerId = item.seller_id || item.seller || '1';
        
        // Extract product_id (could be in different fields)
        const productId = item.product_id || item.id || item.code || '';
        
        return {
          product_id: productId,
          seller_id: sellerId,
          seller_name: item.seller_name || 'Shoppers Seller',
          product_name: item.name || item.title || 'Product',
          price: parseFloat(item.price) || 0,
          quantity: parseInt(item.quantity) || 1,
          image: item.image || item.image_url || '',
          category: item.category || ''
        };
      });

      const response = await fetch(`${apiUrl}/api/orders/create`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          phone: selectedAddr.phone,
          address: `${selectedAddr.street}, ${selectedAddr.city}, ${selectedAddr.state} ${selectedAddr.postal_code}, ${selectedAddr.country}`,
          items: items,
          payment_method: paymentMethod
        })
      });

      const data = await response.json();

      if (response.ok && data.success) {
        const orderId = data.order.order_id;
        
        // Clear cart items (only seller products)
        for (const item of sellerItems) {
          try {
            await fetch(`${apiUrl}/api/user/cart`, {
              method: 'DELETE',
              headers: {
                'Content-Type': 'application/json',
              },
              credentials: 'include',
              body: JSON.stringify({
                product_data: item
              })
            });
          } catch (error) {
            console.error('Error removing item from cart:', error);
          }
        }

        if (onUpdateLists) await onUpdateLists();

        // If online payment, redirect to payment page
        if (paymentMethod === 'online') {
          navigate(`/payment/${orderId}`, { state: { order: data.order } });
        } else {
          // For COD, go to order history
          alert('Order placed successfully! Order ID: ' + orderId);
          navigate('/orders');
        }
      } else {
        alert(data.detail || 'Failed to place order');
      }
    } catch (error) {
      console.error('Error placing order:', error);
      alert('Failed to place order. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (!isSignedIn) {
    return null;
  }

  return (
    <div className={`checkout-page ${isDarkMode ? 'dark' : ''}`}>
      <div className="checkout-container">
        <h1>Checkout</h1>

        {sellerItems.length === 0 ? (
          <div className="empty-checkout">
            <p>No seller products to checkout</p>
            <button onClick={() => navigate('/cart')}>Go to Cart</button>
          </div>
        ) : (
          <>
            <div className="checkout-sections">
              {/* Delivery Address Section */}
              <div className="checkout-section">
                <h2>Delivery Address</h2>
                
                {addresses.length > 0 && !showAddressForm && (
                  <div className="addresses-list">
                    {addresses.map(addr => (
                      <label key={addr.id} className="address-option">
                        <input
                          type="radio"
                          name="address"
                          value={addr.id}
                          checked={selectedAddressId === addr.id}
                          onChange={(e) => setSelectedAddressId(e.target.value)}
                        />
                        <div className="address-info">
                          <h4>{addr.label}</h4>
                          <p>{addr.street}</p>
                          <p>{addr.city}, {addr.state} {addr.postal_code}</p>
                          <p>{addr.country}</p>
                          <p className="phone">📱 {addr.phone}</p>
                          {addr.is_default && <span className="default-badge">Default</span>}
                        </div>
                      </label>
                    ))}
                  </div>
                )}

                {!showAddressForm ? (
                  <button 
                    className="btn-add-address"
                    onClick={() => setShowAddressForm(true)}
                  >
                    + Add New Address
                  </button>
                ) : (
                  <form onSubmit={handleAddAddress} className="address-form">
                    <div className="form-row">
                      <div className="form-group">
                        <label htmlFor="label">Label *</label>
                        <input
                          type="text"
                          id="label"
                          name="label"
                          value={formData.label}
                          onChange={handleAddressFormChange}
                          placeholder="e.g., Home, Office"
                          required
                        />
                      </div>
                      <div className="form-group">
                        <label htmlFor="phone">Phone Number *</label>
                        <input
                          type="tel"
                          id="phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleAddressFormChange}
                          placeholder="10 digit phone number"
                          maxLength="10"
                          required
                        />
                      </div>
                    </div>

                    <div className="form-group full-width">
                      <label htmlFor="street">Street Address *</label>
                      <input
                        type="text"
                        id="street"
                        name="street"
                        value={formData.street}
                        onChange={handleAddressFormChange}
                        placeholder="House no., Building name"
                        required
                      />
                    </div>

                    <div className="form-row">
                      <div className="form-group">
                        <label htmlFor="city">City *</label>
                        <input
                          type="text"
                          id="city"
                          name="city"
                          value={formData.city}
                          onChange={handleAddressFormChange}
                          placeholder="City"
                          required
                        />
                      </div>
                      <div className="form-group">
                        <label htmlFor="state">State *</label>
                        <input
                          type="text"
                          id="state"
                          name="state"
                          value={formData.state}
                          onChange={handleAddressFormChange}
                          placeholder="State"
                          required
                        />
                      </div>
                    </div>

                    <div className="form-row">
                      <div className="form-group">
                        <label htmlFor="postal_code">Postal Code *</label>
                        <input
                          type="text"
                          id="postal_code"
                          name="postal_code"
                          value={formData.postal_code}
                          onChange={handleAddressFormChange}
                          placeholder="Postal code"
                          required
                        />
                      </div>
                      <div className="form-group">
                        <label htmlFor="country">Country *</label>
                        <input
                          type="text"
                          id="country"
                          name="country"
                          value={formData.country}
                          onChange={handleAddressFormChange}
                          placeholder="Country"
                          required
                        />
                      </div>
                    </div>

                    <div className="form-group checkbox">
                      <label htmlFor="is_default">
                        <input
                          type="checkbox"
                          id="is_default"
                          name="is_default"
                          checked={formData.is_default}
                          onChange={handleAddressFormChange}
                        />
                        <span>Set as default address</span>
                      </label>
                    </div>

                    {formError && <p className="form-error">{formError}</p>}

                    <div className="form-actions">
                      <button 
                        type="button"
                        className="btn-secondary"
                        onClick={() => {
                          setShowAddressForm(false);
                          setFormError('');
                        }}
                      >
                        Cancel
                      </button>
                      <button 
                        type="submit"
                        className="btn-primary"
                        disabled={loading}
                      >
                        {loading ? 'Adding...' : 'Add Address'}
                      </button>
                    </div>
                  </form>
                )}
              </div>

              {/* Order Summary */}
              <div className="checkout-section">
                <h2>Order Summary</h2>
                <div className="order-items">
                  {sellerItems.map((item, index) => {
                    const price = parseFloat(item.price) || 0;
                    const quantity = parseInt(item.quantity) || 1;
                    return (
                      <div key={index} className="order-item">
                        <img 
                          src={item.image || item.image_url || '/placeholder-image.svg'} 
                          alt={item.name || item.title}
                          onError={(e) => e.target.src = '/placeholder-image.svg'}
                        />
                        <div className="item-details">
                          <h4>{item.name || item.title}</h4>
                          <p>Seller: {item.seller_name || 'Shoppers Seller'}</p>
                          <p>Quantity: {quantity}</p>
                        </div>
                        <div className="item-price">
                          ₹{(price * quantity).toFixed(2)}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="order-total">
                  <h3>Total Amount</h3>
                  <h2>₹{calculateTotal().toFixed(2)}</h2>
                </div>
              </div>

              {/* Payment Method */}
              <div className="checkout-section">
                <h2>Payment Method</h2>
                <div className="payment-options">
                  <label className="payment-option">
                    <input
                      type="radio"
                      name="payment"
                      value="cod"
                      checked={paymentMethod === 'cod'}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                    />
                    <span>Cash on Delivery</span>
                  </label>
                  
                  <label className="payment-option">
                    <input
                      type="radio"
                      name="payment"
                      value="online"
                      checked={paymentMethod === 'online'}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                    />
                    <span>Online Payment</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="checkout-actions">
              <button 
                className="btn-secondary"
                onClick={() => navigate('/cart')}
                disabled={loading}
              >
                Back to Cart
              </button>
              
              <button 
                className="btn-primary"
                onClick={handlePlaceOrder}
                disabled={loading || !selectedAddressId}
              >
                {loading ? 'Placing Order...' : 'Place Order'}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default CheckoutPage;
