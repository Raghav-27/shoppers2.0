import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import SearchBar from './components/SearchBar';
import ProductsPage from './components/ProductsPage';
import WishlistPage from './components/WishlistPage';
import CartPage from './components/CartPage';
import ComparePage from './components/ComparePage';
import SignIn from './components/SignIn';
import SignUp from './components/SignUp';
import Footer from './components/Footer';
import { checkSession, logout } from './utils/auth';
import { useTheme } from './contexts/ThemeContext';
import './App.css';
import SellerRegister from './seller-frontend/components/SellerRegister';
import SellerLogin from './seller-frontend/components/SellerLogin';
import SellerDashboard from './seller-frontend/components/SellerDashboard';
import AddProduct from './seller-frontend/components/AddProduct';
import ManageProducts from './seller-frontend/components/ManageProducts';
import SellerProfile from './seller-frontend/components/SellerProfile';
import ManageStores from './seller-frontend/components/ManageStores';
import StoreDetails from './seller-frontend/components/StoreDetails';
import SellerProductDetail from './components/SellerProductDetail';
import CheckoutPage from './components/CheckoutPage';
import PaymentPage from './components/PaymentPage';
import OrderHistory from './components/OrderHistory';
import SellerOrders from './seller-frontend/components/SellerOrders';
import AdminDashboard from './components/admin/AdminDashboard';
import UsersTable from './components/admin/UsersTable';
import SellersTable from './components/admin/SellersTable';
import OrdersTable from './components/admin/OrdersTable';
import ProductsTable from './components/admin/ProductsTable';
import AdminLogin from './components/admin/AdminLogin';

function App() {
  const navigate = useNavigate();
  const location = useLocation();
  const [isSignedIn, setIsSignedIn] = useState(false);
  const [user, setUser] = useState(null);
  const [isCheckingSession, setIsCheckingSession] = useState(true);
  const [userLists, setUserLists] = useState({ wishlist: [], cart: [], compare: [] });
  const { isDarkMode } = useTheme();

  // Function to fetch user lists
  const fetchUserLists = async () => {
    try {
      const apiUrl = process.env.REACT_APP_API_URL || 'http://localhost:5000';
      const response = await fetch(`${apiUrl}/api/user/lists`, {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        const lists = await response.json();
        setUserLists(lists);
      }
    } catch (error) {
      console.error('Failed to fetch user lists:', error);
    }
  };

  // Check for existing session on app load
  useEffect(() => {
    const initializeSession = async () => {
      try {
        const session = await checkSession();
        if (session.isValid) {
          setIsSignedIn(true);
          setUser(session.user);
          await fetchUserLists();
        }
      } catch (error) {
        console.error('Failed to check session:', error);
      } finally {
        setIsCheckingSession(false);
      }
    };

    initializeSession();
  }, []);

  const handleSignIn = async (userData) => {
    setIsSignedIn(true);
    setUser(userData);
    navigate('/');
    await fetchUserLists();
  };

  const handleSignOut = async () => {
    try {
      await logout();
      setIsSignedIn(false);
      setUser(null);
      setUserLists({ wishlist: [], cart: [], compare: [] });
      navigate('/');
    } catch (error) {
      console.error('Logout error:', error);
      setIsSignedIn(false);
      setUser(null);
      setUserLists({ wishlist: [], cart: [], compare: [] });
      navigate('/');
    }
  };

  const handleSearch = (searchParams) => {
    navigate('/products', { 
      state: { 
        query: searchParams.query,
        sort: searchParams.sort,
        platforms: searchParams.platforms
      }
    });
  };

  // Home Page Component
  const HomePage = () => (
    <main className={`main-content${isDarkMode ? ' dark' : ''}`}>
      <div className="welcome-section">
        <h1 className='welcometoshoppers'>Welcome to Shoppers</h1>
        <SearchBar onSearch={handleSearch} />
        <p>Your one-stop destination for comparing products across multiple shopping platforms</p>
        <div className="features">
          <div className="feature-card">
            <h3>🔍 Smart Search</h3>
            <p>Search across Amazon, Flipkart, Myntra, and more</p>
          </div>
          <div className="feature-card">
            <h3>💰 Best Prices</h3>
            <p>Compare prices and find the best deals</p>
          </div>
          <div className="feature-card">
            <h3>❤️ Wishlist</h3>
            <p>Save your favorite products for later</p>
          </div>
        </div>
      </div>
    </main>
  );

  // Products Page Wrapper
  const ProductsPageWrapper = () => {
    const location = useLocation();
    const searchData = location.state;

    return searchData ? (
      <ProductsPage 
        searchQuery={searchData.query}
        sortOrder={searchData.sort}
        selectedPlatforms={searchData.platforms}
        isSignedIn={isSignedIn}
        user={user}
        userLists={userLists}
        onUpdateLists={fetchUserLists}
        onSearch={handleSearch}
      />
    ) : (
      <div>No search data available. Please search from the home page.</div>
    );
  };

  return (
    <div className="App">
      {isCheckingSession ? (
        <div className="loading-container">
          <div className="loading-spinner">
            <h2>Loading...</h2>
            <p>Checking your session...</p>
          </div>
        </div>
      ) : (
        <>
          <Navbar 
            onSignInClick={() => navigate('/signin')} 
            onSignUpClick={() => navigate('/signup')}
            onHomeClick={() => navigate('/')}
            onSignOut={handleSignOut}
            onSearch={handleSearch}
            onWishlistClick={() => navigate('/wishlist')}
            onCartClick={() => navigate('/cart')}
            onCompareClick={() => navigate('/compare')}
            showSearchBar={location.pathname === '/products'}
            isSignedIn={isSignedIn}
            user={user}
          />
          <Routes>
            {/* Main App Routes */}
            <Route path="/" element={<HomePage />} />
            <Route path="/signin" element={<SignIn onSignUpClick={() => navigate('/signup')} onSignIn={handleSignIn} />} />
            <Route path="/signup" element={<SignUp onSignInClick={() => navigate('/signin')} onSignUp={handleSignIn} />} />
            <Route path="/products" element={<ProductsPageWrapper />} />
            
            {/* Seller Product Detail - must come before /seller routes */}
            <Route path="/product/seller/:productId" element={
              <SellerProductDetail
                isSignedIn={isSignedIn}
                user={user}
                userLists={userLists}
                onUpdateLists={fetchUserLists}
              />
            } />
            
            <Route path="/wishlist" element={
              <WishlistPage 
                isSignedIn={isSignedIn}
                user={user}
                userLists={userLists}
                onUpdateLists={fetchUserLists}
              />
            } />
            <Route path="/cart" element={
              <CartPage 
                isSignedIn={isSignedIn}
                user={user}
                userLists={userLists}
                onUpdateLists={fetchUserLists}
              />
            } />
            <Route path="/compare" element={
              <ComparePage 
                isSignedIn={isSignedIn}
                user={user}
                userLists={userLists}
                onUpdateLists={fetchUserLists}
              />
            } />
            
            <Route path="/checkout" element={
              <CheckoutPage 
                isSignedIn={isSignedIn}
                user={user}
                userLists={userLists}
                onUpdateLists={fetchUserLists}
              />
            } />
            
            <Route path="/payment/:orderId" element={
              <PaymentPage 
                isSignedIn={isSignedIn}
                user={user}
              />
            } />
            
            <Route path="/orders" element={
              <OrderHistory 
                isSignedIn={isSignedIn}
                user={user}
              />
            } />

            {/* Seller Routes */}
            <Route path="/seller/register" element={<SellerRegister />} />
            <Route path="/seller/login" element={<SellerLogin />} />
            <Route path="/seller/dashboard" element={<SellerDashboard />} />
            <Route path="/seller/orders" element={<SellerOrders />} />
            <Route path="/seller/stores" element={<ManageStores />} />
            <Route path="/seller/stores/:storeId" element={<StoreDetails />} />
            <Route path="/seller/add-product" element={<AddProduct />} />
            <Route path="/seller/manage-products" element={<ManageProducts />} />
            <Route path="/seller/profile" element={<SellerProfile />} />

            {/* Admin Routes */}
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/users" element={<UsersTable />} />
            <Route path="/admin/sellers" element={<SellersTable />} />
            <Route path="/admin/orders" element={<OrdersTable />} />
            <Route path="/admin/products" element={<ProductsTable />} />
          </Routes>
          <Footer />
        </>
      )}
    </div>
  );
}

export default App;
