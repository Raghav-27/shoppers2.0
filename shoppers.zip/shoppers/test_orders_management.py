"""
Test admin orders endpoint
"""
import requests
import json

ADMIN_URL = "http://localhost:5002"

def test_orders_endpoint():
    """Test fetching orders list for management page"""
    
    # Login as admin
    session = requests.Session()
    
    login_response = session.post(
        f"{ADMIN_URL}/api/admin/login",
        json={"email": "admin@shoppers.com", "password": "admin123"}
    )
    
    if login_response.status_code != 200:
        print("❌ Admin login failed")
        return
    
    print("✅ Admin logged in successfully\n")
    
    # Fetch orders list
    print("Fetching orders list...")
    
    orders_response = session.get(
        f"{ADMIN_URL}/api/admin/orders",
        params={"offset": 0, "limit": 50}
    )
    
    print(f"Status: {orders_response.status_code}")
    
    if orders_response.status_code == 200:
        data = orders_response.json()
        orders = data.get('orders', [])
        total = data.get('total', 0)
        
        print(f"\n📋 Orders Management Data:")
        print(f"Total Orders: {total}")
        print(f"Orders Retrieved: {len(orders)}\n")
        
        if orders:
            print("Order Details:")
            for order in orders[:5]:  # Show first 5
                print(f"\n  Order ID: {order.get('order_id', 'N/A')}")
                print(f"  Customer: {order.get('user_name', 'N/A')}")
                print(f"  Email: {order.get('user_email', 'N/A')}")
                print(f"  Amount: ${order.get('total_amount', 'N/A')}")
                print(f"  Status: {order.get('status', 'N/A')}")
                print(f"  Items: {len(order.get('items', []))}")
            
            print(f"\n🎉 SUCCESS! Order Management page will now show {len(orders)} order(s)!")
        else:
            print("❌ No orders found in response")
    else:
        print(f"❌ Failed to fetch orders: {orders_response.text}")
    
    # Also check dashboard stats
    print("\n" + "=" * 60)
    print("Checking Dashboard Stats...")
    
    stats_response = session.get(f"{ADMIN_URL}/api/admin/dashboard/stats")
    
    if stats_response.status_code == 200:
        stats = stats_response.json()
        print(f"\n📊 Dashboard Statistics:")
        print(f"  Orders Total: {stats['orders']['total']}")
        print(f"  Orders Pending: {stats['orders']['pending']}")
        print(f"  Orders Completed: {stats['orders']['completed']}")
        
        if stats['orders']['total'] > 0:
            print("\n✅ Dashboard now shows orders!")
        else:
            print("\n❌ Dashboard still shows 0 orders")

if __name__ == "__main__":
    print("=" * 60)
    print("ADMIN ORDERS MANAGEMENT TEST")
    print("=" * 60)
    print()
    
    test_orders_endpoint()
    
    print("\n" + "=" * 60)
