# Seller Platform - Complete Setup Guide

## Overview
A complete seller management system with backend API and frontend React components.

## Project Structure

```
shoppers/
├── seller-backend/          # Flask API for seller management
│   ├── api.py              # Main API with authentication & product endpoints
│   ├── requirements.txt    # Python dependencies
│   ├── sellers.db         # SQLite database (auto-created)
│   └── README.md
│
└── seller-frontend/         # React components for seller interface
    ├── components/
    │   ├── SellerRegister.js
    │   ├── SellerLogin.js
    │   ├── SellerDashboard.js
    │   ├── AddProduct.js
    │   ├── ManageProducts.js
    │   ├── SellerProfile.js
    │   ├── SellerAuth.css
    │   ├── SellerDashboard.css
    │   ├── AddProduct.css
    │   ├── ManageProducts.css
    │   └── SellerProfile.css
    ├── App.example.js       # Example route configuration
    └── README.md
```

## Quick Start

### Backend Setup

1. Navigate to seller-backend:
```bash
cd seller-backend
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the server:
```bash
python api.py
```

Server runs on: `http://localhost:5001`

### Frontend Setup

1. The components are ready to use in your React app

2. Add routes to your main App.js (see seller-frontend/App.example.js)

3. Access seller pages:
   - Register: `http://localhost:3000/seller/register`
   - Login: `http://localhost:3000/seller/login`
   - Dashboard: `http://localhost:3000/seller/dashboard`

## Features

### Backend API
- ✅ Seller registration & authentication
- ✅ Session management
- ✅ Product CRUD operations
- ✅ SQLite database
- ✅ CORS enabled

### Frontend
- ✅ Beautiful gradient UI design
- ✅ Seller registration & login
- ✅ Dashboard with statistics
- ✅ Add/Edit/Delete products
- ✅ Product image support
- ✅ Profile management
- ✅ Fully responsive

## API Endpoints

### Authentication
- `POST /api/seller/register` - Register new seller
- `POST /api/seller/login` - Login seller
- `POST /api/seller/logout` - Logout seller
- `GET /api/seller/profile` - Get seller profile

### Products
- `GET /api/seller/products` - Get all seller products
- `POST /api/seller/products` - Add new product
- `PUT /api/seller/products/<id>` - Update product
- `DELETE /api/seller/products/<id>` - Delete product

## Database Schema

### sellers table
- id, email, password_hash, business_name, contact_person, phone, address, created_at, is_active

### seller_products table
- id, seller_id, name, description, price, original_price, category, stock_quantity, image_url, images, created_at, updated_at, is_active

## Next Steps

1. Start the backend server
2. Integrate routes in your main React app
3. Customize styling to match your brand
4. Add more features as needed

## Support

For questions or issues, refer to:
- Backend: seller-backend/README.md
- Frontend: seller-frontend/README.md
