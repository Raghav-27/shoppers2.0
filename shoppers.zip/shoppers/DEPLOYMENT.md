# Deployment Guide 🚀

This guide covers deploying the Shoppers application in various environments.

## Table of Contents
1. [Local Development](#local-development)
2. [Docker Deployment](#docker-deployment)
3. [Production Deployment](#production-deployment)
4. [Environment Variables](#environment-variables)
5. [Troubleshooting](#troubleshooting)

---

## Local Development

### Prerequisites
- Python 3.11+
- Node.js 18+
- Redis (or Docker)

### Setup Steps

#### 1. Backend Setup
```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Create .env file
cp .env.example .env

# Edit .env and configure:
# REDIS_HOST=localhost
# CORS_ORIGINS=http://localhost:3000
```

#### 2. Start Redis
```bash
# Using Docker
docker run -d -p 6379:6379 --name redis redis:7-alpine

# Or install Redis locally
# Windows: https://redis.io/docs/getting-started/installation/install-redis-on-windows/
# Linux: sudo apt-get install redis-server
# Mac: brew install redis
```

#### 3. Start Backend
```bash
cd backend
uvicorn api:app --reload --host 0.0.0.0 --port 5000
```

Backend will be available at: http://localhost:5000
API Docs: http://localhost:5000/docs

#### 4. Frontend Setup
```bash
# Install dependencies
npm install

# Create .env file
cp .env.example .env

# Edit .env:
# REACT_APP_API_URL=http://localhost:5000

# Start development server
npm start
```

Frontend will be available at: http://localhost:3000

---

## Docker Deployment

### Development Mode

```bash
# Build and start all services
docker-compose -f docker-compose.dev.yml up --build

# Or in detached mode
docker-compose -f docker-compose.dev.yml up -d --build

# View logs
docker-compose -f docker-compose.dev.yml logs -f

# Stop services
docker-compose -f docker-compose.dev.yml down
```

**Services:**
- Frontend: http://localhost:3000
- Backend: http://localhost:5000
- API Docs: http://localhost:5000/docs
- Redis Commander: http://localhost:8081

### Production Mode

```bash
# Build and start all services
docker-compose up --build -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down

# Stop and remove volumes (clears data)
docker-compose down -v
```

**Services:**
- Frontend + Backend (via Nginx): http://localhost
- API Docs: http://localhost/docs (proxied through Nginx)
- Redis Commander: http://localhost:8081

---

## Production Deployment

### AWS EC2 / DigitalOcean / VPS

#### 1. Server Setup
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Install git
sudo apt install git -y
```

#### 2. Clone and Configure
```bash
# Clone repository
git clone <your-repo-url>
cd shoppers

# Create production environment files
cp backend/.env.example backend/.env
cp .env.example .env

# Edit backend/.env
nano backend/.env
# Set production values:
# REDIS_HOST=redis
# REDIS_PORT=6379
# CORS_ORIGINS=https://yourdomain.com
# LOG_LEVEL=WARNING
# RATE_LIMIT_PER_MINUTE=100

# Edit .env (leave empty for nginx proxy)
nano .env
# REACT_APP_API_URL=
```

#### 3. Deploy with Docker Compose
```bash
# Build and start services
docker-compose up -d --build

# Check status
docker-compose ps

# View logs
docker-compose logs -f
```

#### 4. Setup Nginx (Optional - if not using Docker nginx)
```bash
sudo apt install nginx -y

# Create Nginx configuration
sudo nano /etc/nginx/sites-available/shoppers

# Add configuration (see below)
# Enable site
sudo ln -s /etc/nginx/sites-available/shoppers /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

**Nginx Configuration Example:**
```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:80;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

#### 5. Setup SSL with Let's Encrypt
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx -y

# Get SSL certificate
sudo certbot --nginx -d yourdomain.com

# Auto-renewal (already configured by certbot)
```

### Kubernetes Deployment

#### 1. Create Kubernetes Manifests

**backend-deployment.yaml:**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: backend
spec:
  replicas: 3
  selector:
    matchLabels:
      app: backend
  template:
    metadata:
      labels:
        app: backend
    spec:
      containers:
      - name: backend
        image: your-registry/shoppers-backend:latest
        ports:
        - containerPort: 5000
        env:
        - name: REDIS_HOST
          value: "redis-service"
        - name: REDIS_PORT
          value: "6379"
---
apiVersion: v1
kind: Service
metadata:
  name: backend-service
spec:
  selector:
    app: backend
  ports:
  - port: 5000
    targetPort: 5000
```

**redis-deployment.yaml:**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:7-alpine
        ports:
        - containerPort: 6379
---
apiVersion: v1
kind: Service
metadata:
  name: redis-service
spec:
  selector:
    app: redis
  ports:
  - port: 6379
    targetPort: 6379
```

Apply manifests:
```bash
kubectl apply -f backend-deployment.yaml
kubectl apply -f redis-deployment.yaml
kubectl apply -f frontend-deployment.yaml
```

---

## Environment Variables

### Backend (.env)

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| REDIS_HOST | Redis hostname | redis | Yes |
| REDIS_PORT | Redis port | 6379 | Yes |
| API_HOST | API bind address | 0.0.0.0 | No |
| API_PORT | API port | 5000 | No |
| CORS_ORIGINS | Allowed origins (comma-separated) | http://localhost:3000 | Yes |
| RATE_LIMIT_PER_MINUTE | Global rate limit | 60 | No |
| LOG_LEVEL | Logging level (DEBUG, INFO, WARNING, ERROR) | INFO | No |
| SESSION_EXPIRY_DAYS | Session expiry in days | 7 | No |

### Frontend (.env)

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| REACT_APP_API_URL | Backend API URL | (empty for nginx proxy) | Yes |
| REACT_APP_NAME | App name | Shoppers | No |
| REACT_APP_VERSION | App version | 1.0.0 | No |

---

## Monitoring & Logs

### View Docker Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f frontend
docker-compose logs -f redis

# Last 100 lines
docker-compose logs --tail=100 backend
```

### Health Checks
```bash
# Backend health
curl http://localhost:5000/health

# Redis health
docker-compose exec redis redis-cli ping
```

### Redis Data Inspection
```bash
# Access Redis Commander
http://localhost:8081

# Or use CLI
docker-compose exec redis redis-cli

# Check keys
KEYS *

# Check specific key
GET meesho:shoes:relevance:data
```

---

## Backup & Restore

### Backup Redis Data
```bash
# Create backup
docker-compose exec redis redis-cli SAVE

# Copy backup file
docker cp $(docker-compose ps -q redis):/data/dump.rdb ./backup-$(date +%Y%m%d).rdb
```

### Restore Redis Data
```bash
# Stop services
docker-compose down

# Copy backup to Redis volume
docker run --rm -v shoppers_redis_data:/data -v $(pwd):/backup alpine cp /backup/dump.rdb /data/dump.rdb

# Start services
docker-compose up -d
```

---

## Scaling

### Scale Backend Replicas
```bash
# Docker Compose
docker-compose up -d --scale backend=3

# Kubernetes
kubectl scale deployment backend --replicas=5
```

### Load Balancing
For production, use:
- **Nginx** as reverse proxy
- **AWS ELB/ALB** for AWS deployments
- **HAProxy** for custom setups
- **Kubernetes Ingress** for k8s deployments

---

## Troubleshooting

### Backend Not Starting
```bash
# Check logs
docker-compose logs backend

# Common issues:
# 1. Redis not accessible
docker-compose exec backend ping redis

# 2. Port already in use
sudo lsof -i :5000
sudo kill -9 <PID>

# 3. Environment variables not loaded
docker-compose exec backend env | grep REDIS
```

### Frontend Can't Connect to Backend
```bash
# Check REACT_APP_API_URL in .env
cat .env | grep REACT_APP_API_URL

# Verify backend is running
curl http://localhost:5000/health

# Check CORS settings
docker-compose exec backend env | grep CORS_ORIGINS
```

### Redis Connection Issues
```bash
# Test Redis connection
docker-compose exec backend python -c "import redis; r=redis.Redis(host='redis', port=6379); print(r.ping())"

# Check Redis logs
docker-compose logs redis

# Restart Redis
docker-compose restart redis
```

### High Memory Usage
```bash
# Check Redis memory
docker-compose exec redis redis-cli INFO memory

# Clear cache (CAUTION: deletes all data)
docker-compose exec redis redis-cli FLUSHALL

# Limit Redis memory in redis.conf
maxmemory 256mb
maxmemory-policy allkeys-lru
```

### Rate Limiting Issues
```bash
# Check rate limit keys in Redis
docker-compose exec redis redis-cli KEYS "ratelimit:*"

# Clear rate limit for specific IP
docker-compose exec redis redis-cli DEL "ratelimit:192.168.1.1"

# Adjust rate limits in backend/.env
RATE_LIMIT_PER_MINUTE=120
```

---

## Performance Tuning

### Redis Optimization
```bash
# Enable persistence
# In redis.conf:
save 900 1
save 300 10
save 60 10000

# Disable persistence for cache-only use
save ""
```

### Uvicorn Workers
```bash
# Increase workers in Dockerfile
CMD ["uvicorn", "api:app", "--host", "0.0.0.0", "--port", "5000", "--workers", "8"]

# Rule of thumb: (2 x CPU cores) + 1
```

### Nginx Caching
```nginx
proxy_cache_path /var/cache/nginx levels=1:2 keys_zone=api_cache:10m max_size=1g inactive=60m;

location /api/search {
    proxy_cache api_cache;
    proxy_cache_valid 200 5m;
    proxy_cache_key "$scheme$request_method$host$request_uri";
}
```

---

## Security Checklist

- [ ] Change default Redis password
- [ ] Enable HTTPS/SSL in production
- [ ] Set secure CORS origins (no wildcards)
- [ ] Use environment variables for secrets
- [ ] Enable rate limiting
- [ ] Set up firewall rules
- [ ] Regular security updates
- [ ] Enable Redis authentication
- [ ] Use HTTP-only cookies for sessions
- [ ] Implement API key authentication (if needed)

---

## Support

For issues or questions:
- Open an issue on GitHub
- Check logs: `docker-compose logs -f`
- Health check: `curl http://localhost:5000/health`

---

**Happy Deploying! 🚀**
