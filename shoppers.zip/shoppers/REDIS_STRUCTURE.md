# Redis Data Structure Documentation - Shoppers Platform

**Last Updated:** January 21, 2026  
**Version:** 2.0

## Overview

The Shoppers platform uses a single Redis instance with multiple logical databases (0-4) for different data domains. This document provides a complete reference of all key patterns, data structures, and storage schemas currently in use.

## Database Allocation

| Database | Purpose | Primary Files |
|----------|---------|---------------|
| **DB 0** | User sessions, admin sessions, scraped products cache, rate limiting, payment sessions | `backend/sign_up.py`, `backend/api.py`, `backend/admin_api.py`, scrapers |
| **DB 1** | Seller products (new structure), Flask-Session for seller backend | `backend/seller_products_manager.py`, `seller-backend/api.py` |
| **DB 2** | Seller accounts, stores, seller metadata | `backend/sellers_manager.py`, `seller-backend/api.py` |
| **DB 3** | Orders (new structure), seller product search index | `backend/orders_manager.py`, `backend/seller_product_search.py` |
| **DB 4** | Orders (legacy structure) | `backend/order_manager.py` |

---

## ⚠️ CRITICAL ISSUES & CONFLICTS

### 1. **DB 3 Collision**
- **Problem:** Both `orders_manager.py` (orders) and `seller_product_search.py` (search index) use DB 3
- **Risk:** Potential key collisions and data corruption
- **Status:** Active conflict - needs resolution

### 2. **Dual Order Management Systems**
- **Problem:** Two different order managers using different databases
  - `backend/order_manager.py` → DB 4
  - `backend/orders_manager.py` → DB 3
- **Risk:** Orders may be split across databases, inconsistent data
- **Status:** Both systems in use by different endpoints in `backend/api.py`

### 3. **Seller Data Duplication**
- **Problem:** Two different key patterns for seller/product data
  - **Legacy:** `seller:{id}`, `seller:{id}:product:{id}` (seller-backend/api.py)
  - **New:** `seller:info:{id}`, `seller:prod:{seller_id}:{product_id}` (managers)
- **Risk:** Data synchronization issues, admin dashboard doesn't see legacy data
- **Status:** Active - seller-backend uses legacy, admin uses new

### 4. **ID Counter Conflicts**
- **Problem:** `seller:id_counter` incremented by both legacy and new systems
- **Risk:** Same seller_id used for different data structures
- **Status:** Active conflict

---

## DB 0: User Sessions & Scraped Products

### User Authentication & Sessions

#### `user:{email}` - User Profile
- **Type:** String (JSON)
- **Created by:** `backend/sign_up.py`, `backend/api.py`
- **TTL:** None
- **Schema:**
```json
{
  "first_name": "string",
  "last_name": "string",
  "email": "string",
  "phone": "string",
  "country": "string",
  "password": "bcrypt_hash",
  "created_at": "ISO8601_timestamp",
  "addresses": []  // optional array
}
```

#### `user:{email}:state` - User State (Cart, Wishlist, Compare)
- **Type:** String (JSON)
- **Created by:** `backend/sign_up.py`, `backend/api.py`
- **TTL:** None
- **Schema:**
```json
{
  "wishlist": [/* product objects */],
  "cart": [/* product objects with quantity */],
  "compare": [/* product objects */]
}
```

#### `session:{token}` - User Session
- **Type:** String (JSON)
- **Created by:** `backend/api.py`
- **TTL:** 7 days (604800 seconds)
- **Schema:**
```json
{
  "email": "string",
  "created_at": "timestamp",
  "expires_at": "timestamp"
}
```

### Admin Authentication

#### `admin:{email}` - Admin Credentials
- **Type:** String (JSON)
- **Created by:** `backend/admin_api.py`
- **TTL:** None
- **Schema:**
```json
{
  "email": "string",
  "password_hash": "bcrypt_hash",
  "created_at": "ISO8601_timestamp",
  "role": "admin"
}
```

#### `admin:session:{token}` - Admin Session
- **Type:** String (JSON)
- **Created by:** `backend/admin_api.py`
- **TTL:** 7 days (604800 seconds)

### Scraped Product Cache

#### `{platform}:{query}:{sort}:data` - Marketplace Products
- **Platforms:** `myntra`, `meesho`, `flipkart`, `ajio`, `shopshy`
- **Type:** String (JSON)
- **Created by:** Platform-specific scrapers (`backend/*_scraper.py`)
- **TTL:** None (manual refresh)
- **Schema:**
```json
{
  "metadata": {
    "query": "string",
    "sort_order": "string",
    "total_products": 0,
    "scraped_at": "ISO8601",
    "scraped_timestamp": 0,
    "last_page_scraped": 0,
    "cursor": "string"  // optional
  },
  "products": [
    {
      "name": "string",
      "price": "string",
      "original_price": "string",
      "image": "url",
      "url": "product_url",
      "rating": "string",
      "platform": "platform_name"
      // ... platform-specific fields
    }
  ]
}
```

### Rate Limiting

#### `ratelimit:{ip}:{user_agent_hash}` - Global Rate Limit
- **Type:** Sorted Set
- **Created by:** `backend/rate_limiter.py`
- **TTL:** 70 seconds (window_size + 10)
- **Score:** Timestamp (float)
- **Members:** Request IDs

#### `endpoint_ratelimit:{ip}:{user_agent_hash}:{endpoint}` - Per-Endpoint Rate Limit
- **Type:** Sorted Set
- **Created by:** `backend/rate_limiter.py`
- **TTL:** Window size + 10 seconds

### Payment Sessions

#### `payment:{session_id}` - Payment Session
- **Type:** String (JSON)
- **Created by:** `backend/api.py`
- **TTL:** 3600 seconds (1 hour)
- **Schema:**
```json
{
  "session_id": "string",
  "order_id": "string",
  "user_id": "string",
  "amount": 0.0,
  "status": "pending|success|failed",
  "transaction_id": "string",  // optional
  "created_at": 0  // timestamp
}
```

---

## DB 1: Seller Products (New Structure)

### Product Management (seller_products_manager.py)

#### `seller:prod:{seller_id}:{product_id}` - Product Details
- **Type:** Hash
- **Created by:** `backend/seller_products_manager.py`
- **Read by:** `backend/seller_products_manager.py`, `backend/admin_api.py`
- **TTL:** None
- **Fields:**
```
name: string
description: string
price: float (as string)
category: string
stock: int (as string)
image_url: string (primary image URL)
images: string (comma-separated URLs)
is_active: "0" or "1"
store_id: string
created_at: ISO8601_timestamp
updated_at: ISO8601_timestamp
```

#### `seller:prod:list:{seller_id}` - Seller's Product IDs
- **Type:** Set
- **Members:** Product IDs (integers as strings)
- **Created by:** `backend/seller_products_manager.py`
- **TTL:** None

#### `seller:prod:all` - All Seller Products Index
- **Type:** Set
- **Members:** Strings in format `{seller_id}:{product_id}`
- **Created by:** `backend/seller_products_manager.py`
- **Read by:** `backend/admin_api.py`
- **TTL:** None

#### `seller:prod:count:{seller_id}` - Product Count
- **Type:** String (integer)
- **Created by:** `backend/seller_products_manager.py`
- **TTL:** None

### Flask Session Storage (Seller Backend)

#### `session:{session_id}` - Flask-Session Data
- **Type:** Binary
- **Created by:** `seller-backend/api.py` (Flask-Session)
- **TTL:** Session duration

---

## DB 2: Seller Information

### Seller Accounts (New Structure - sellers_manager.py)

#### `seller:id_counter` - Seller ID Auto-Increment
- **Type:** String (integer)
- **Used by:** `backend/sellers_manager.py`, `seller-backend/api.py` (⚠️ both increment)
- **TTL:** None

#### `seller:info:{seller_id}` - Seller Account Details
- **Type:** Hash
- **Created by:** `backend/sellers_manager.py`
- **Read by:** `backend/sellers_manager.py`, `backend/admin_api.py`
- **TTL:** None
- **Fields:**
```
seller_id: int (as string)
email: string
business_name: string
phone: string
contact_person: string
address: string
verified: "0" or "1"
status: "active" or "inactive"
created_at: ISO8601_timestamp
total_orders: int (as string)
```

#### `seller:email:lookup` - Email to Seller ID Mapping
- **Type:** Hash
- **Created by:** `backend/sellers_manager.py`
- **Fields:** `{email}: {seller_id}`
- **TTL:** None

#### `seller:all` - All Seller IDs Index
- **Type:** Set
- **Members:** Seller IDs (integers as strings)
- **Created by:** `backend/sellers_manager.py`
- **Read by:** `backend/admin_api.py`
- **TTL:** None

#### `seller:rating:{seller_id}` - Seller Rating Aggregates
- **Type:** Hash
- **TTL:** None
- **Fields:**
```
total_ratings: int
average_rating: float
```

### Store Management

#### `store:id_counter` - Store ID Auto-Increment
- **Type:** String (integer)
- **TTL:** None

#### `store:{store_id}` - Store Details
- **Type:** Hash
- **TTL:** None
- **Fields:**
```
store_id: int
seller_id: int
name: string
description: string
address: string
phone: string
email: string
image_url: string
is_active: "0" or "1"
created_at: ISO8601_timestamp
```

#### `seller:stores:{seller_id}` - Seller's Store IDs
- **Type:** Set
- **Members:** Store IDs
- **TTL:** None

### Legacy Seller Structure (seller-backend/api.py)

⚠️ **WARNING:** This structure conflicts with the new structure above. Used by `seller-backend/api.py` but NOT visible to admin dashboard.

#### `seller:{seller_id}` - Legacy Seller Data
- **Type:** Hash
- **Created by:** `seller-backend/api.py`
- **TTL:** None
- **Fields:**
```
id: int
email: string
password_hash: bcrypt_hash
business_name: string
contact_person: string
phone: string
address: string
created_at: ISO8601_timestamp
is_active: "0" or "1"
```

#### `seller:emails` - Legacy Email Lookup
- **Type:** Hash
- **Created by:** `seller-backend/api.py`
- **Fields:** `{email}: {seller_id}`
- **TTL:** None

#### `seller:{seller_id}:store` - Legacy Store
- **Type:** Hash
- **Created by:** `seller-backend/api.py`
- **TTL:** None
- **Fields:**
```
store_name: string
description: string
logo_url: string
created_at: ISO8601_timestamp
```

#### `seller:{seller_id}:product_id_counter` - Product ID Counter (Legacy)
- **Type:** String (integer)
- **Created by:** `seller-backend/api.py`
- **TTL:** None

#### `seller:{seller_id}:products` - Product IDs (Legacy)
- **Type:** Set
- **Members:** Product IDs
- **Created by:** `seller-backend/api.py`
- **TTL:** None

#### `seller:{seller_id}:product:{product_id}` - Product Details (Legacy)
- **Type:** Hash
- **Created by:** `seller-backend/api.py`
- **TTL:** None
- **Fields:**
```
id: int
seller_id: int
name: string
description: string
price: decimal
original_price: decimal
category: string
stock_quantity: int
image_url: string
images: string (JSON array or comma-separated)
created_at: ISO8601_timestamp
updated_at: ISO8601_timestamp
is_active: "0" or "1"
```

---

## DB 3: Orders & Search Index

⚠️ **CRITICAL CONFLICT:** This database is used for TWO different purposes by different modules!

### Orders (orders_manager.py)

#### `order:id_counter` - Order ID Counter
- **Type:** String (integer)
- **Created by:** `backend/orders_manager.py`
- **TTL:** None

#### `order:{order_id}` - Order Details
- **Type:** String (JSON)
- **Created by:** `backend/orders_manager.py`
- **Read by:** `backend/orders_manager.py`, `backend/api.py`, `backend/admin_api.py`
- **TTL:** 365 days (31536000 seconds)
- **Schema:**
```json
{
  "order_id": "ORD-{year}-{counter}",
  "user_id": "string",
  "user_email": "string",
  "user_name": "string",
  "phone": "string",
  "address": "string",
  "items": [
    {
      "product_id": "string",
      "seller_id": "string",
      "name": "string",
      "price": 0.0,
      "quantity": 0,
      "image": "url"
    }
  ],
  "total_amount": 0.0,
  "status": "pending|confirmed|shipped|delivered|cancelled",
  "seller_status": "string",
  "buyer_status": "string",
  "payment_method": "string",
  "payment_status": "string",
  "created_at": "ISO8601_timestamp",
  "updated_at": "ISO8601_timestamp"
}
```

#### `order:user:{user_email}` - User's Order IDs
- **Type:** Set
- **Members:** Order IDs
- **Created by:** `backend/orders_manager.py`
- **TTL:** 365 days

#### `order:seller:{seller_id}` - Seller's Order IDs
- **Type:** Set
- **Members:** Order IDs
- **Created by:** `backend/orders_manager.py`
- **TTL:** 365 days

#### `order:status:{status}` - Orders by Status
- **Type:** Set
- **Members:** Order IDs
- **Status values:** `pending`, `confirmed`, `shipped`, `delivered`, `cancelled`
- **Created by:** `backend/orders_manager.py`
- **TTL:** 365 days

#### `order:all` - All Order IDs
- **Type:** Set
- **Members:** Order IDs
- **Created by:** `backend/orders_manager.py`
- **Read by:** `backend/admin_api.py`
- **TTL:** 365 days

#### `order:date:{YYYY-MM-DD}` - Orders by Date
- **Type:** Set
- **Members:** Order IDs
- **Created by:** `backend/orders_manager.py`
- **TTL:** 365 days

### Seller Product Search Index (seller_product_search.py)

⚠️ **CONFLICT:** Uses same DB 3 as orders above!

#### `seller_product:{seller_id}_{product_id}` - Indexed Product
- **Type:** String (JSON)
- **Created by:** `backend/seller_product_search.py`
- **TTL:** 24 hours (86400 seconds)
- **Schema:**
```json
{
  "id": "seller_{seller_id}_{product_id}",
  "product_id": "string",
  "seller_id": "string",
  "title": "string",
  "name": "string",
  "description": "string",
  "price": "string",
  "category": "string",
  "image": "url",
  "images": ["array", "of", "urls"],
  "stock": 0,
  "platform": "Seller",
  "source": "seller",
  "seller_name": "string",
  "url": "string",
  "rating": "string",
  "created_at": "ISO8601_timestamp"
}
```

#### `seller_search:{seller_id}_{product_id}` - Searchable Text
- **Type:** String
- **Content:** Concatenated searchable fields
- **Created by:** `backend/seller_product_search.py`
- **TTL:** 24 hours

#### `seller_product_keys` - All Indexed Product Keys
- **Type:** Set
- **Members:** Product key strings (`seller_{seller_id}_{product_id}`)
- **Created by:** `backend/seller_product_search.py`
- **TTL:** None

---

## DB 4: Orders (Legacy)

⚠️ **DUAL SYSTEM:** `backend/order_manager.py` uses DB 4 while `backend/orders_manager.py` uses DB 3

#### `order:{order_id}` - Order Details
- **Type:** String (JSON)
- **Created by:** `backend/order_manager.py`
- **Read by:** `backend/order_manager.py`, `backend/api.py` (some endpoints)
- **TTL:** None
- **Schema:** Similar to orders_manager.py schema

#### `user_orders:{user_email}` - User's Orders
- **Type:** Set
- **Members:** Order IDs
- **Created by:** `backend/order_manager.py`
- **TTL:** None

#### `seller_orders:{seller_id}` - Seller's Orders
- **Type:** Set
- **Members:** Order IDs
- **Created by:** `backend/order_manager.py`
- **TTL:** None

#### `all_orders` - All Order IDs
- **Type:** Set
- **Members:** Order IDs
- **Created by:** `backend/order_manager.py`
- **TTL:** None

---

## Data Flow Examples

### User Registration Flow
```
1. POST /api/signup
   ├─ Validate email not in use
   ├─ Hash password with bcrypt
   ├─ Store in user:{email} (DB 0)
   ├─ Initialize user:{email}:state with empty lists (DB 0)
   └─ Return success

2. User profile stored in DB 0:
   user:john@example.com → {"first_name":"John", "email":"john@example.com", ...}
```

### Seller Registration Flow (Legacy - seller-backend)
```
1. POST /api/seller/register (seller-backend:5001)
   ├─ Increment seller:id_counter (DB 2) → seller_id
   ├─ Store in seller:emails → {email: seller_id} (DB 2)
   ├─ Store in seller:{seller_id} hash (DB 2)
   ├─ Store in seller:{seller_id}:store hash (DB 2)
   └─ ❌ Does NOT add to seller:all set
   └─ ❌ Not visible to admin dashboard!

⚠️ Admin dashboard expects:
   ├─ seller:all set to contain seller_id
   └─ seller:info:{seller_id} key (not seller:{seller_id})
```

### Product Addition Flow (Legacy)
```
1. POST /api/seller/products (seller-backend:5001)
   ├─ Increment seller:{seller_id}:product_id_counter → product_id
   ├─ Store in seller:{seller_id}:product:{product_id} hash (DB 2)
   ├─ Add to seller:{seller_id}:products set (DB 2)
   └─ ❌ Not indexed in DB 1 seller:prod:all
   └─ ❌ Not visible to admin dashboard!
```

### Order Creation Flow (New)
```
1. POST /api/orders (backend:5000)
   ├─ Uses orders_manager.py
   ├─ Increment order:id_counter (DB 3) → counter
   ├─ Generate order_id: ORD-{year}-{counter}
   ├─ Store order:{order_id} JSON (DB 3, TTL: 365 days)
   ├─ Add to order:user:{email} set (DB 3)
   ├─ Add to order:seller:{seller_id} set (DB 3)
   ├─ Add to order:status:pending set (DB 3)
   ├─ Add to order:all set (DB 3)
   └─ Add to order:date:{YYYY-MM-DD} set (DB 3)
```

### Admin Dashboard Data Fetch
```
1. GET /api/admin/dashboard/stats (admin-api:5002)
   ├─ Users: SCAN DB 0 for user:* keys ✅ Works
   ├─ Sellers: Read seller:all set from DB 2 ❌ Empty (not populated by seller-backend)
   │   └─ For each seller_id: Get seller:info:{seller_id} ❌ Doesn't exist (legacy uses seller:{id})
   ├─ Orders: Read order:all set from DB 3 ✅ Works if orders created
   └─ Products: Read seller:prod:all from DB 1 ❌ Empty (legacy uses DB 2 different keys)

Result: Shows 0 sellers, 0 products even if data exists in legacy format
```

---

## Recommended Database Reorganization

To resolve conflicts and standardize data storage:

```
DB 0: User Sessions & Authentication
  - user:* (profiles, states, sessions)
  - admin:* (admin credentials, sessions)
  - payment:* (payment sessions)

DB 1: Scraped Products & Rate Limiting
  - {platform}:*:data (scraped marketplace products)
  - ratelimit:* (rate limiting)
  - endpoint_ratelimit:* (per-endpoint limits)

DB 2: Seller Accounts & Stores
  - seller:info:* (seller accounts - NEW STANDARD)
  - seller:store:* (store information)
  - seller:email:lookup (email mapping)
  - seller:all (all seller IDs index)
  - seller:rating:* (seller ratings)
  - Deprecate: seller:{id}, seller:emails

DB 3: Seller Products
  - seller:prod:* (product details - NEW STANDARD)
  - seller:prod:list:* (product IDs per seller)
  - seller:prod:all (all products index)
  - seller:prod:count:* (product counts)
  - Deprecate: seller:{id}:product:*

DB 4: Orders (Consolidated)
  - order:* (order details)
  - order:user:* (user orders)
  - order:seller:* (seller orders)
  - order:status:* (orders by status)
  - order:all (all orders index)
  - order:date:* (orders by date)
  - Merge: Both order_manager.py and orders_manager.py

DB 5: Seller Product Search Index (NEW)
  - seller_product:* (indexed products)
  - seller_search:* (searchable text)
  - seller_product_keys (index)
  - Move from: DB 3 to avoid conflict

DB 6: Temporary Data & Caching (Future)
  - Reserved for future use
```

---

## Migration Checklist

To fix current issues:

- [ ] **Update seller-backend/api.py:**
  - [ ] Change `seller:{id}` → `seller:info:{id}`
  - [ ] Change `seller:emails` → `seller:email:lookup`
  - [ ] Add seller_id to `seller:all` set on registration
  - [ ] Move products from DB 2 to DB 1 using `seller:prod:*` pattern
  - [ ] Add products to `seller:prod:all` set

- [ ] **Consolidate Order Managers:**
  - [ ] Migrate order_manager.py data from DB 4 to DB 3
  - [ ] Update all API endpoints to use orders_manager.py only
  - [ ] Deprecate order_manager.py

- [ ] **Move Search Index:**
  - [ ] Update seller_product_search.py to use DB 5
  - [ ] Migrate existing search index from DB 3 to DB 5

- [ ] **Create Migration Script:**
  - [ ] Scan and copy `seller:{id}` → `seller:info:{id}`
  - [ ] Populate `seller:all` set with existing seller IDs
  - [ ] Copy `seller:{id}:product:{id}` → `seller:prod:{seller_id}:{product_id}`
  - [ ] Update email lookup hash structure

- [ ] **Update Documentation:**
  - [ ] Update API documentation
  - [ ] Update deployment guides
  - [ ] Update developer onboarding docs

---

## Notes

- **TTL Policy:** Consider implementing TTL for inactive users/sellers to prevent memory bloat
- **Backup Strategy:** Redis persistence should be configured (RDB + AOF)
- **Monitoring:** Track key counts per database for capacity planning
- **Session Security:** All session tokens should be cryptographically secure UUIDs
- **Data Consistency:** Consider implementing Redis Transactions (MULTI/EXEC) for complex operations

---

## Files Reference

| File | Database(s) | Purpose |
|------|-------------|---------|
| `backend/redis_db.py` | All | Redis connection management |
| `backend/sign_up.py` | 0 | User registration |
| `backend/api.py` | 0, 3, 4 | Main API endpoints |
| `backend/admin_api.py` | 0, 1, 2, 3 | Admin dashboard API |
| `backend/sellers_manager.py` | 2 | Seller account management (NEW) |
| `backend/seller_products_manager.py` | 1 | Product management (NEW) |
| `backend/orders_manager.py` | 3 | Order management (NEW) |
| `backend/order_manager.py` | 4 | Order management (LEGACY) |
| `backend/rate_limiter.py` | 0 | Rate limiting |
| `backend/seller_product_search.py` | 3 | Product search indexing |
| `seller-backend/api.py` | 1, 2 | Seller backend (LEGACY patterns) |
| `backend/*_scraper.py` | 0 | Marketplace product scrapers |
