# Architecture & Data Flow Diagrams

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         FRONTEND (React)                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  CheckoutPage                          PaymentPage              │
│  ├─ Address Selection                  ├─ Order Summary         │
│  ├─ Address Management Form            ├─ Payment Form          │
│  ├─ Order Summary                      ├─ Payment Status        │
│  └─ Payment Method Selection           └─ Success/Failure States│
│                                                                   │
└──────────────────────────────────────────────────────────────────┘
                              ↓ API Calls
┌──────────────────────────────────────────────────────────────────┐
│                     BACKEND (FastAPI/Python)                     │
├──────────────────────────────────────────────────────────────────┤
│                                                                   │
│  Address Endpoints              Payment Endpoints                │
│  ├─ POST   /api/user/addresses  ├─ POST /api/payment/initiate  │
│  ├─ GET    /api/user/addresses  ├─ GET  /api/payment/status    │
│  ├─ PUT    /api/user/addresses  └─ POST /api/payment/confirm   │
│  └─ DELETE /api/user/addresses                                 │
│                                                                   │
│  Order Management (Existing)                                     │
│  ├─ POST /api/orders/create                                      │
│  ├─ GET  /api/orders/user                                        │
│  └─ GET  /api/orders/{id}                                        │
│                                                                   │
└──────────────────────────────────────────────────────────────────┘
                              ↓ Redis Operations
┌──────────────────────────────────────────────────────────────────┐
│                      REDIS DATA STORES                            │
├──────────────────────────────────────────────────────────────────┤
│                                                                   │
│  DB 0: User Data & Sessions                                      │
│  ├─ user:{email}              - User profile + addresses         │
│  ├─ payment:{session_id}      - Payment session (TTL: 30 min)   │
│  └─ session:{token}           - User session                     │
│                                                                   │
│  DB 4: Orders (New)                                              │
│  ├─ {order_id}                - Complete order data              │
│  ├─ user_orders:{user_id}     - Set of user's order IDs          │
│  ├─ seller_orders:{seller_id} - Set of seller's order IDs        │
│  └─ all_orders                - Set of all order IDs              │
│                                                                   │
└──────────────────────────────────────────────────────────────────┘
```

## Checkout Flow - Cash on Delivery

```
Start
  ↓
┌──────────────────┐
│ Add to Cart      │
└────────┬─────────┘
         ↓
┌──────────────────┐
│ Go to Checkout   │
└────────┬─────────┘
         ↓
┌─────────────────────────────────┐
│ Fetch User Addresses (DB 0)    │
└────────┬────────────────────────┘
         ↓
    ┌────┴────┐
    │          │
    ↓         ↓
┌─────────┐ ┌──────────────────┐
│ Existing│ │ Add New Address  │
│Address  │ │ ┌──────────────┐ │
│(Select) │ │ │ Validate     │ │
└────┬────┘ │ │ Form Data    │ │
     │      │ └──────┬───────┘ │
     │      │        ↓         │
     │      │ ┌──────────────┐ │
     │      │ │ Save to      │ │
     │      │ │ DB 0         │ │
     │      │ └──────┬───────┘ │
     │      └────────┼─────────┘
     │               ↓
     └───────┬───────┘
             ↓
   ┌─────────────────────┐
   │ Select Payment      │
   │ Method: COD         │
   └────────┬────────────┘
            ↓
   ┌─────────────────────┐
   │ Click Place Order   │
   └────────┬────────────┘
            ↓
   ┌──────────────────────────────┐
   │ POST /api/orders/create      │
   │ ├─ phone (from address)      │
   │ ├─ address (from address)    │
   │ ├─ items (from cart)         │
   │ └─ payment_method: "cod"     │
   └────────┬─────────────────────┘
            ↓
   ┌──────────────────────────────┐
   │ Create Order in DB 4         │
   │ ├─ order_id                  │
   │ ├─ user_id                   │
   │ ├─ items                     │
   │ ├─ total_amount              │
   │ ├─ status: "pending"         │
   │ └─ payment_status: "cod"     │
   └────────┬─────────────────────┘
            ↓
   ┌──────────────────────────────┐
   │ Clear Cart Items from DB 0   │
   └────────┬─────────────────────┘
            ↓
   ┌──────────────────────────────┐
   │ Navigate to /orders          │
   │ (Order Confirmation)         │
   └──────────────────────────────┘
            ↓
          END ✓
```

## Checkout Flow - Online Payment

```
Start
  ↓
┌──────────────────┐
│ Add to Cart      │
└────────┬─────────┘
         ↓
┌──────────────────┐
│ Go to Checkout   │
└────────┬─────────┘
         ↓
┌─────────────────────────────────┐
│ Fetch User Addresses (DB 0)    │
└────────┬────────────────────────┘
         ↓
    ┌────┴────┐
    │          │
    ↓         ↓
┌─────────┐ ┌──────────────────┐
│ Existing│ │ Add New Address  │
│Address  │ │ (Same as COD)    │
│(Select) │ └──────────────────┘
└────┬────┘
     │
     ↓
┌──────────────────────────────────┐
│ Select Payment Method: Online    │
└────────┬───────────────────────┘
         ↓
┌──────────────────────────────────┐
│ Click Place Order                │
└────────┬───────────────────────┘
         ↓
┌──────────────────────────────────────────────┐
│ POST /api/orders/create                      │
│ ├─ phone (from address)                      │
│ ├─ address (from address)                    │
│ ├─ items (from cart)                         │
│ └─ payment_method: "online"                  │
└────────┬─────────────────────────────────────┘
         ↓
┌──────────────────────────────────────────────┐
│ Create Order in DB 4                         │
│ ├─ order_id                                  │
│ ├─ status: "pending"                         │
│ ├─ payment_status: "initiated"               │
│ └─ (payment not yet confirmed)               │
└────────┬─────────────────────────────────────┘
         ↓
┌──────────────────────────────────────────────┐
│ Redirect to /payment/:orderId                │
│ (Pass order data via router state)           │
└────────┬─────────────────────────────────────┘
         ↓
┌──────────────────────────────────────────────┐
│ PaymentPage Component Loads                  │
├──────────────────────────────────────────────┤
│ 1. Display order summary                     │
│ 2. POST /api/payment/initiate                │
│    └─ Create payment session (DB 0)          │
│       TTL: 30 minutes                        │
└────────┬─────────────────────────────────────┘
         ↓
┌──────────────────────────────────────────────┐
│ User Enters Card Details                     │
│ ┌────────────────────────────────────────┐  │
│ │ Card Number: 4532123456789010          │  │
│ │ Expiry: MM/YY                          │  │
│ │ CVV: 123                               │  │
│ │ Name: John Doe                         │  │
│ └────────────────────────────────────────┘  │
└────────┬─────────────────────────────────────┘
         ↓
   ┌─────┴─────┐
   │            │
   ↓            ↓
┌──────┐    ┌──────────┐
│Demo  │    │Real      │
│Success│   │Gateway   │
└──┬───┘    └────┬─────┘
   │             │
   ↓             ↓
┌────────────────────────────────────────────────┐
│ POST /api/payment/confirm                      │
│ ├─ session_id                                  │
│ ├─ transaction_id                              │
│ └─ status: "success"                           │
└────────┬───────────────────────────────────────┘
         ↓
┌────────────────────────────────────────────────┐
│ Update Order in DB 4                           │
│ ├─ status: "confirmed"                         │
│ ├─ payment_status: "completed"                 │
│ ├─ transaction_id: "TXN123456"                 │
│ └─ Verify order belongs to user                │
└────────┬───────────────────────────────────────┘
         ↓
┌────────────────────────────────────────────────┐
│ Navigate to /orders                            │
│ (Show order confirmation)                      │
└─────────────────────────────────────────────────┘
         ↓
       END ✓
```

## Payment Flow - Failed & Retry

```
Payment Page
  ↓
User Clicks "Simulate Failed"
  ↓
POST /api/payment/confirm
├─ session_id
├─ transaction_id
└─ status: "failed"
  ↓
Order Updated (DB 4)
├─ status: "pending"
├─ payment_status: "failed"
└─ Still in pending state
  ↓
Show Error Page
├─ Error message
├─ "Retry Payment" button
└─ "Back to Cart" button
  ↓
  ├─ User clicks "Retry"
  │  ↓
  │  Go back to payment form
  │  └─ Process again
  │
  └─ User clicks "Back to Cart"
     ↓
     Navigate to /cart
```

## Address Management Flow

```
Checkout Page
  ↓
GET /api/user/addresses
  ↓
Display Addresses (from DB 0)
  ↓
  ├─ Select Existing
  │  └─ Use selected address for order
  │
  └─ Add New Address
     ├─ Show form
     ├─ Validate input
     │  ├─ Phone: 10 digits
     │  ├─ All fields required
     │  └─ Format checks
     │
     ├─ POST /api/user/addresses
     │  └─ Save to DB 0
     │
     ├─ Add to addresses list
     ├─ Update selected address
     └─ Use for order
```

## Database Operations

### Address Operations

```
ADD ADDRESS:
  Frontend validates form
    ↓
  POST /api/user/addresses
    ↓
  Backend validates
    ↓
  GET user:{email} from DB 0
    ↓
  Add address to user.addresses
    ↓
  SET user:{email} in DB 0
    ↓
  Return address to frontend

GET ADDRESSES:
  GET /api/user/addresses
    ↓
  GET user:{email} from DB 0
    ↓
  Return user.addresses

UPDATE ADDRESS:
  PUT /api/user/addresses/{id}
    ↓
  GET user:{email} from DB 0
    ↓
  Find and update address
    ↓
  SET user:{email} in DB 0
    ↓
  Return updated address

DELETE ADDRESS:
  DELETE /api/user/addresses/{id}
    ↓
  GET user:{email} from DB 0
    ↓
  Remove address from list
    ↓
  SET user:{email} in DB 0
    ↓
  Confirm deletion
```

### Payment Session Operations

```
INITIATE PAYMENT:
  POST /api/payment/initiate
    ↓
  Generate session_id
    ↓
  Create payment session object
    ↓
  SETEX payment:{session_id} in DB 0
    │ TTL: 30 minutes
    │ Auto-expire after 30 min
    ↓
  Return session_id to frontend

GET PAYMENT STATUS:
  GET /api/payment/status/{id}
    ↓
  GET payment:{id} from DB 0
    ↓
  Return payment session

CONFIRM PAYMENT:
  POST /api/payment/confirm
    ↓
  GET payment:{session_id} from DB 0
    ↓
  Verify session is valid
    ↓
  GET order:{order_id} from DB 4
    ↓
  Update order status & payment_status
    ↓
  SET order:{order_id} in DB 4
    ↓
  (Optional) DELETE payment:{session_id}
    ↓
  Return confirmation
```

## Component Interaction

```
App.js
  ├─ Provides: isSignedIn, user, userLists
  │
  ├─ Routes
  │   ├─ /checkout → CheckoutPage
  │   │   ├─ State: addresses, selectedAddressId, paymentMethod
  │   │   ├─ Effects: fetchAddresses(), fetchOrderDetails()
  │   │   ├─ Handlers:
  │   │   │   ├─ handleAddAddress()
  │   │   │   ├─ handlePlaceOrder()
  │   │   │   └─ handleAddressFormChange()
  │   │   └─ On COD: Navigate to /orders
  │   │   └─ On Online: Navigate to /payment/:orderId
  │   │
  │   └─ /payment/:orderId → PaymentPage
  │       ├─ State: order, paymentStatus, sessionId
  │       ├─ Effects: fetchOrderDetails(), initiatePayment()
  │       ├─ Handlers:
  │       │   ├─ handlePaymentSuccess()
  │       │   ├─ handlePaymentFailed()
  │       │   └─ handleRetryPayment()
  │       ├─ Demo Buttons: Simulate Success/Failed
  │       └─ On Success: Navigate to /orders
```

## State Management Flow

```
User Logs In
  ↓
App.js: checkSession()
  ├─ isSignedIn = true
  ├─ user = { email, firstName, lastName, etc. }
  └─ userLists = { cart, wishlist, compare }
  ↓
Go to Checkout
  ↓
CheckoutPage.js
  ├─ fetchAddresses() - GET /api/user/addresses
  ├─ addresses = [ { id, label, street, ... }, ... ]
  ├─ selectedAddressId = default or first address
  └─ paymentMethod = "cod"
  ↓
User Action: Place Order
  ↓
  ├─ Validate selectedAddressId
  ├─ Build order payload
  ├─ POST /api/orders/create
  └─ On COD: Navigate /orders
  └─ On Online: Navigate /payment/:orderId
```

## Error Handling Flow

```
API Request
  ↓
  ├─ Status 200
  │  └─ Success ✓
  │
  ├─ Status 400
  │  └─ Validation Error
  │     └─ Show form error message
  │
  ├─ Status 404
  │  └─ Not Found
  │     └─ Show alert or redirect
  │
  ├─ Status 403
  │  └─ Access Denied
  │     └─ Redirect to signin
  │
  └─ Status 500
     └─ Server Error
        └─ Show error message & retry option
```

## Key Sequences

### Sequence 1: Add Address & Place COD Order
```
1. [FE] User fills address form
2. [FE] Validates all fields
3. [FE] POST /api/user/addresses
4. [BE] Validate, fetch user, add address, save
5. [FE] Address added to list
6. [FE] Address selected
7. [FE] User selects COD, clicks Place Order
8. [FE] POST /api/orders/create
9. [BE] Create order in DB 4, update user lists
10. [FE] Clear cart
11. [FE] Navigate to /orders
12. [User] See order confirmation
```

### Sequence 2: Select Existing Address & Place Online Order
```
1. [FE] CheckoutPage fetches addresses
2. [FE] Display addresses list
3. [FE] Default address pre-selected
4. [FE] User selects Online payment
5. [FE] Clicks Place Order
6. [FE] POST /api/orders/create
7. [BE] Create order (status: pending, payment: initiated)
8. [FE] Navigate to /payment/:orderId
9. [FE] Display order summary
10. [FE] POST /api/payment/initiate
11. [BE] Create payment session (TTL: 30 min)
12. [FE] Show payment form
13. [FE] User enters card details
14. [FE] POST /api/payment/confirm
15. [BE] Update order (status: confirmed, payment: completed)
16. [FE] Show success page
17. [FE] Navigate to /orders
```
