# Seller Backend

Flask API for seller authentication and product management.

## Setup

1. Make sure Redis is running (same Redis instance as main backend)

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the server:
```bash
python api.py
```

The server will run on http://localhost:5001

## Configuration

The backend uses the same Redis instance as the main backend:
- **REDIS_HOST**: Default `localhost` (or use environment variable)
- **REDIS_PORT**: Default `6379` (or use environment variable)
- **Redis DB 1**: Seller sessions
- **Redis DB 2**: Seller data (sellers, stores, products)

## Data Storage

All data is stored in **Redis** (no SQLite database):
- `seller:{id}` - Seller account information (hash)
- `seller:{id}:store` - Store information (hash)
- `seller:{id}:products` - Set of product IDs
- `seller:{id}:product:{product_id}` - Product details (hash)
- `seller:emails` - Email to seller_id mapping (hash)
- `seller:id_counter` - Auto-increment counter for seller IDs
- `seller:{id}:product_id_counter` - Auto-increment counter for product IDs

See [REDIS_STRUCTURE.md](../REDIS_STRUCTURE.md) for detailed data structure documentation.
