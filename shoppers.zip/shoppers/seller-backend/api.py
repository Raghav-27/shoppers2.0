from flask import Flask, request, jsonify, session
from flask_cors import CORS
from flask_session import Session
from werkzeug.security import generate_password_hash, check_password_hash
import os
from datetime import datetime
import secrets
import redis
import requests
import json

app = Flask(__name__)
app.secret_key = os.environ.get('SELLER_SECRET_KEY', secrets.token_hex(32))

# Backend URL for triggering indexing
BACKEND_URL = os.getenv('BACKEND_URL', 'http://localhost:5000')

# Redis configuration (using same Redis as main backend)
REDIS_HOST = os.getenv('REDIS_HOST', 'localhost')
REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))

# Redis client for seller data (DB 2)
redis_client = redis.Redis(
    host=REDIS_HOST,
    port=REDIS_PORT,
    db=2,
    decode_responses=True
)

# Redis client for products (DB 1) - matches admin expectations
redis_products = redis.Redis(
    host=REDIS_HOST,
    port=REDIS_PORT,
    db=1,
    decode_responses=True
)

# Configure Flask session to use Redis
app.config['SESSION_TYPE'] = 'redis'
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_USE_SIGNER'] = True
app.config['SESSION_KEY_PREFIX'] = 'seller:'
app.config['SESSION_REDIS'] = redis.Redis(
    host=REDIS_HOST,
    port=REDIS_PORT,
    db=1
    # NO decode_responses here - Flask-Session uses binary data
)

# Initialize Flask-Session
Session(app)

# CORS configuration
CORS(app, supports_credentials=True, origins=[
    'http://localhost:3000',
    'http://localhost:80',
    'http://localhost:3001',
    os.environ.get('FRONTEND_URL', '')
])

# ====================== HELPER FUNCTIONS ======================

def get_next_seller_id():
    """Generate next seller ID using Redis counter"""
    return str(redis_client.incr('seller:id_counter'))

def get_next_product_id(seller_id):
    """Generate next product ID for a seller"""
    return str(redis_client.incr(f'seller:{seller_id}:product_id_counter'))

def get_next_store_id(seller_id):
    """Generate next store ID for a seller"""
    return str(redis_client.incr(f'seller:{seller_id}:store_id_counter'))

def trigger_indexing():
    """Trigger async indexing of seller products in backend"""
    try:
        response = requests.post(
            f"{BACKEND_URL}/api/seller/products/index",
            timeout=5
        )
        if response.status_code == 200:
            print(f"✅ Indexing triggered successfully: {response.json()}")
        else:
            print(f"⚠️ Indexing trigger failed: {response.status_code}")
    except Exception as e:
        print(f"⚠️ Indexing trigger error (non-blocking): {str(e)}")

# ====================== HEALTH CHECK ======================

@app.route('/', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'running',
        'service': 'seller-backend',
        'version': '1.0.0'
    }), 200

# ====================== SELLER AUTHENTICATION ======================

@app.route('/api/seller/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('email') or not data.get('password') or not data.get('business_name'):
            return jsonify({'error': 'Email, password, and business name are required'}), 400
        
        email = data['email'].lower().strip()
        
        # Check if email already exists (use new key pattern)
        if redis_client.hexists('seller:email:lookup', email):
            return jsonify({'error': 'Email already registered'}), 400
        
        # Get next seller ID
        seller_id = get_next_seller_id()
        
        # Hash password
        password_hash = generate_password_hash(data['password'])
        
        # Store seller information in Redis (use seller:info:{id} pattern for admin compatibility)
        seller_data = {
            'seller_id': seller_id,
            'email': email,
            'password_hash': password_hash,
            'business_name': data.get('business_name', ''),
            'contact_person': data.get('contact_person', ''),
            'phone': data.get('phone', ''),
            'address': data.get('address', ''),
            'verified': '0',
            'status': 'active',
            'created_at': datetime.now().isoformat(),
            'total_orders': '0'
        }
        redis_client.hset(f'seller:info:{seller_id}', mapping=seller_data)
        
        # Store email -> seller_id mapping (use new key pattern)
        redis_client.hset('seller:email:lookup', email, seller_id)
        
        # Add to seller:all set (CRITICAL for admin dashboard)
        redis_client.sadd('seller:all', seller_id)
        
        # Store business/store information (keep for backward compatibility)
        store_data = {
            'business_name': data.get('business_name', ''),
            'contact_person': data.get('contact_person', ''),
            'phone': data.get('phone', ''),
            'address': data.get('address', ''),
            'created_at': datetime.now().isoformat()
        }
        redis_client.hset(f'seller:{seller_id}:store', mapping=store_data)
        
        # Initialize empty products set
        # (Set will be created when first product is added)
        
        # Create session
        session['seller_id'] = seller_id
        session['email'] = email
        
        return jsonify({
            'message': 'Registration successful',
            'seller': {
                'id': seller_id,
                'email': email,
                'business_name': data.get('business_name')
            }
        }), 201
        
    except Exception as e:
        print(f"Registration error: {str(e)}")
        return jsonify({'error': 'Registration failed'}), 500


@app.route('/api/seller/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        
        if not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Email and password are required'}), 400
        
        email = data['email'].lower().strip()
        
        # Get seller_id from email (use new key pattern)
        seller_id = redis_client.hget('seller:email:lookup', email)
        
        if not seller_id:
            return jsonify({'error': 'Invalid email or password'}), 401
        
        # Get seller data (use new key pattern)
        seller_data = redis_client.hgetall(f'seller:info:{seller_id}')
        
        if not seller_data or seller_data.get('status') != 'active':
            return jsonify({'error': 'Account not found or inactive'}), 401
        
        # Verify password (use password_hash field)
        if not check_password_hash(seller_data['password_hash'], data['password']):
            return jsonify({'error': 'Invalid email or password'}), 401
        
        # Get business name from seller data
        business_name = seller_data.get('business_name', '')
        
        # Create session
        session['seller_id'] = seller_id
        session['email'] = email
        
        return jsonify({
            'message': 'Login successful',
            'seller': {
                'id': seller_id,
                'email': email,
                'business_name': business_name
            }
        }), 200
        
    except Exception as e:
        print(f"Login error: {str(e)}")
        return jsonify({'error': 'Login failed'}), 500

@app.route('/api/seller/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'message': 'Logged out successfully'}), 200

@app.route('/api/seller/profile', methods=['GET'])
def get_profile():
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        # Get seller data
        seller_data = redis_client.hgetall(f'seller:{seller_id}')
        store_data = redis_client.hgetall(f'seller:{seller_id}:store')
        
        if not seller_data:
            return jsonify({'error': 'Seller not found'}), 404
        
        return jsonify({
            'seller': {
                'id': seller_data.get('id'),
                'email': seller_data.get('email'),
                'created_at': seller_data.get('created_at')
            },
            'store': {
                'business_name': store_data.get('business_name'),
                'contact_person': store_data.get('contact_person'),
                'phone': store_data.get('phone'),
                'address': store_data.get('address')
            }
        }), 200
        
    except Exception as e:
        print(f"Profile error: {str(e)}")
        return jsonify({'error': 'Failed to fetch profile'}), 500

# ====================== PRODUCT MANAGEMENT ======================

@app.route('/api/seller/products', methods=['GET'])
def get_products():
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        # Get all product IDs for this seller (from DB 1)
        product_ids = redis_products.smembers(f'seller:prod:list:{seller_id}')
        
        products = []
        for product_id in product_ids:
            product_data = redis_products.hgetall(f'seller:prod:{seller_id}:{product_id}')
            if product_data and product_data.get('is_active') == '1':
                # Add IDs for frontend
                product_data['id'] = product_id
                product_data['seller_id'] = seller_id
                products.append(product_data)
        
        return jsonify({'products': products}), 200
        
    except Exception as e:
        print(f"Get products error: {str(e)}")
        return jsonify({'error': 'Failed to fetch products'}), 500

@app.route('/api/seller/products', methods=['POST'])
def add_product():
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'price', 'category']
        if not all(field in data for field in required_fields):
            return jsonify({'error': 'Name, price, and category are required'}), 400
        
        # Get next product ID
        product_id = get_next_product_id(seller_id)
        
        # Create product data (admin-compatible schema)
        product_data = {
            'name': data['name'],
            'description': data.get('description', ''),
            'price': str(data['price']),
            'category': data['category'],
            'stock': str(data.get('stock', 0)),
            'image_url': data.get('image_url', ''),
            'images': data.get('image_url', ''),  # Store as single image for now
            'is_active': '1',
            'store_id': data.get('store_id', ''),
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        
        # Store product in DB 1 using seller:prod pattern
        redis_products.hset(f'seller:prod:{seller_id}:{product_id}', mapping=product_data)
        
        # Add product ID to seller's products set in DB 1
        redis_products.sadd(f'seller:prod:list:{seller_id}', product_id)
        
        # Add to global seller:prod:all set (CRITICAL for admin dashboard)
        redis_products.sadd('seller:prod:all', f'{seller_id}:{product_id}')
        
        # Increment product count
        redis_products.incr(f'seller:prod:count:{seller_id}')
        
        # Trigger async indexing in background
        trigger_indexing()
        
        # Add IDs to response
        response_data = product_data.copy()
        response_data['id'] = product_id
        response_data['seller_id'] = seller_id
        
        return jsonify({
            'message': 'Product added successfully',
            'product': response_data
        }), 201
        
    except Exception as e:
        print(f"Add product error: {str(e)}")
        return jsonify({'error': f'Failed to add product: {str(e)}'}), 500

@app.route('/api/seller/products/<product_id>', methods=['PUT'])
def update_product(product_id):
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        # Verify product belongs to seller (from DB 1)
        product_data = redis_products.hgetall(f'seller:prod:{seller_id}:{product_id}')
        
        if not product_data:
            return jsonify({'error': 'Product not found'}), 404
        
        data = request.get_json()
        
        # Update fields
        update_data = {
            'name': data.get('name', product_data.get('name')),
            'description': data.get('description', product_data.get('description')),
            'price': str(data.get('price', product_data.get('price'))),
            'category': data.get('category', product_data.get('category')),
            'image_url': data.get('image_url', product_data.get('image_url')),
            'images': data.get('image_url', product_data.get('images')),
            'stock': str(data.get('stock', product_data.get('stock'))),
            'store_id': data.get('store_id', product_data.get('store_id', '')),
            'updated_at': datetime.now().isoformat()
        }
        
        # Merge with existing data
        product_data.update(update_data)
        
        # Update in Redis DB 1
        redis_products.hset(f'seller:prod:{seller_id}:{product_id}', mapping=product_data)
        
        # Trigger async indexing in background
        trigger_indexing()
        
        # Add IDs to response
        response_data = product_data.copy()
        response_data['id'] = product_id
        response_data['seller_id'] = seller_id
        
        return jsonify({
            'message': 'Product updated successfully',
            'product': response_data
        }), 200
        
    except Exception as e:
        print(f"Update product error: {str(e)}")
        return jsonify({'error': 'Failed to update product'}), 500

@app.route('/api/seller/products/<product_id>', methods=['DELETE'])
def delete_product(product_id):
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        # Verify product belongs to seller (from DB 1)
        product_data = redis_products.hgetall(f'seller:prod:{seller_id}:{product_id}')
        
        if not product_data:
            return jsonify({'error': 'Product not found'}), 404
        
        # Hard delete - completely remove from Redis DB 1
        # 1. Remove from seller's products set
        redis_products.srem(f'seller:prod:list:{seller_id}', product_id)
        
        # 2. Remove from global seller:prod:all set
        redis_products.srem('seller:prod:all', f'{seller_id}:{product_id}')
        
        # 3. Decrement product count
        redis_products.decr(f'seller:prod:count:{seller_id}')
        
        # 4. Delete the product hash itself
        redis_products.delete(f'seller:prod:{seller_id}:{product_id}')
        
        # 5. Trigger indexing to update search results
        trigger_indexing()
        
        return jsonify({'message': 'Product deleted successfully'}), 200
        
    except Exception as e:
        print(f"Delete product error: {str(e)}")
        return jsonify({'error': 'Failed to delete product'}), 500

@app.route('/api/seller/dashboard', methods=['GET'])
def get_dashboard():
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        # Get seller and store info (use new key pattern)
        seller_data = redis_client.hgetall(f'seller:info:{seller_id}')
        store_data = redis_client.hgetall(f'seller:{seller_id}:store')
        
        # Get product statistics (from DB 1)
        product_ids = redis_products.smembers(f'seller:prod:list:{seller_id}')
        active_products = 0
        total_products = len(product_ids)
        
        recent_products = []
        for product_id in list(product_ids)[:5]:  # Get last 5 products
            product_data = redis_products.hgetall(f'seller:prod:{seller_id}:{product_id}')
            if product_data:
                if product_data.get('is_active') == '1':
                    active_products += 1
                # Add IDs for frontend
                product_data['id'] = product_id
                product_data['seller_id'] = seller_id
                recent_products.append(product_data)
        
        # Get store count
        store_ids = redis_client.smembers(f'seller:{seller_id}:stores')
        total_stores = len([sid for sid in store_ids if redis_client.hget(f'seller:{seller_id}:store:{sid}', 'is_active') == '1'])
        
        return jsonify({
            'seller': {
                'id': seller_data.get('seller_id', seller_id),
                'email': seller_data.get('email'),
                'business_name': seller_data.get('business_name', store_data.get('business_name', ''))
            },
            'stats': {
                'total_stores': total_stores,
                'total_products': total_products,
                'active_products': active_products,
                'inactive_products': total_products - active_products
            },
            'recent_products': recent_products
        }), 200
        
    except Exception as e:
        print(f"Dashboard error: {str(e)}")
        return jsonify({'error': 'Failed to fetch dashboard data'}), 500

# ====================== STORE MANAGEMENT ======================

@app.route('/api/seller/stores', methods=['GET'])
def get_stores():
    """Get all stores for a seller"""
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        # Get all store IDs for this seller
        store_ids = redis_client.smembers(f'seller:{seller_id}:stores')
        
        stores = []
        for store_id in store_ids:
            store_data = redis_client.hgetall(f'seller:{seller_id}:store:{store_id}')
            if store_data and store_data.get('is_active') == '1':
                # Get product count for this store
                product_count = len(redis_client.smembers(f'seller:{seller_id}:store:{store_id}:products'))
                store_data['product_count'] = product_count
                stores.append(store_data)
        
        return jsonify({'stores': stores}), 200
        
    except Exception as e:
        print(f"Get stores error: {str(e)}")
        return jsonify({'error': 'Failed to fetch stores'}), 500

@app.route('/api/seller/stores', methods=['POST'])
def create_store():
    """Create a new store"""
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        data = request.get_json()
        
        # Validate required fields
        if not data.get('name'):
            return jsonify({'error': 'Store name is required'}), 400
        
        # Get next store ID
        store_id = get_next_store_id(seller_id)
        
        # Create store data
        store_data = {
            'id': store_id,
            'seller_id': seller_id,
            'name': data['name'],
            'description': data.get('description', ''),
            'image_url': data.get('image_url', ''),
            'address': data.get('address', ''),
            'phone': data.get('phone', ''),
            'email': data.get('email', ''),
            'is_active': '1',
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        
        # Store in Redis
        redis_client.hset(f'seller:{seller_id}:store:{store_id}', mapping=store_data)
        
        # Add store ID to seller's stores set
        redis_client.sadd(f'seller:{seller_id}:stores', store_id)
        
        return jsonify({
            'message': 'Store created successfully',
            'store': store_data
        }), 201
        
    except Exception as e:
        print(f"Create store error: {str(e)}")
        return jsonify({'error': f'Failed to create store: {str(e)}'}), 500

@app.route('/api/seller/stores/<store_id>', methods=['GET'])
def get_store(store_id):
    """Get a specific store with its products"""
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        # Get store data
        store_data = redis_client.hgetall(f'seller:{seller_id}:store:{store_id}')
        
        if not store_data:
            return jsonify({'error': 'Store not found'}), 404
        
        # Get products in this store
        product_ids = redis_client.smembers(f'seller:{seller_id}:store:{store_id}:products')
        products = []
        
        for product_id in product_ids:
            product_data = redis_client.hgetall(f'seller:{seller_id}:product:{product_id}')
            if product_data and product_data.get('is_active') == '1':
                products.append(product_data)
        
        store_data['products'] = products
        store_data['product_count'] = len(products)
        
        return jsonify({'store': store_data}), 200
        
    except Exception as e:
        print(f"Get store error: {str(e)}")
        return jsonify({'error': 'Failed to fetch store'}), 500

@app.route('/api/seller/stores/<store_id>', methods=['PUT'])
def update_store(store_id):
    """Update a store"""
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        # Verify store belongs to seller
        store_data = redis_client.hgetall(f'seller:{seller_id}:store:{store_id}')
        
        if not store_data:
            return jsonify({'error': 'Store not found'}), 404
        
        data = request.get_json()
        
        # Update fields
        update_data = {
            'name': data.get('name', store_data.get('name')),
            'description': data.get('description', store_data.get('description')),
            'image_url': data.get('image_url', store_data.get('image_url')),
            'address': data.get('address', store_data.get('address')),
            'phone': data.get('phone', store_data.get('phone')),
            'email': data.get('email', store_data.get('email')),
            'updated_at': datetime.now().isoformat()
        }
        
        # Merge with existing data
        store_data.update(update_data)
        
        # Update in Redis
        redis_client.hset(f'seller:{seller_id}:store:{store_id}', mapping=store_data)
        
        return jsonify({
            'message': 'Store updated successfully',
            'store': store_data
        }), 200
        
    except Exception as e:
        print(f"Update store error: {str(e)}")
        return jsonify({'error': 'Failed to update store'}), 500

@app.route('/api/seller/stores/<store_id>', methods=['DELETE'])
def delete_store(store_id):
    """Delete a store (soft delete)"""
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        # Verify store belongs to seller
        store_data = redis_client.hgetall(f'seller:{seller_id}:store:{store_id}')
        
        if not store_data:
            return jsonify({'error': 'Store not found'}), 404
        
        # Soft delete - mark as inactive
        redis_client.hset(f'seller:{seller_id}:store:{store_id}', 'is_active', '0')
        
        return jsonify({'message': 'Store deleted successfully'}), 200
        
    except Exception as e:
        print(f"Delete store error: {str(e)}")
        return jsonify({'error': 'Failed to delete store'}), 500

# ====================== ORDER MANAGEMENT ======================

# Redis client for orders (DB 4 - same as main backend)
redis_orders = redis.Redis(
    host=REDIS_HOST,
    port=REDIS_PORT,
    db=4,  # Same database as main backend orders
    decode_responses=True
)

@app.route('/api/seller/orders', methods=['GET'])
def get_seller_orders():
    """Get all orders for the logged-in seller"""
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        # Get all order IDs for this seller from main backend's order DB
        order_ids = redis_orders.smembers(f"seller_orders:{seller_id}")
        
        orders = []
        for order_id in order_ids:
            order_json = redis_orders.get(order_id)
            if order_json:
                try:
                    order = json.loads(order_json)
                    
                    # Filter items to only show this seller's products
                    seller_items = [
                        item for item in order.get('items', [])
                        if item.get('seller_id') == seller_id
                    ]
                    
                    if seller_items:
                        # Create seller-specific view of order
                        seller_order = {
                            'order_id': order.get('order_id'),
                            'user_name': order.get('user_name'),
                            'user_email': order.get('user_email'),
                            'phone': order.get('phone'),
                            'address': order.get('address'),
                            'items': seller_items,
                            'order_date': order.get('order_date'),
                            'seller_status': order.get('seller_status', 'pending'),
                            'buyer_status': order.get('buyer_status', 'awaiting_delivery'),
                            'delivery_status': order.get('delivery_status', 'pending'),
                            'payment_method': order.get('payment_method'),
                            'payment_status': order.get('payment_status'),
                            'seller_total': sum(
                                float(item.get('price', 0)) * int(item.get('quantity', 1))
                                for item in seller_items
                            )
                        }
                        orders.append(seller_order)
                except json.JSONDecodeError:
                    print(f"Error parsing order {order_id}")
                    continue
        
        # Sort by date descending
        orders.sort(key=lambda x: x.get('order_date', ''), reverse=True)
        
        return jsonify({
            'success': True,
            'orders': orders,
            'total_orders': len(orders)
        }), 200
        
    except Exception as e:
        print(f"Get seller orders error: {str(e)}")
        return jsonify({'error': 'Failed to fetch orders'}), 500

@app.route('/api/seller/orders/<order_id>', methods=['GET'])
def get_seller_order_details(order_id):
    """Get details of a specific order for the seller"""
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        # Get order from main backend's order DB
        order_json = redis_orders.get(order_id)
        
        if not order_json:
            return jsonify({'error': 'Order not found'}), 404
        
        try:
            order = json.loads(order_json)
            
            # Verify this seller has items in this order
            seller_items = [
                item for item in order.get('items', [])
                if item.get('seller_id') == seller_id
            ]
            
            if not seller_items:
                return jsonify({'error': 'Order not accessible to this seller'}), 403
            
            # Return order with seller-specific details
            seller_order = {
                'order_id': order.get('order_id'),
                'user_name': order.get('user_name'),
                'user_email': order.get('user_email'),
                'phone': order.get('phone'),
                'address': order.get('address'),
                'items': seller_items,
                'order_date': order.get('order_date'),
                'seller_status': order.get('seller_status', 'pending'),
                'buyer_status': order.get('buyer_status', 'awaiting_delivery'),
                'delivery_status': order.get('delivery_status', 'pending'),
                'payment_method': order.get('payment_method'),
                'payment_status': order.get('payment_status'),
                'seller_total': sum(
                    float(item.get('price', 0)) * int(item.get('quantity', 1))
                    for item in seller_items
                )
            }
            
            return jsonify({
                'success': True,
                'order': seller_order
            }), 200
            
        except json.JSONDecodeError:
            return jsonify({'error': 'Invalid order data'}), 500
        
    except Exception as e:
        print(f"Get order details error: {str(e)}")
        return jsonify({'error': 'Failed to fetch order details'}), 500

@app.route('/api/seller/orders/<order_id>/status', methods=['PUT'])
def update_seller_order_status(order_id):
    """Update order status from seller side (confirmed, processing, shipped, delivered)"""
    try:
        seller_id = session.get('seller_id')
        
        if not seller_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        data = request.get_json()
        new_seller_status = data.get('seller_status', '').lower()
        
        # Validate seller status
        valid_seller_statuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered']
        if new_seller_status not in valid_seller_statuses:
            return jsonify({'error': f'Invalid seller status. Must be one of: {", ".join(valid_seller_statuses)}'}), 400
        
        # Get order
        order_json = redis_orders.get(order_id)
        if not order_json:
            return jsonify({'error': 'Order not found'}), 404
        
        try:
            order = json.loads(order_json)
            
            # Verify seller has items in this order
            seller_items = [
                item for item in order.get('items', [])
                if item.get('seller_id') == seller_id
            ]
            
            if not seller_items:
                return jsonify({'error': 'Order not accessible to this seller'}), 403
            
            # Update seller status
            order['seller_status'] = new_seller_status
            order['updated_at'] = datetime.now().isoformat()
            
            # When seller marks as delivered, set delivery status for buyer
            if new_seller_status == 'delivered':
                order['delivery_status'] = 'awaiting_buyer_confirmation'
                order['buyer_status'] = 'awaiting_delivery'
            
            # Store updated order
            redis_orders.set(order_id, json.dumps(order))
            
            return jsonify({
                'success': True,
                'message': f'Order marked as {new_seller_status}',
                'order_id': order_id,
                'seller_status': new_seller_status,
                'delivery_status': order.get('delivery_status', 'pending')
            }), 200
            
        except json.JSONDecodeError:
            return jsonify({'error': 'Invalid order data'}), 500
        
    except Exception as e:
        print(f"Update order status error: {str(e)}")
        return jsonify({'error': 'Failed to update order status'}), 500


if __name__ == '__main__':
    print("Starting Seller Backend API on port 5001...")
    print(f"Redis Host: {REDIS_HOST}:{REDIS_PORT}")
    app.run(host='0.0.0.0', port=5001, debug=True)
