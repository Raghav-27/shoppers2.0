# Dark Mode Implementation Guide

## Overview
A comprehensive dark mode feature has been added to the Shoppers application, allowing users to toggle between light and dark themes with persistent preferences.

## Features

### 🌓 Theme Toggle
- **Location**: Navbar (top right, next to search button)
- **Icons**: Sun icon for light mode, Moon icon for dark mode
- **Animation**: Smooth rotation effect on hover

### 💾 Persistent Preferences
- Theme preference is saved to `localStorage`
- Automatically loads saved theme on app startup
- Preference persists across browser sessions

### 🎨 Theme Colors

#### Light Mode
- Background: White and light grays
- Text: Dark blacks and grays
- Accent: Medium sea green (#2e8b57)
- Cards: White backgrounds with subtle shadows

#### Dark Mode
- Background: Deep blacks (#121212, #1a1a1a)
- Text: Light grays and whites
- Accent: Brighter green (#3da869)
- Cards: Dark gray backgrounds (#1e1e1e) with stronger shadows

## Implementation Details

### Context API
**File**: `src/contexts/ThemeContext.js`
- Provides `isDarkMode` state
- Provides `toggleTheme` function
- Manages localStorage persistence
- Applies/removes `dark-mode` class on document root

### CSS Variables
**File**: `src/index.css`
```css
:root {
  --bg-primary, --bg-secondary, --bg-tertiary
  --text-primary, --text-secondary, --text-tertiary
  --border-color
  --shadow-sm, --shadow-md, --shadow-lg
  --green-primary, --green-secondary, --green-light
  --card-bg, --input-bg
}
```

### Affected Components
All major components have been updated with dark mode support:
- ✅ App.js & App.css
- ✅ Navbar.js & Navbar.css
- ✅ ProductCard.css
- ✅ ProductsPage.css
- ✅ ComparePage.css
- ✅ SignIn.css
- ✅ SignUp.css
- ✅ SearchBar.css
- ✅ ListPage.css (Wishlist, Cart)
- ✅ Footer.css (already dark, works with both modes)

## Usage

### For Users
1. Click the sun/moon icon in the navbar
2. Theme switches instantly
3. Preference is remembered on next visit

### For Developers

#### Using Theme in Components
```javascript
import { useTheme } from '../contexts/ThemeContext';

function MyComponent() {
  const { isDarkMode, toggleTheme } = useTheme();
  
  return (
    <div>
      <p>Current mode: {isDarkMode ? 'Dark' : 'Light'}</p>
      <button onClick={toggleTheme}>Toggle Theme</button>
    </div>
  );
}
```

#### Using Theme in CSS
Use CSS variables instead of hardcoded colors:
```css
.my-element {
  background: var(--card-bg);
  color: var(--text-primary);
  border: 1px solid var(--border-color);
  box-shadow: 0 2px 8px var(--shadow-sm);
}
```

## Smooth Transitions
All color-related properties transition smoothly:
```css
* {
  transition: background-color 0.3s ease, border-color 0.3s ease;
}
```

## Browser Compatibility
- ✅ Chrome/Edge (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Mobile browsers

## Future Enhancements
- [ ] Auto-detect system theme preference
- [ ] Schedule-based theme switching
- [ ] Custom theme colors
- [ ] High contrast mode
- [ ] Theme preview before applying

## Technical Notes

### Why CSS Variables?
- Single source of truth for colors
- Easy to maintain and update
- Better performance than inline styles
- Works seamlessly with existing CSS

### Why Context API?
- Global state management
- Avoids prop drilling
- Clean component integration
- Easy to test and mock

## Troubleshooting

### Theme doesn't persist
Check browser's localStorage is enabled and not in private mode.

### Colors look wrong
Ensure all CSS files use CSS variables (--var-name) instead of hardcoded colors.

### Toggle button not visible
Check that ThemeProvider wraps the entire App component in index.js.

## Credits
Implemented: November 2025
Dark mode design follows modern UI/UX best practices with careful attention to contrast ratios and accessibility.
