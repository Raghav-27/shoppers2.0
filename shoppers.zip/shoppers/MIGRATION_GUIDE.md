# Migration Guide: Address & Payment Features

## What's New

This update adds comprehensive address management and payment gateway integration to the Shoppers application.

### New Features

1. **Address Management System**
   - Save multiple delivery addresses
   - Mark default address
   - Full CRUD operations (Create, Read, Update, Delete)
   - Address validation

2. **Payment Gateway Integration**
   - Cash on Delivery (COD)
   - Online Payment support
   - Payment session management
   - Transaction tracking

3. **Enhanced Checkout Experience**
   - Address selection from saved addresses
   - Add new address during checkout
   - Payment method selection
   - Clear order summary

## What Changed

### Backend (API)

**New Endpoints:**
```
POST   /api/user/addresses          - Add new address
GET    /api/user/addresses          - Get all addresses
PUT    /api/user/addresses/{id}     - Update address
DELETE /api/user/addresses/{id}     - Delete address
POST   /api/payment/initiate        - Initiate payment
GET    /api/payment/status/{id}     - Get payment status
POST   /api/payment/confirm         - Confirm payment
```

**Data Storage:**
- Addresses stored in DB 0 as part of user data
- Orders stored in DB 4 (new dedicated database)
- Payment sessions stored in DB 0 with 30-minute TTL

### Frontend (React)

**New Components:**
- `PaymentPage.js` - Payment processing interface

**Updated Components:**
- `CheckoutPage.js` - Enhanced with address management
- `App.js` - Added payment route

**New Styles:**
- `PaymentPage.css` - Complete payment interface styling
- Updated `CheckoutPage.css` - Address management styles

## Migration Steps

### Step 1: Database Preparation
Ensure your Redis instance has DB 4 available. No migration needed - the system will create orders in DB 4 automatically.

### Step 2: Backend Updates
1. Update `backend/api.py` with new endpoints (already done)
2. Verify `order_manager.py` uses DB 4 (already configured)
3. Restart backend service

### Step 3: Frontend Updates
1. Update `src/App.js` - Add PaymentPage import and route (already done)
2. Update `src/components/CheckoutPage.js` - Add address management (already done)
3. Add `src/components/PaymentPage.js` - New component (already done)
4. Update styles - CSS files updated (already done)

### Step 4: Configuration
No new environment variables required. System uses:
- `REACT_APP_API_URL` - Same as before

### Step 5: Testing
1. **Test Address Management:**
   ```bash
   # Add address during checkout
   # Verify address saved in DB 0
   # Select saved address
   # Edit and delete addresses
   ```

2. **Test Payment Flow:**
   ```bash
   # Place COD order
   # Place online payment order
   # Use demo buttons to test payment success/failure
   # Verify order in DB 4
   ```

## Backward Compatibility

### Existing Users
- Existing orders continue to work
- No changes to cart, wishlist, or compare features
- User authentication unchanged

### Existing Orders
- Orders created before update won't have address details
- New orders will have full address information
- Old order history remains accessible

## Rollback Plan

If needed to rollback:

1. **Remove new endpoints** from `backend/api.py`
2. **Remove PaymentPage** from frontend
3. **Revert CheckoutPage** to previous version
4. **Remove payment route** from App.js
5. **Clear payment sessions** from Redis DB 0 (optional)

## Verification Checklist

- [ ] Backend starts without errors
- [ ] Frontend compiles without warnings
- [ ] Can add address during checkout
- [ ] Can select existing address
- [ ] Can place COD order
- [ ] Can place online payment order
- [ ] Payment page loads correctly
- [ ] Orders appear in order history
- [ ] Addresses persist in database

## Troubleshooting

### Issue: "User not found" error
**Solution:** Ensure user is logged in and session is valid

### Issue: Address form won't submit
**Solution:** Verify all fields are filled and phone is 10 digits

### Issue: Payment page shows error
**Solution:** Check browser console and backend logs for API errors

### Issue: Address not saving
**Solution:** Verify Redis DB 0 is accessible from backend

### Issue: Orders not appearing
**Solution:** Verify Redis DB 4 exists and is accessible

## Performance Considerations

- Address operations are O(n) where n = number of addresses (typically small)
- Payment session expires after 30 minutes to save memory
- Order queries by user_id are efficient

## Security Updates

1. **Session Validation**: All endpoints verify user session
2. **Address Isolation**: Users can only access their own addresses
3. **Payment Authentication**: Payment sessions are user-specific
4. **Transaction Tracking**: Each payment has unique transaction ID

## Future Updates

Planned enhancements:
- Real payment gateway integration (Razorpay, Stripe)
- Order tracking
- Email notifications
- Invoice generation
- Address auto-complete

## Support

For issues:
1. Check backend logs: `docker logs <backend-container>`
2. Check browser console: F12 -> Console tab
3. Check Redis connection: `redis-cli PING`
4. Verify network requests: F12 -> Network tab

## Documentation

See `ADDRESS_PAYMENT_GUIDE.md` for complete API documentation.
