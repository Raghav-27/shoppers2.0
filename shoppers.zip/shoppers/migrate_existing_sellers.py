"""
Migration Script: Convert Legacy Seller Data to New Format

This script migrates existing sellers from the old Redis key pattern to the new one:
- Old: seller:{id} → New: seller:info:{id}
- Old: seller:emails → New: seller:email:lookup
- Adds seller_id to seller:all set
- Migrates old products to new DB 1 structure

Run this ONCE to migrate existing data.
"""
import redis
from datetime import datetime

REDIS_HOST = 'localhost'
REDIS_PORT = 6379

def migrate_sellers():
    """Migrate sellers from old to new format"""
    print("=" * 60)
    print("SELLER DATA MIGRATION")
    print("=" * 60)
    
    # Connect to Redis DB 2 (Sellers)
    r2 = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=2, decode_responses=True)
    
    # Connect to Redis DB 1 (Products)
    r1 = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=1, decode_responses=True)
    
    # Step 1: Find all legacy seller keys (pattern: seller:{id} where id is numeric)
    print("\n1. Scanning for legacy seller keys...")
    
    legacy_sellers = []
    for key in r2.scan_iter('seller:*'):
        # Check if it's a legacy seller key (seller:{id}, not seller:info:{id} or seller:emails)
        if key.startswith('seller:') and not key.startswith('seller:info:') \
           and not key.startswith('seller:email') and ':' not in key.replace('seller:', ''):
            # Check if it's numeric ID
            try:
                seller_id = key.replace('seller:', '')
                int(seller_id)  # Verify it's a number
                legacy_sellers.append(seller_id)
            except ValueError:
                pass
    
    print(f"   Found {len(legacy_sellers)} legacy seller(s): {legacy_sellers}")
    
    if not legacy_sellers:
        print("\n✅ No legacy sellers to migrate!")
        return
    
    # Step 2: Check what's already in the new format
    current_seller_all = r2.smembers('seller:all')
    current_email_lookup = r2.hgetall('seller:email:lookup')
    
    print(f"\n2. Current state:")
    print(f"   seller:all set: {current_seller_all}")
    print(f"   seller:email:lookup: {list(current_email_lookup.keys())}")
    
    # Step 3: Migrate each seller
    print(f"\n3. Migrating sellers...")
    
    for seller_id in legacy_sellers:
        print(f"\n   Migrating seller:{seller_id}...")
        
        # Get old data
        old_key = f'seller:{seller_id}'
        old_data = r2.hgetall(old_key)
        
        if not old_data:
            print(f"      ⚠️  No data found for {old_key}, skipping")
            continue
        
        print(f"      Old data: {old_data.get('email', 'N/A')}")
        
        # Check if already migrated
        new_key = f'seller:info:{seller_id}'
        if r2.exists(new_key):
            print(f"      ⚠️  Already exists: {new_key}, skipping")
            continue
        
        # Get store data if exists
        store_key = f'seller:{seller_id}:store'
        store_data = r2.hgetall(store_key)
        
        # Transform to new format
        new_data = {
            'seller_id': seller_id,
            'email': old_data.get('email', ''),
            'password_hash': old_data.get('password', ''),  # Rename password → password_hash
            'business_name': store_data.get('business_name', old_data.get('business_name', '')),
            'contact_person': store_data.get('contact_person', old_data.get('contact_person', '')),
            'phone': old_data.get('phone', store_data.get('phone', '')),
            'address': old_data.get('address', store_data.get('address', '')),
            'verified': '0',
            'status': 'active' if old_data.get('is_active') == '1' else 'inactive',
            'created_at': old_data.get('created_at', datetime.now().isoformat()),
            'total_orders': '0'
        }
        
        # Create new seller:info:{id} key
        r2.hset(new_key, mapping=new_data)
        print(f"      ✅ Created {new_key}")
        
        # Add to seller:all set
        r2.sadd('seller:all', seller_id)
        print(f"      ✅ Added to seller:all set")
        
        # Add to seller:email:lookup
        email = new_data['email']
        if email:
            r2.hset('seller:email:lookup', email, seller_id)
            print(f"      ✅ Added to seller:email:lookup: {email}")
        
        # Migrate products
        print(f"      Checking for products...")
        product_ids = r2.smembers(f'seller:{seller_id}:products')
        
        if product_ids:
            print(f"      Found {len(product_ids)} product(s) to migrate")
            
            for product_id in product_ids:
                old_prod_key = f'seller:{seller_id}:product:{product_id}'
                old_prod_data = r2.hgetall(old_prod_key)
                
                if not old_prod_data:
                    continue
                
                # Transform product data to new format (DB 1)
                new_prod_key = f'seller:prod:{seller_id}:{product_id}'
                new_prod_data = {
                    'name': old_prod_data.get('name', ''),
                    'description': old_prod_data.get('description', ''),
                    'price': old_prod_data.get('price', '0'),
                    'category': old_prod_data.get('category', ''),
                    'stock': old_prod_data.get('stock_quantity', old_prod_data.get('stock', '0')),
                    'image_url': old_prod_data.get('image_url', ''),
                    'images': old_prod_data.get('images', old_prod_data.get('image_url', '')),
                    'is_active': old_prod_data.get('is_active', '1'),
                    'store_id': old_prod_data.get('store_id', ''),
                    'created_at': old_prod_data.get('created_at', datetime.now().isoformat()),
                    'updated_at': old_prod_data.get('updated_at', datetime.now().isoformat())
                }
                
                # Store in DB 1 (Products)
                r1.hset(new_prod_key, mapping=new_prod_data)
                r1.sadd(f'seller:prod:list:{seller_id}', product_id)
                r1.sadd('seller:prod:all', f'{seller_id}:{product_id}')
                
                print(f"         ✅ Migrated product {product_id}: {new_prod_data['name']}")
            
            # Update product count
            r1.set(f'seller:prod:count:{seller_id}', len(product_ids))
            print(f"      ✅ Migrated {len(product_ids)} products to DB 1")
        else:
            print(f"      No products to migrate")
        
        print(f"   ✅ Seller {seller_id} migration complete!")
    
    # Step 4: Verify migration
    print(f"\n4. Verifying migration...")
    
    final_seller_all = r2.smembers('seller:all')
    final_email_lookup = r2.hgetall('seller:email:lookup')
    final_prod_all = r1.smembers('seller:prod:all')
    
    print(f"\n   Final state:")
    print(f"   seller:all set: {final_seller_all}")
    print(f"   seller:email:lookup: {list(final_email_lookup.keys())}")
    print(f"   seller:prod:all: {final_prod_all}")
    
    print(f"\n{'=' * 60}")
    print(f"✅ MIGRATION COMPLETE!")
    print(f"{'=' * 60}")
    print(f"\nMigrated {len(legacy_sellers)} seller(s)")
    print(f"\nNext steps:")
    print(f"1. Refresh the admin dashboard")
    print(f"2. Verify sellers appear in the dashboard")
    print(f"3. If everything works, you can safely delete old keys:")
    print(f"   - seller:{{id}} keys (old format)")
    print(f"   - seller:emails hash (old email lookup)")
    print(f"   - seller:{{id}}:product:{{id}} keys (old products in DB 2)")

if __name__ == "__main__":
    try:
        migrate_sellers()
    except Exception as e:
        print(f"\n❌ Migration failed: {e}")
        import traceback
        traceback.print_exc()
