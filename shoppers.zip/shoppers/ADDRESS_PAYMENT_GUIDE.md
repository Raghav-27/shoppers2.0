# Address Management & Payment Gateway Integration

## Overview
This document describes the new features added to the Shoppers application:
1. **Address Management System** - Users can add, select, update, and delete delivery addresses
2. **Payment Gateway Integration** - Support for both Cash on Delivery (COD) and Online payments
3. **Order Management** - Orders are now stored in a dedicated Redis database (DB 4)

## Database Structure

### Redis Databases Used
- **DB 0**: User data (existing) - Stores user information and now includes addresses
- **DB 4**: Orders (new) - Stores all order information

### User Data Structure (DB 0)
```json
{
  "first_name": "John",
  "last_name": "Doe",
  "email": "john@example.com",
  "phone": "+91-9876543210",
  "country": "India",
  "password_hash": "...",
  "addresses": [
    {
      "id": "addr_1_1234567890",
      "label": "Home",
      "phone": "9876543210",
      "street": "123 Main Street",
      "city": "Mumbai",
      "state": "Maharashtra",
      "postal_code": "400001",
      "country": "India",
      "is_default": true,
      "created_at": "2026-01-07T10:30:00"
    },
    {
      "id": "addr_2_1234567891",
      "label": "Office",
      "phone": "9876543211",
      "street": "Corporate Plaza",
      "city": "Bangalore",
      "state": "Karnataka",
      "postal_code": "560001",
      "country": "India",
      "is_default": false,
      "created_at": "2026-01-07T11:00:00",
      "updated_at": "2026-01-07T11:30:00"
    }
  ]
}
```

### Order Data Structure (DB 4)
```json
{
  "order_id": "order_1234567890_user@example.com",
  "user_id": "user@example.com",
  "user_name": "John Doe",
  "user_email": "user@example.com",
  "phone": "9876543210",
  "address": "123 Main Street, Mumbai, Maharashtra 400001, India",
  "items": [
    {
      "product_id": "prod_123",
      "seller_id": "seller_1",
      "seller_name": "Shoppers Seller",
      "product_name": "Sample Product",
      "price": 999.99,
      "quantity": 2,
      "image": "https://example.com/image.jpg",
      "category": "Electronics"
    }
  ],
  "total_amount": 1999.98,
  "order_date": "2026-01-07T12:00:00",
  "status": "pending",
  "payment_method": "online",
  "payment_status": "completed",
  "transaction_id": "TXN1234567890",
  "created_at": "2026-01-07T12:00:00"
}
```

### Payment Session Structure (DB 0 - TTL: 30 minutes)
```json
{
  "session_id": "pay_order_1234567890_user@example.com_1234567890",
  "order_id": "order_1234567890_user@example.com",
  "user_id": "user@example.com",
  "amount": 1999.98,
  "currency": "INR",
  "status": "initiated",
  "payment_method": "online",
  "created_at": "2026-01-07T12:00:00"
}
```

## API Endpoints

### Address Management

#### Add New Address
```
POST /api/user/addresses
Content-Type: application/json

{
  "label": "Home",
  "phone": "9876543210",
  "street": "123 Main Street",
  "city": "Mumbai",
  "state": "Maharashtra",
  "postal_code": "400001",
  "country": "India",
  "is_default": false
}

Response (200):
{
  "success": true,
  "message": "Address added successfully",
  "address": { ... }
}
```

#### Get All User Addresses
```
GET /api/user/addresses

Response (200):
{
  "success": true,
  "addresses": [
    { ... },
    { ... }
  ]
}
```

#### Update Address
```
PUT /api/user/addresses/{address_id}
Content-Type: application/json

{
  "label": "Home Updated",
  "phone": "9876543210",
  "street": "456 New Street",
  "city": "Mumbai",
  "state": "Maharashtra",
  "postal_code": "400002",
  "country": "India",
  "is_default": true
}

Response (200):
{
  "success": true,
  "message": "Address updated successfully",
  "address": { ... }
}
```

#### Delete Address
```
DELETE /api/user/addresses/{address_id}

Response (200):
{
  "success": true,
  "message": "Address deleted successfully"
}
```

### Payment Gateway

#### Initiate Payment
```
POST /api/payment/initiate
Content-Type: application/json

{
  "order_id": "order_1234567890_user@example.com",
  "amount": 1999.98,
  "payment_method": "online"
}

Response (200):
{
  "success": true,
  "message": "Payment session initiated",
  "session_id": "pay_order_1234567890_user@example.com_1234567890",
  "payment_url": "/payment/pay_order_1234567890_user@example.com_1234567890",
  "amount": 1999.98,
  "order_id": "order_1234567890_user@example.com"
}
```

#### Get Payment Status
```
GET /api/payment/status/{session_id}

Response (200):
{
  "success": true,
  "session": { ... }
}
```

#### Confirm Payment (Webhook from Payment Gateway)
```
POST /api/payment/confirm
Content-Type: application/json

{
  "session_id": "pay_order_1234567890_user@example.com_1234567890",
  "transaction_id": "TXN1234567890",
  "status": "success"  // or "failed"
}

Response (200):
{
  "success": true,
  "message": "Payment success",
  "order_id": "order_1234567890_user@example.com"
}
```

## Frontend Components

### CheckoutPage.js
Enhanced with address management capabilities:

**Features:**
- Display all saved addresses
- Select from existing addresses
- Add new address inline
- Edit/Delete addresses (future enhancement)
- Payment method selection (COD or Online)
- Order summary display

**Key Props:**
- `isSignedIn`: Boolean - User authentication status
- `user`: Object - User information
- `userLists`: Object - User's wishlist, cart, compare lists
- `onUpdateLists`: Function - Callback to update user lists

**State Management:**
- `addresses`: Array of user addresses
- `selectedAddressId`: Currently selected address ID
- `showAddressForm`: Toggle address form visibility
- `paymentMethod`: Selected payment method (cod/online)
- `formData`: New address form data
- `formError`: Form validation errors

**Key Functions:**
- `fetchAddresses()`: Fetch user's saved addresses
- `handleAddAddress()`: Add new address
- `handlePlaceOrder()`: Place order and redirect to payment if needed

### PaymentPage.js (New)
Complete payment processing interface:

**Route:** `/payment/:orderId`

**Features:**
- Display order summary
- Accept card details (demo mode)
- Show payment processing status
- Success/Failed payment states
- Demo mode buttons for testing

**Key Props:**
- `isSignedIn`: Boolean - User authentication status
- `user`: Object - User information

**Payment Flow:**
1. User places order from CheckoutPage
2. If online payment selected, redirected to `/payment/:orderId`
3. Payment session is initiated
4. User enters card details (demo only)
5. Payment is confirmed with backend
6. On success: Redirected to `/orders`
7. On failure: Can retry payment

**Integration Points:**
- `/api/payment/initiate` - Initiate payment session
- `/api/payment/status/{session_id}` - Check payment status
- `/api/payment/confirm` - Confirm payment completion

## Checkout Flow

### For Cash on Delivery (COD)
```
1. User navigates to /checkout
2. Selects or adds delivery address
3. Selects COD payment method
4. Clicks "Place Order"
5. Order is created in DB 4
6. Cart is cleared
7. Redirected to /orders
```

### For Online Payment
```
1. User navigates to /checkout
2. Selects or adds delivery address
3. Selects Online payment method
4. Clicks "Place Order"
5. Order is created in DB 4 with status "pending"
6. Redirected to /payment/:orderId
7. Payment session is initiated
8. User enters payment details
9. Payment is confirmed
10. Order status updated to "confirmed"
11. Redirected to /orders
```

## Address Validation

All address fields are validated:
- **Label**: Required, non-empty string
- **Phone**: Required, must be exactly 10 digits
- **Street**: Required, non-empty string
- **City**: Required, non-empty string
- **State**: Required, non-empty string
- **Postal Code**: Required, non-empty string
- **Country**: Required, non-empty string

## Error Handling

### Backend Errors
- `404 User not found`: User session invalid
- `404 Address not found`: Requested address doesn't exist
- `403 Access denied`: User doesn't own the address
- `404 Order not found`: Order doesn't exist
- `403 Access denied`: User doesn't own the order

### Frontend Errors
- Form validation errors displayed in red
- API errors shown in alert dialogs
- Failed addresses marked with error messages

## Security Considerations

1. **Session-based Authentication**: All endpoints require valid session
2. **User Isolation**: Users can only access their own data
3. **CORS Protection**: Credentials included in all requests
4. **Payment Session TTL**: Payment sessions expire after 30 minutes
5. **Transaction ID**: Unique transaction ID for each payment

## Future Enhancements

1. **Real Payment Gateway Integration**
   - Razorpay integration
   - Stripe integration
   - PayPal integration

2. **Address Management**
   - Edit existing addresses
   - Bulk import addresses
   - Address auto-completion
   - Google Maps integration for address verification

3. **Payment Features**
   - EMI options
   - Wallet/Gift card support
   - Multiple payment methods
   - Payment retry mechanism

4. **Order Management**
   - Order tracking with status updates
   - Email notifications
   - SMS updates
   - Invoice generation
   - Return/Refund management

## Testing

### Manual Testing Checklist

**Address Management:**
- [ ] Add new address successfully
- [ ] Set address as default
- [ ] Edit existing address
- [ ] Delete address
- [ ] Form validation works
- [ ] Addresses persist in database

**Checkout Flow:**
- [ ] Select existing address
- [ ] Add new address during checkout
- [ ] Select COD payment
- [ ] Select Online payment
- [ ] Place order successfully
- [ ] Order appears in order history

**Payment Flow:**
- [ ] Payment page loads correctly
- [ ] Order summary displays
- [ ] Payment form accepts valid input
- [ ] Simulate success works
- [ ] Simulate failure works
- [ ] Retry payment works

### Demo Mode
The PaymentPage includes demo buttons to simulate payment success/failure:
- Click "Simulate Success" to complete payment
- Click "Simulate Failed" to simulate payment failure

## Configuration

No additional configuration needed. The system uses:
- Redis DB 0 for users and payment sessions
- Redis DB 4 for orders
- Environment variables for API URL

## Deployment Notes

1. Ensure Redis DB 4 is available
2. Update CORS_ORIGINS if needed
3. For production, integrate real payment gateway
4. Set up payment webhook endpoint
5. Configure email notifications
6. Set up order tracking system

## Support

For issues or questions:
1. Check backend logs for API errors
2. Check browser console for frontend errors
3. Verify Redis connectivity
4. Ensure session is valid
