"""
Complete Admin Dashboard Test Suite
"""
import requests
import json

ADMIN_URL = "http://localhost:5002"

def test_complete_admin_dashboard():
    """Test all admin dashboard endpoints"""
    
    print("=" * 70)
    print("COMPLETE ADMIN DASHBOARD TEST SUITE")
    print("=" * 70)
    
    # Login as admin
    session = requests.Session()
    
    print("\n1. Testing Admin Login...")
    login_response = session.post(
        f"{ADMIN_URL}/api/admin/login",
        json={"email": "admin@shoppers.com", "password": "admin123"}
    )
    
    if login_response.status_code != 200:
        print("❌ Admin login failed")
        return
    
    print("✅ Admin login successful")
    
    # Test Dashboard Stats
    print("\n2. Testing Dashboard Stats...")
    stats_response = session.get(f"{ADMIN_URL}/api/admin/dashboard/stats")
    
    if stats_response.status_code == 200:
        stats = stats_response.json()
        print(f"✅ Dashboard Stats Retrieved:")
        print(f"   - Users: {stats['users']['total']} (Admins: {stats['users']['admins']})")
        print(f"   - Sellers: {stats['sellers']['total']} (Active: {stats['sellers']['active']})")
        print(f"   - Products: {stats['products']['total']}")
        print(f"   - Orders: {stats['orders']['total']} (Pending: {stats['orders']['pending']})")
    else:
        print(f"❌ Dashboard stats failed: {stats_response.status_code}")
    
    # Test Users Management
    print("\n3. Testing Users Management...")
    users_response = session.get(
        f"{ADMIN_URL}/api/admin/users",
        params={"offset": 0, "limit": 50}
    )
    
    if users_response.status_code == 200:
        users_data = users_response.json()
        print(f"✅ Users Retrieved: {users_data['total']} user(s)")
        for user in users_data['users']:
            print(f"   - {user['first_name']} {user['last_name']} ({user['email']})")
    else:
        print(f"❌ Users fetch failed: {users_response.status_code}")
    
    # Test Sellers Management
    print("\n4. Testing Sellers Management...")
    sellers_response = session.get(
        f"{ADMIN_URL}/api/admin/sellers",
        params={"offset": 0, "limit": 20}
    )
    
    if sellers_response.status_code == 200:
        sellers_data = sellers_response.json()
        print(f"✅ Sellers Retrieved: {sellers_data['total']} seller(s)")
        for seller in sellers_data['sellers']:
            print(f"   - {seller['business_name']} ({seller['email']}) - {seller['status']}")
    else:
        print(f"❌ Sellers fetch failed: {sellers_response.status_code}")
    
    # Test Products View
    print("\n5. Testing Products View...")
    products_response = session.get(
        f"{ADMIN_URL}/api/admin/products",
        params={"offset": 0, "limit": 50}
    )
    
    if products_response.status_code == 200:
        products_data = products_response.json()
        print(f"✅ Products Retrieved: {products_data['total']} product(s)")
        for product in products_data.get('products', [])[:5]:  # Show first 5
            print(f"   - {product.get('name', 'N/A')} - ${product.get('price', 'N/A')}")
    else:
        print(f"❌ Products fetch failed: {products_response.status_code}")
    
    # Test Orders View
    print("\n6. Testing Orders View...")
    orders_response = session.get(
        f"{ADMIN_URL}/api/admin/orders",
        params={"offset": 0, "limit": 50}
    )
    
    if orders_response.status_code == 200:
        orders_data = orders_response.json()
        print(f"✅ Orders Retrieved: {orders_data['total']} order(s)")
        if orders_data['total'] > 0:
            for order in orders_data.get('orders', [])[:3]:
                print(f"   - Order {order.get('order_id', 'N/A')} - ${order.get('total_amount', 'N/A')}")
        else:
            print("   (No orders yet)")
    else:
        print(f"❌ Orders fetch failed: {orders_response.status_code}")
    
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    
    if all([
        stats_response.status_code == 200,
        users_response.status_code == 200,
        sellers_response.status_code == 200,
        products_response.status_code == 200,
        orders_response.status_code == 200
    ]):
        print("\n🎉 ALL TESTS PASSED!")
        print("\n✅ Admin Dashboard is fully functional:")
        print("   - Dashboard stats working")
        print("   - User management working")
        print("   - Seller management working")
        print("   - Product management working")
        print("   - Order management working")
        print("\nYou can now use the admin dashboard in the browser!")
    else:
        print("\n⚠️  Some tests failed. Check the output above for details.")
    
    print("=" * 70)

if __name__ == "__main__":
    test_complete_admin_dashboard()
