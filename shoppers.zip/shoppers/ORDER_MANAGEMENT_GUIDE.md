# Order Management System Guide

## Overview
Complete checkout and order management system for seller products with separate database storage, user order history, and seller order management.

## Architecture

### Database Structure
- **Redis DB 4**: Dedicated database for orders
- **Indexes**:
  - `user_orders:{user_id}`: Set of order IDs for each user
  - `seller_orders:{seller_id}`: Set of order IDs for each seller
  - `all_orders`: Global set of all order IDs
  - `order:{order_id}`: JSON object containing order details

### Order Schema
```json
{
  "order_id": "order_1735999999_user123",
  "user_id": "user123",
  "user_name": "John Doe",
  "user_email": "john@example.com",
  "phone": "+1234567890",
  "address": "123 Main St, City, State, ZIP",
  "items": [
    {
      "product_id": "seller_1_2",
      "seller_id": "1",
      "seller_name": "AAKASH RAGHAV",
      "product_name": "shoes",
      "price": 69,
      "quantity": 1,
      "image": "https://...",
      "category": "footwear",
      "status": "pending"
    }
  ],
  "total_amount": 69,
  "order_date": "2026-01-06T12:00:00Z",
  "status": "pending",
  "payment_method": "cod"
}
```

## Backend Components

### 1. OrderManager Class (`backend/order_manager.py`)

#### Methods:
- `connect()`: Initialize Redis connection to DB 4
- `create_order(user_id, user_name, user_email, phone, address, items, payment_method)`: Create new order
- `get_order(order_id)`: Retrieve single order
- `get_user_orders(user_id)`: Get all orders for a user (sorted by date)
- `get_seller_orders(seller_id)`: Get seller's orders with filtered items
- `update_order_status(order_id, status, seller_id=None, item_index=None)`: Update order/item status
- `cancel_order(order_id, user_id)`: Cancel order (pending/confirmed only)
- `close()`: Cleanup connection

#### Order ID Format:
`order_{timestamp}_{user_id}` - Ensures uniqueness and sortability

### 2. API Endpoints (`backend/api.py`)

#### User Endpoints:
- **POST `/api/orders/create`**
  - Body: `{ phone, address, items[], payment_method }`
  - Returns: Complete order object
  - Authentication: Required

- **GET `/api/orders/user`**
  - Returns: Array of user's orders (newest first)
  - Authentication: Required

- **GET `/api/orders/{order_id}`**
  - Returns: Single order details
  - Authentication: Required (ownership verified)

- **POST `/api/orders/{order_id}/cancel`**
  - Returns: Success message
  - Authentication: Required
  - Validation: Only pending/confirmed orders can be cancelled

#### Seller Endpoints:
- **GET `/api/seller/orders?seller_id={id}`**
  - Returns: Orders containing seller's products
  - Filters: Only shows items from this seller
  - Calculates: `seller_total` for payment

- **POST `/api/seller/orders/{order_id}/status`**
  - Body: `{ status, seller_id, item_index? }`
  - Returns: Success message
  - Updates: Item-level or order-level status

## Frontend Components

### 1. CheckoutPage (`src/components/CheckoutPage.js`)

#### Features:
- Filters cart for seller products only
- Pre-fills phone from user profile
- Editable delivery information per order
- Order summary with item cards
- Payment method selection (COD/Online)
- Total calculation
- Cart clearing after successful order

#### User Flow:
1. User clicks "Proceed to Checkout" in cart
2. System filters for seller products
3. User reviews/edits phone and address
4. User selects payment method
5. User clicks "Place Order"
6. Order created, cart cleared, redirect to order history

#### Validation:
- Phone number required
- Address required (min 10 characters)
- At least one seller product in cart

### 2. OrderHistory (`src/components/OrderHistory.js`)

#### Features:
- Displays all user orders (newest first)
- Shows order status badges
- Lists all items in each order
- Displays delivery information
- Cancel order button (for pending/confirmed orders)
- Responsive design with dark mode

#### Status Badges:
- **Pending**: Yellow background
- **Confirmed**: Light blue background
- **Shipped**: Light green background
- **Delivered**: Green background
- **Cancelled**: Red background

### 3. SellerOrders (`src/seller-frontend/components/SellerOrders.js`)

#### Features:
- Shows orders containing seller's products
- Filters items to show only seller's products
- Displays seller-specific total
- Status dropdown per item
- Customer contact information
- Real-time status updates

#### Seller Flow:
1. Seller logs in and navigates to "Orders"
2. System fetches orders with seller_id filter
3. Each order shows only seller's items
4. Seller can update status per item
5. Status changes saved to database

### 4. CartPage Updates (`src/components/CartPage.js`)

#### New Features:
- Detects seller products in cart
- Shows "Proceed to Checkout" button if seller products exist
- Displays count of seller items
- Cart summary section with totals

## Order Status Workflow

### Status Progression:
1. **Pending**: Order placed, awaiting seller confirmation
2. **Confirmed**: Seller confirmed, preparing shipment
3. **Shipped**: Order dispatched, in transit
4. **Delivered**: Order completed successfully
5. **Cancelled**: Order cancelled (by user or seller)

### Status Rules:
- Users can cancel: pending, confirmed
- Sellers can update: any status
- Item-level status: Allows multi-seller order management

## Payment Methods

### Current:
- **COD (Cash on Delivery)**: Active and fully functional

### Coming Soon:
- **Online Payment**: Placeholder UI, integration pending

## Routes

### User Routes:
- `/checkout` - Checkout page for seller products
- `/orders` - Order history page

### Seller Routes:
- `/seller/orders` - Seller order management page

## Usage Examples

### Creating an Order:
```javascript
const response = await fetch('http://localhost:5000/api/orders/create', {
  method: 'POST',
  credentials: 'include',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    phone: '+1234567890',
    address: '123 Main St, City, State, ZIP',
    payment_method: 'cod',
    items: [
      {
        product_id: 'seller_1_2',
        seller_id: '1',
        seller_name: 'AAKASH RAGHAV',
        product_name: 'shoes',
        price: 69,
        quantity: 1,
        image: 'https://...',
        category: 'footwear'
      }
    ]
  })
});
```

### Fetching User Orders:
```javascript
const response = await fetch('http://localhost:5000/api/orders/user', {
  credentials: 'include'
});
const data = await response.json();
// data.orders contains array of orders
```

### Updating Order Status (Seller):
```javascript
const response = await fetch('http://localhost:5000/api/seller/orders/order_123/status', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  credentials: 'include',
  body: JSON.stringify({
    status: 'shipped',
    seller_id: '1',
    item_index: 0  // Optional: update specific item
  })
});
```

## Multi-Seller Order Support

### Scenario:
User orders products from multiple sellers in one checkout.

### Implementation:
- Each item has `seller_id` and `seller_name`
- Order stored once with all items
- Indexed under each seller's `seller_orders:{seller_id}`
- Sellers see only their items
- Each item can have independent status
- Seller total calculated per seller

### Example:
```json
{
  "order_id": "order_123",
  "items": [
    {
      "product_id": "seller_1_2",
      "seller_id": "1",
      "status": "shipped"
    },
    {
      "product_id": "seller_2_5",
      "seller_id": "2",
      "status": "pending"
    }
  ],
  "total_amount": 150
}
```

When `seller_id=1` fetches orders:
- Shows only first item
- `seller_total = 69` (not 150)

## Testing the System

### 1. Test Order Creation:
1. Add seller products to cart
2. Navigate to cart page
3. Click "Proceed to Checkout"
4. Verify phone pre-filled
5. Edit/confirm address
6. Select COD payment
7. Click "Place Order"
8. Verify redirect to /orders
9. Verify cart is cleared

### 2. Test Order History:
1. Navigate to /orders
2. Verify orders display newest first
3. Check status badges
4. Verify item images and details
5. Test cancel order button

### 3. Test Seller Orders:
1. Login as seller
2. Navigate to /seller/orders
3. Verify only seller's items shown
4. Test status dropdown updates
5. Verify customer information display

## Error Handling

### Frontend:
- Authentication checks before API calls
- Empty state when no orders
- Loading states during fetches
- Alert messages for success/failure
- Form validation for phone and address

### Backend:
- Order ownership verification
- Status validation (can't cancel delivered orders)
- JSON serialization error handling
- Redis connection error handling
- User session validation

## Dark Mode Support

All components include dark mode styling:
- Background colors
- Text colors
- Border colors
- Button hover states
- Card shadows

## Responsive Design

Mobile-first approach:
- Breakpoint: 768px
- Stacked layouts on mobile
- Full-width buttons
- Adjusted font sizes
- Touch-friendly spacing

## Future Enhancements

1. **Email Notifications**: Order confirmation, status updates
2. **Order Tracking**: Real-time tracking with courier integration
3. **Invoice Generation**: PDF invoices for orders
4. **Return/Refund**: Order return and refund workflow
5. **Rating System**: Rate products after delivery
6. **Order Analytics**: Dashboard with order statistics
7. **Bulk Operations**: Seller bulk status updates
8. **Export Orders**: CSV/Excel export for sellers
9. **Advanced Filters**: Date range, status, seller filters
10. **Payment Gateway**: Razorpay/Stripe integration

## Database Maintenance

### Cleanup Old Orders:
```python
# Archive orders older than 6 months
async def archive_old_orders():
    cutoff_date = datetime.now() - timedelta(days=180)
    # Implementation pending
```

### Order Statistics:
```python
# Get order counts by status
async def get_order_stats(seller_id=None):
    # Implementation pending
    pass
```

## Security Considerations

1. **Authentication**: All endpoints require user/seller session
2. **Authorization**: Order ownership verified before access
3. **Input Validation**: Phone, address, payment method validated
4. **SQL Injection**: N/A (using Redis, no SQL)
5. **XSS Protection**: React auto-escapes output
6. **CSRF**: Using credentials: 'include' with CORS
7. **Rate Limiting**: Existing rate limiter applies

## Deployment Checklist

- [x] OrderManager class created
- [x] API endpoints implemented
- [x] CheckoutPage component created
- [x] OrderHistory component created
- [x] SellerOrders component created
- [x] Routes added to App.js
- [x] Cart page updated with checkout button
- [x] Backend restarted
- [ ] Test end-to-end order flow
- [ ] Test multi-seller orders
- [ ] Test order cancellation
- [ ] Test seller status updates
- [ ] Add order notifications (future)
- [ ] Add payment gateway (future)

## Support

For issues or questions:
1. Check backend logs: `docker logs shoppers-backend-1`
2. Check Redis data: Use `redis_viewer.py` tool
3. Check browser console for frontend errors
4. Verify Docker containers running: `docker-compose ps`

---

**Order System Ready for Production Use!**
