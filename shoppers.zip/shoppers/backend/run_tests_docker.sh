#!/bin/bash
# Automated test suite runner for Docker environment

echo "=============================================="
echo "🧪 RUNNING TESTS INSIDE DOCKER CONTAINER"
echo "=============================================="
echo ""

# Run tests inside the backend container
docker exec shoppers-backend-1 python test_transformations.py

exit_code=$?

echo ""
echo "=============================================="
if [ $exit_code -eq 0 ]; then
    echo "✅ All tests passed in Docker environment!"
else
    echo "⚠️  Some tests failed - see output above"
fi
echo "=============================================="

exit $exit_code
