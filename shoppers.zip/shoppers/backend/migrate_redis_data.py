"""
Redis Data Migration Script
Migrates data from old database layout to new DB 1-4 schema
Runs as one-time setup - safe to run multiple times (idempotent)
"""
import asyncio
import redis.asyncio as aioredis
import json
import logging
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

REDIS_HOST = os.getenv('REDIS_HOST', 'redis')
REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))

async def migrate_data():
    """
    Migrate existing data to new database schema
    
    Migration Plan:
    - DB 0 → DB 0 (no changes): Sessions, rate limiting, cache
    - DB 2 (old seller data) → DB 1: Seller products
    - DB 2 (old seller data) → DB 2: Seller accounts, stores
    - DB 4 (old orders) → DB 3: Orders (with 365-day TTL)
    """
    
    # Connect to all databases
    redis_db0 = await aioredis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=0, decode_responses=True)
    redis_db1 = await aioredis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=1, decode_responses=True)
    redis_db2 = await aioredis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=2, decode_responses=True)
    redis_db3 = await aioredis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=3, decode_responses=True)
    redis_db4 = await aioredis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=4, decode_responses=True)
    
    try:
        logger.info("🚀 Starting Redis Data Migration...")
        
        # Phase 1: Migrate seller products from DB2 → DB1
        logger.info("\n📦 Phase 1: Migrating seller products to DB 1...")
        await migrate_seller_products(redis_db2, redis_db1)
        
        # Phase 2: Migrate seller info from DB2 → DB2 (restructure)
        logger.info("\n👥 Phase 2: Restructuring seller info in DB 2...")
        await restructure_seller_info(redis_db2)
        
        # Phase 3: Migrate orders from DB4 → DB3
        logger.info("\n📋 Phase 3: Migrating orders to DB 3...")
        await migrate_orders(redis_db4, redis_db3)
        
        logger.info("\n✅ Migration completed successfully!")
        logger.info("\nDatabase Status:")
        
        # Print statistics
        db0_keys = await redis_db0.dbsize()
        db1_keys = await redis_db1.dbsize()
        db2_keys = await redis_db2.dbsize()
        db3_keys = await redis_db3.dbsize()
        
        logger.info(f"  DB 0 (Sessions/Cache): {db0_keys} keys")
        logger.info(f"  DB 1 (Seller Products): {db1_keys} keys")
        logger.info(f"  DB 2 (Sellers): {db2_keys} keys")
        logger.info(f"  DB 3 (Orders): {db3_keys} keys")
        
    except Exception as e:
        logger.error(f"❌ Migration failed: {e}", exc_info=True)
    finally:
        await redis_db0.close()
        await redis_db1.close()
        await redis_db2.close()
        await redis_db3.close()
        await redis_db4.close()

async def migrate_seller_products(src_redis, dst_redis):
    """Migrate seller products from source to DB1"""
    try:
        # Get all seller product keys (pattern: seller:{seller_id}:product:*)
        cursor = 0
        migrated = 0
        
        while True:
            cursor, keys = await src_redis.scan(
                cursor,
                match="seller:*:product:*",
                count=100
            )
            
            for old_key in keys:
                try:
                    # Extract seller_id and product_id
                    parts = old_key.split(':')
                    if len(parts) >= 4 and parts[0] == 'seller' and parts[2] == 'product':
                        seller_id = parts[1]
                        product_id = parts[3]
                        
                        # Get product data
                        product_data = await src_redis.hgetall(old_key)
                        
                        if product_data:
                            # New key format for DB1
                            new_key = f"seller:prod:{seller_id}:{product_id}"
                            
                            # Copy to DB1
                            await dst_redis.hset(new_key, mapping=product_data)
                            
                            # Update indices
                            await dst_redis.sadd(f"seller:prod:list:{seller_id}", product_id)
                            await dst_redis.sadd("seller:prod:all", f"{seller_id}:{product_id}")
                            
                            migrated += 1
                except Exception as e:
                    logger.warning(f"  Failed to migrate key {old_key}: {e}")
            
            if cursor == 0:
                break
        
        logger.info(f"  ✓ Migrated {migrated} seller products to DB 1")
        
    except Exception as e:
        logger.error(f"  ✗ Error migrating seller products: {e}")

async def restructure_seller_info(redis_db2):
    """Restructure seller info in DB2"""
    try:
        # Get all seller info keys (pattern: seller:{seller_id})
        cursor = 0
        restructured = 0
        
        while True:
            cursor, keys = await redis_db2.scan(
                cursor,
                match="seller:[0-9]*",
                count=100
            )
            
            for key in keys:
                try:
                    parts = key.split(':')
                    if len(parts) == 2 and parts[0] == 'seller' and parts[1].isdigit():
                        seller_id = parts[1]
                        
                        # Get seller data
                        seller_data = await redis_db2.hgetall(key)
                        
                        if seller_data:
                            # Data already in correct format (seller:info:{id})
                            # Just ensure all required fields exist
                            if 'seller_id' not in seller_data:
                                await redis_db2.hset(key, "seller_id", seller_id)
                            
                            # Update email lookup
                            email = seller_data.get('email')
                            if email:
                                await redis_db2.hset("seller:email:lookup", email, seller_id)
                            
                            # Add to all sellers set
                            await redis_db2.sadd("seller:all", seller_id)
                            
                            restructured += 1
                except Exception as e:
                    logger.warning(f"  Failed to restructure key {key}: {e}")
            
            if cursor == 0:
                break
        
        logger.info(f"  ✓ Restructured {restructured} seller records in DB 2")
        
    except Exception as e:
        logger.error(f"  ✗ Error restructuring seller info: {e}")

async def migrate_orders(src_redis, dst_redis):
    """Migrate orders from DB4 to DB3 with 365-day TTL"""
    try:
        ORDER_TTL = 365 * 24 * 60 * 60
        
        # Get all order keys
        cursor = 0
        migrated = 0
        
        while True:
            cursor, keys = await src_redis.scan(
                cursor,
                match="order:*",
                count=100
            )
            
            for old_key in keys:
                try:
                    # Get order data
                    order_json = await src_redis.get(old_key)
                    
                    if order_json:
                        try:
                            order_data = json.loads(order_json)
                            order_id = order_data.get('order_id')
                            
                            if order_id:
                                # New key in DB3
                                new_key = f"order:{order_id}"
                                
                                # Copy to DB3 with TTL
                                await dst_redis.set(new_key, order_json, ex=ORDER_TTL)
                                
                                # Update indices with TTL
                                user_id = order_data.get('user_id')
                                if user_id:
                                    await dst_redis.sadd(f"order:user:{user_id}", order_id)
                                
                                seller_id = order_data.get('seller_id')
                                if seller_id:
                                    await dst_redis.sadd(f"order:seller:{seller_id}", order_id)
                                
                                status = order_data.get('status', 'pending')
                                await dst_redis.sadd(f"order:status:{status}", order_id)
                                
                                await dst_redis.sadd("order:all", order_id)
                                
                                migrated += 1
                        except json.JSONDecodeError:
                            logger.warning(f"  Invalid JSON in order: {old_key}")
                except Exception as e:
                    logger.warning(f"  Failed to migrate key {old_key}: {e}")
            
            if cursor == 0:
                break
        
        logger.info(f"  ✓ Migrated {migrated} orders to DB 3 (365-day TTL)")
        
    except Exception as e:
        logger.error(f"  ✗ Error migrating orders: {e}")

if __name__ == "__main__":
    asyncio.run(migrate_data())
