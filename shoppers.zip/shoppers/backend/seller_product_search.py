import redis.asyncio as redis
from rapidfuzz import fuzz
import json
import logging
from typing import List, Dict, Any, Optional
import asyncio

logger = logging.getLogger(__name__)

class AsyncSellerProductSearch:
    """
    Async fuzzy search for seller products only
    """
    
    def __init__(self, redis_host='localhost', redis_port=6379):
        self.redis_host = redis_host
        self.redis_port = redis_port
        self._search_client = None
        self._seller_client = None
    
    async def get_search_client(self):
        """Get or create async Redis client for search index (DB 3)"""
        if self._search_client is None:
            self._search_client = await redis.Redis(
                host=self.redis_host,
                port=self.redis_port,
                db=3,
                decode_responses=True
            )
        return self._search_client
    
    async def get_seller_client(self):
        """Get or create async Redis client for seller data (DB 2)"""
        if self._seller_client is None:
            self._seller_client = await redis.Redis(
                host=self.redis_host,
                port=self.redis_port,
                db=2,
                decode_responses=True
            )
        return self._seller_client
    
    async def close(self):
        """Close Redis connections"""
        if self._search_client:
            await self._search_client.close()
        if self._seller_client:
            await self._seller_client.close()
    
    async def index_seller_products(self) -> int:
        """Async indexing of all active seller products"""
        try:
            search_client = await self.get_search_client()
            seller_client = await self.get_seller_client()
            
            logger.info("Starting async indexing of seller products...")
            indexed_count = 0
            
            # Clear old index
            old_keys = await search_client.smembers('seller_search:all_products')
            if old_keys:
                pipeline = search_client.pipeline()
                for key in old_keys:
                    pipeline.delete(key)
                    pipeline.delete(f'{key}:search_terms')
                pipeline.delete('seller_search:all_products')
                await pipeline.execute()
            
            # Get all sellers
            seller_emails = await seller_client.hgetall('seller:emails')
            logger.info(f"Found {len(seller_emails)} sellers to index")
            
            # Process all sellers concurrently
            tasks = []
            for email, seller_id in seller_emails.items():
                tasks.append(self._index_seller_products(seller_id, search_client, seller_client))
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            indexed_count = sum(r for r in results if isinstance(r, int))
            
            logger.info(f"Successfully indexed {indexed_count} seller products")
            return indexed_count
            
        except Exception as e:
            logger.error(f"Error indexing seller products: {str(e)}", exc_info=True)
            return 0
    
    async def _index_seller_products(self, seller_id: str, search_client, seller_client) -> int:
        """Index all products for a single seller"""
        try:
            count = 0
            
            # Get all products for this seller
            product_ids = await seller_client.smembers(f'seller:{seller_id}:products')
            
            # Get store info once
            store_data = await seller_client.hgetall(f'seller:{seller_id}:store')
            
            # Process products concurrently
            tasks = []
            for product_id in product_ids:
                tasks.append(
                    self._index_single_product(
                        seller_id, 
                        product_id, 
                        store_data, 
                        search_client, 
                        seller_client
                    )
                )
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            count = sum(1 for r in results if r is True)
            
            return count
            
        except Exception as e:
            logger.error(f"Error indexing seller {seller_id}: {str(e)}")
            return 0
    
    async def _index_single_product(
        self, 
        seller_id: str, 
        product_id: str, 
        store_data: dict,
        search_client,
        seller_client
    ) -> bool:
        """Index a single product"""
        try:
            # Get product data
            product_data = await seller_client.hgetall(f'seller:{seller_id}:product:{product_id}')
            
            if product_data.get('is_active') != '1':
                return False
            
            # Create unified product format
            # Get image - try image_url first (main field), then fall back to images
            image_url = product_data.get('image_url', '')
            images_str = product_data.get('images', '')
            image = image_url if image_url else (images_str.split(',')[0] if images_str else '')
            images = images_str.split(',') if images_str else []
            
            unified_product = {
                'id': f"seller_{seller_id}_{product_id}",
                'product_id': product_id,
                'seller_id': seller_id,
                'title': product_data.get('name', ''),
                'name': product_data.get('name', ''),
                'description': product_data.get('description', ''),
                'price': product_data.get('price', ''),
                'original_price': product_data.get('price', ''),
                'category': product_data.get('category', ''),
                'image': image,
                'images': images,
                'stock': int(product_data.get('stock', '0')),
                'platform': 'Seller',
                'source': 'seller',
                'seller_name': store_data.get('business_name', 'Unknown Seller'),
                'url': f"/product/seller_{seller_id}_{product_id}",
                'rating': '4.0',
                'reviews': '0',
                'created_at': product_data.get('created_at', '')
            }
            
            # Store in search index
            search_key = f"seller_product:{seller_id}:{product_id}"
            
            # Create searchable text
            search_terms = (
                f"{unified_product['title']} "
                f"{unified_product['description']} "
                f"{unified_product['category']}"
            ).lower()
            
            # Use pipeline for atomic operations
            pipeline = search_client.pipeline()
            pipeline.set(search_key, json.dumps(unified_product), ex=86400)
            pipeline.sadd('seller_search:all_products', search_key)
            pipeline.set(f'{search_key}:search_terms', search_terms, ex=86400)
            await pipeline.execute()
            
            return True
            
        except Exception as e:
            logger.error(f"Error indexing product {product_id}: {str(e)}")
            return False
    
    async def fuzzy_search_sellers(
        self, 
        query: str, 
        threshold: int = 50
    ) -> List[Dict[str, Any]]:
        """
        Async fuzzy search for seller products
        """
        try:
            query = query.lower().strip()
            
            if not query:
                return []
            
            search_client = await self.get_search_client()
            
            # Get all seller product keys
            all_product_keys = await search_client.smembers('seller_search:all_products')
            
            if not all_product_keys:
                logger.warning("No seller products in search index")
                return []
            
            # Search all products concurrently
            tasks = []
            for product_key in all_product_keys:
                tasks.append(self._fuzzy_match_product(query, product_key, threshold, search_client))
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Filter out None results and errors
            matched_products = [
                r for r in results 
                if r is not None and not isinstance(r, Exception)
            ]
            
            # Sort by relevance
            matched_products.sort(key=lambda x: x.get('relevance_score', 0), reverse=True)
            
            logger.info(f"Found {len(matched_products)} seller products for query '{query}'")
            
            return matched_products
            
        except Exception as e:
            logger.error(f"Error in fuzzy_search_sellers: {str(e)}", exc_info=True)
            return []
    
    async def _fuzzy_match_product(
        self, 
        query: str, 
        product_key: str, 
        threshold: int,
        search_client
    ) -> Optional[Dict[str, Any]]:
        """Match a single product against query with advanced Amazon-style search"""
        try:
            # Get product data first for field-level matching
            product_json = await search_client.get(product_key)
            if not product_json:
                return None
            
            product_data = json.loads(product_json)
            
            # Get search terms
            search_terms = await search_client.get(f'{product_key}:search_terms')
            if not search_terms:
                return None
            
            # Comprehensive synonyms and related terms mapping
            synonyms = {
                # Footwear
                'footwear': ['shoe', 'shoes', 'sandal', 'sandals', 'boot', 'boots', 'slipper', 'slippers', 'sneaker', 'sneakers', 'footgear'],
                'shoe': ['shoes', 'footwear', 'sneaker', 'sneakers', 'boot', 'boots'],
                'shoes': ['shoe', 'footwear', 'sneaker', 'sneakers', 'boot', 'boots'],
                'sneaker': ['sneakers', 'shoes', 'trainers', 'runners', 'kicks', 'sports shoes'],
                'sneakers': ['sneaker', 'shoes', 'trainers', 'runners', 'kicks', 'sports shoes'],
                'sandal': ['sandals', 'flip-flops', 'slides', 'slippers', 'chappals'],
                'sandals': ['sandal', 'flip-flops', 'slides', 'slippers', 'chappals'],
                'boot': ['boots', 'shoes', 'footwear', 'ankle boots'],
                'boots': ['boot', 'shoes', 'footwear', 'ankle boots'],
                'slipper': ['slippers', 'slides', 'flip-flops', 'house shoes'],
                'slippers': ['slipper', 'slides', 'flip-flops', 'house shoes'],
                'heels': ['high heels', 'stilettos', 'pumps', 'platforms'],
                'flats': ['flat shoes', 'ballerinas', 'ballet flats'],
                
                # Clothing
                'apparel': ['clothing', 'clothes', 'wear', 'garment', 'garments', 'dress', 'attire'],
                'clothing': ['apparel', 'clothes', 'wear', 'garment', 'garments', 'dress', 'attire'],
                'clothes': ['clothing', 'apparel', 'wear', 'garments', 'attire'],
                'wear': ['clothing', 'apparel', 'clothes', 'garments'],
                'dress': ['dresses', 'gown', 'frock', 'outfit'],
                'dresses': ['dress', 'gown', 'frock', 'outfit'],
                'shirt': ['shirts', 'top', 'tops', 'blouse', 'tshirt', 't-shirt', 'tee'],
                'shirts': ['shirt', 'top', 'tops', 'blouse', 'tshirt', 't-shirt', 'tee'],
                'tshirt': ['t-shirt', 'tee', 'shirt', 'top', 'casual shirt'],
                't-shirt': ['tshirt', 'tee', 'shirt', 'top', 'casual shirt'],
                'top': ['tops', 'shirt', 'blouse', 'tee', 'tunic'],
                'tops': ['top', 'shirt', 'blouse', 'tee', 'tunic'],
                'pants': ['trousers', 'jeans', 'bottoms', 'slacks', 'chinos'],
                'trousers': ['pants', 'jeans', 'bottoms', 'slacks', 'chinos'],
                'jeans': ['denim', 'pants', 'trousers', 'denims'],
                'shorts': ['short pants', 'bermuda', 'cargo shorts'],
                'skirt': ['skirts', 'mini skirt', 'maxi skirt'],
                'jacket': ['jackets', 'blazer', 'coat', 'outerwear'],
                'coat': ['coats', 'jacket', 'overcoat', 'outerwear'],
                'sweater': ['sweaters', 'pullover', 'jumper', 'cardigan', 'knitwear'],
                'hoodie': ['hoodies', 'sweatshirt', 'pullover'],
                'kurta': ['kurti', 'kurtas', 'kurtis', 'ethnic wear'],
                'saree': ['sarees', 'sari', 'traditional wear'],
                'lehenga': ['lehengas', 'ghagra', 'ethnic wear'],
                'salwar': ['salwar kameez', 'suit', 'ethnic wear'],
                
                # Accessories
                'accessories': ['accessory', 'add-ons', 'extras'],
                'bag': ['bags', 'purse', 'handbag', 'backpack', 'satchel', 'tote'],
                'bags': ['bag', 'purse', 'handbag', 'backpack', 'satchel', 'tote'],
                'backpack': ['backpacks', 'rucksack', 'bag', 'school bag'],
                'handbag': ['handbags', 'purse', 'bag', 'clutch'],
                'wallet': ['wallets', 'purse', 'billfold', 'card holder'],
                'belt': ['belts', 'waistband', 'strap'],
                'watch': ['watches', 'wristwatch', 'timepiece', 'clock'],
                'sunglasses': ['sunnies', 'shades', 'eyewear', 'goggles', 'sun shades'],
                'glasses': ['spectacles', 'eyewear', 'specs', 'eyeglasses', 'frames'],
                'spectacles': ['glasses', 'eyewear', 'specs', 'eyeglasses', 'frames'],
                'eyewear': ['glasses', 'spectacles', 'sunglasses', 'goggles', 'shades'],
                'jewelry': ['jewellery', 'ornaments', 'accessories', 'trinkets'],
                'jewellery': ['jewelry', 'ornaments', 'accessories', 'trinkets'],
                'necklace': ['necklaces', 'chain', 'pendant', 'jewelry'],
                'earring': ['earrings', 'studs', 'hoops', 'jewelry'],
                'bracelet': ['bracelets', 'bangle', 'wristband', 'jewelry'],
                'ring': ['rings', 'band', 'jewelry'],
                'hat': ['hats', 'cap', 'caps', 'headwear', 'beanie'],
                'cap': ['caps', 'hat', 'baseball cap', 'headwear'],
                'scarf': ['scarves', 'muffler', 'stole', 'shawl'],
                
                # Electronics & Gadgets
                'electronics': ['electronic', 'gadgets', 'devices', 'tech', 'technology'],
                'gadget': ['gadgets', 'device', 'electronics', 'tech'],
                'phone': ['phones', 'mobile', 'smartphone', 'cellphone', 'cell', 'mobile phone'],
                'mobile': ['mobiles', 'phone', 'smartphone', 'cellphone', 'cell phone'],
                'smartphone': ['smartphones', 'phone', 'mobile', 'smart phone'],
                'laptop': ['laptops', 'notebook', 'computer', 'pc', 'netbook'],
                'computer': ['computers', 'pc', 'laptop', 'desktop'],
                'tablet': ['tablets', 'ipad', 'tab', 'slate'],
                'headphone': ['headphones', 'earphone', 'earphones', 'earbuds', 'headset'],
                'headphones': ['headphone', 'earphones', 'earbuds', 'headset', 'ear phones'],
                'earphone': ['earphones', 'headphones', 'earbuds', 'ear buds'],
                'earphones': ['earphone', 'headphones', 'earbuds', 'ear phones'],
                'earbuds': ['earbud', 'earphones', 'headphones', 'wireless earbuds'],
                'speaker': ['speakers', 'bluetooth speaker', 'sound system'],
                'charger': ['chargers', 'adapter', 'power adapter', 'charging cable'],
                'powerbank': ['power bank', 'portable charger', 'battery pack'],
                'camera': ['cameras', 'dslr', 'digital camera', 'camcorder'],
                'tv': ['television', 'smart tv', 'led tv', 'lcd'],
                'television': ['tv', 'smart tv', 'led tv', 'telly'],
                'monitor': ['monitors', 'display', 'screen', 'computer screen'],
                'keyboard': ['keyboards', 'typing keyboard', 'gaming keyboard'],
                'mouse': ['mice', 'computer mouse', 'wireless mouse', 'gaming mouse'],
                'printer': ['printers', 'printing machine', 'inkjet', 'laser printer'],
                
                # Home & Kitchen
                'home': ['household', 'domestic', 'house', 'home decor'],
                'furniture': ['furnishing', 'furnishings', 'home furniture'],
                'bed': ['beds', 'bedding', 'cot', 'mattress'],
                'mattress': ['mattresses', 'bed', 'sleeping mat'],
                'sofa': ['sofas', 'couch', 'settee', 'lounge'],
                'chair': ['chairs', 'seat', 'seating', 'armchair'],
                'table': ['tables', 'desk', 'dining table', 'coffee table'],
                'kitchen': ['cookware', 'utensils', 'kitchenware', 'cooking'],
                'utensil': ['utensils', 'cutlery', 'kitchen tools', 'cookware'],
                'cookware': ['cooking utensils', 'pots', 'pans', 'kitchen items'],
                'mixer': ['mixers', 'blender', 'grinder', 'food processor'],
                'blender': ['blenders', 'mixer', 'juicer', 'food processor'],
                'refrigerator': ['fridge', 'freezer', 'cooler', 'ref'],
                'fridge': ['refrigerator', 'freezer', 'cooler'],
                'oven': ['ovens', 'microwave', 'toaster oven', 'baking oven'],
                'microwave': ['microwaves', 'oven', 'microwave oven'],
                
                # Beauty & Personal Care
                'beauty': ['cosmetics', 'makeup', 'beauty products', 'skincare'],
                'cosmetics': ['makeup', 'beauty', 'beauty products', 'make-up'],
                'makeup': ['cosmetics', 'make-up', 'beauty products'],
                'perfume': ['perfumes', 'fragrance', 'scent', 'cologne', 'eau de toilette'],
                'fragrance': ['perfume', 'scent', 'cologne', 'aroma'],
                'skincare': ['skin care', 'facial care', 'beauty'],
                'cream': ['creams', 'lotion', 'moisturizer', 'face cream'],
                'lotion': ['lotions', 'cream', 'moisturizer', 'body lotion'],
                'shampoo': ['shampoos', 'hair wash', 'hair cleanser'],
                'conditioner': ['conditioners', 'hair conditioner'],
                'soap': ['soaps', 'body wash', 'bathing soap', 'cleanser'],
                'facewash': ['face wash', 'facial cleanser', 'face cleanser'],
                'lipstick': ['lipsticks', 'lip color', 'lip stick'],
                'nail': ['nails', 'nail polish', 'manicure'],
                
                # Sports & Fitness
                'sports': ['sport', 'fitness', 'athletic', 'exercise', 'gym'],
                'fitness': ['gym', 'workout', 'exercise', 'sports'],
                'gym': ['fitness', 'workout', 'exercise', 'gymnasium'],
                'yoga': ['yoga mat', 'meditation', 'exercise'],
                'dumbbell': ['dumbbells', 'weights', 'free weights'],
                'treadmill': ['treadmills', 'running machine', 'cardio'],
                'cycle': ['cycles', 'bicycle', 'bike', 'cycling'],
                'bicycle': ['bike', 'cycle', 'cycles', 'cycling'],
                'ball': ['balls', 'football', 'basketball', 'cricket ball'],
                'racket': ['rackets', 'racquet', 'tennis racket', 'badminton racket'],
                
                # Books & Stationery
                'book': ['books', 'novel', 'novels', 'literature', 'reading material'],
                'books': ['book', 'novel', 'novels', 'literature', 'reading'],
                'novel': ['novels', 'book', 'fiction', 'story'],
                'notebook': ['notebooks', 'notepad', 'journal', 'diary'],
                'pen': ['pens', 'writing pen', 'ballpoint'],
                'pencil': ['pencils', 'writing pencil', 'lead pencil'],
                'diary': ['diaries', 'journal', 'planner', 'notebook'],
                
                # Toys & Games
                'toy': ['toys', 'plaything', 'playthings', 'games'],
                'toys': ['toy', 'playthings', 'games', 'fun'],
                'game': ['games', 'gaming', 'video game', 'board game'],
                'puzzle': ['puzzles', 'jigsaw', 'brain teaser'],
                'doll': ['dolls', 'toy doll', 'barbie'],
                'car': ['cars', 'toy car', 'vehicle', 'automobile'],
                
                # Baby & Kids
                'baby': ['infant', 'newborn', 'toddler', 'child'],
                'kids': ['children', 'child', 'kid', 'youngster'],
                'children': ['kids', 'child', 'kid', 'youngsters'],
                'diaper': ['diapers', 'nappy', 'nappies'],
                'bottle': ['bottles', 'feeding bottle', 'baby bottle'],
                
                # Gender
                'men': ['male', 'man', 'mens', 'gents', 'boys', 'gentlemen'],
                'man': ['men', 'male', 'mens', 'gents', 'gentleman'],
                'mens': ['men', 'male', 'man', 'gents'],
                'women': ['female', 'woman', 'womens', 'ladies', 'girls'],
                'woman': ['women', 'female', 'womens', 'ladies', 'lady'],
                'womens': ['women', 'female', 'woman', 'ladies'],
                'ladies': ['women', 'woman', 'female', 'womens', 'lady'],
                'boys': ['boy', 'kids', 'children', 'male kids'],
                'girls': ['girl', 'kids', 'children', 'female kids'],
                'unisex': ['men', 'women', 'all', 'everyone'],
                
                # Colors (useful for product variations)
                'black': ['dark', 'noir', 'ebony'],
                'white': ['ivory', 'cream', 'off-white'],
                'red': ['crimson', 'scarlet', 'maroon'],
                'blue': ['navy', 'azure', 'cobalt'],
                'green': ['olive', 'lime', 'emerald'],
                'yellow': ['golden', 'mustard', 'amber'],
                'pink': ['rose', 'magenta', 'fuchsia'],
                'purple': ['violet', 'lavender', 'mauve'],
                'brown': ['tan', 'beige', 'khaki'],
                'grey': ['gray', 'silver', 'charcoal'],
                
                # Brands & Categories
                'premium': ['luxury', 'high-end', 'deluxe', 'elite'],
                'luxury': ['premium', 'high-end', 'deluxe', 'elite'],
                'budget': ['affordable', 'cheap', 'economical', 'value'],
                'affordable': ['budget', 'cheap', 'economical', 'value'],
                'new': ['latest', 'newest', 'fresh', 'recent'],
                'latest': ['new', 'newest', 'recent', 'modern'],
                'vintage': ['retro', 'classic', 'old-fashioned', 'antique'],
                'classic': ['traditional', 'vintage', 'timeless'],
            }
            
            # Expand query with synonyms
            query_terms = query.lower().split()
            expanded_terms = set(query_terms)
            for term in query_terms:
                if term in synonyms:
                    expanded_terms.update(synonyms[term])
            
            # Calculate scores for different fields
            name_score = 0
            category_score = 0
            description_score = 0
            overall_score = 0
            
            # Field-level matching
            product_name = product_data.get('name', '').lower()
            product_category = product_data.get('category', '').lower()
            product_description = product_data.get('description', '').lower()
            
            # Score against product name (highest weight)
            for term in expanded_terms:
                if term in product_name:
                    name_score = 100  # Exact substring match
                else:
                    name_score = max(name_score, fuzz.partial_ratio(term, product_name))
            
            # Score against category (medium weight)
            for term in expanded_terms:
                if term in product_category or product_category in expanded_terms:
                    category_score = 100  # Category match
                else:
                    category_score = max(category_score, fuzz.partial_ratio(term, product_category))
            
            # Score against description (lower weight)
            for term in expanded_terms:
                description_score = max(description_score, fuzz.partial_ratio(term, product_description))
            
            # Overall fuzzy matching with full search terms
            token_sort_ratio = fuzz.token_sort_ratio(query, search_terms)
            partial_ratio = fuzz.partial_ratio(query, search_terms)
            token_set_ratio = fuzz.token_set_ratio(query, search_terms)
            
            overall_score = (
                token_sort_ratio * 0.3 + 
                partial_ratio * 0.4 + 
                token_set_ratio * 0.3
            )
            
            # Weighted final score (prioritize name and category matches)
            final_score = (
                name_score * 0.5 +        # Name is most important
                category_score * 0.3 +    # Category is important
                overall_score * 0.15 +    # Overall fuzzy match
                description_score * 0.05  # Description is least important
            )
            
            if final_score >= threshold:
                product_data['relevance_score'] = round(final_score, 2)
                return product_data
            
            return None
                
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON for {product_key}")
            return None
        except Exception as e:
            logger.error(f"Error matching product {product_key}: {str(e)}")
            return None
    
    async def search_with_filters(
        self, 
        query: str,
        category: Optional[str] = None,
        min_price: Optional[float] = None,
        max_price: Optional[float] = None,
        threshold: int = 50
    ) -> List[Dict[str, Any]]:
        """Async search with filters"""
        results = await self.fuzzy_search_sellers(query, threshold)
        
        if not (category or min_price or max_price):
            return results
        
        filtered = []
        
        for product in results:
            # Category filter
            if category and product.get('category', '').lower() != category.lower():
                continue
            
            # Price filter
            try:
                price = float(product.get('price', 0))
                
                if min_price and price < min_price:
                    continue
                
                if max_price and price > max_price:
                    continue
            except (ValueError, TypeError):
                continue
            
            filtered.append(product)
        
        return filtered
