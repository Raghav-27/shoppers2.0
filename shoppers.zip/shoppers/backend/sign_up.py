import redis
import json
import hashlib
import uuid
import time
import bcrypt

# ---------------------------------------------
# REDIS CONFIG
# ---------------------------------------------
REDIS_HOST = 'redis'  # Use Redis container name
REDIS_PORT = 6379

# ---------------------------------------------
# CONNECT TO REDIS
# ---------------------------------------------
def connect_to_redis():
    try:
        r = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, decode_responses=True)
        r.ping()
        print("✅ Connected to Redis")
        return r
    except Exception as e:
        print(f"❌ Redis connection failed: {e}")
        return None

# ---------------------------------------------
# UTILITIES
# ---------------------------------------------
def hash_password(password):
    """Hash password using bcrypt with salt"""
    # Convert password to bytes and hash with bcrypt
    password_bytes = password.encode('utf-8')
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password_bytes, salt)
    # Return as string for Redis storage
    return hashed.decode('utf-8')

def verify_password(password, hashed_password):
    """Verify password against bcrypt hash"""
    password_bytes = password.encode('utf-8')
    hashed_bytes = hashed_password.encode('utf-8')
    return bcrypt.checkpw(password_bytes, hashed_bytes)

def generate_session_token(email):
    """Generate a unique session token"""
    raw = f"{email}:{uuid.uuid4()}:{time.time()}"
    return hashlib.sha256(raw.encode()).hexdigest()

# ---------------------------------------------
# SIGNUP
# ---------------------------------------------
def signup_user(redis_client, first_name, last_name, email, phone, country, password):
    key_profile = f"user:{email}"
    key_state = f"user:{email}:state"

    if redis_client.exists(key_profile):
        print("⚠️ User already exists!")
        return None

    user_data = {
        "first_name": first_name,
        "last_name": last_name,
        "email": email,
        "phone": phone,
        "country": country,
        "password": hash_password(password),
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S")
    }

    state_data = {
        "wishlist": [],
        "compare": [],
        "cart": []
    }

    redis_client.set(key_profile, json.dumps(user_data))
    redis_client.set(key_state, json.dumps(state_data))
    print(f"✅ User '{email}' registered successfully.")

    return user_data

# ---------------------------------------------
# LOGIN
# ---------------------------------------------
def login_user(redis_client, email, password):
    key_profile = f"user:{email}"

    data = redis_client.get(key_profile)
    if not data:
        print("❌ No such user.")
        return None

    user = json.loads(data)
    if user["password"] != hash_password(password):
        print("❌ Incorrect password.")
        return None

    # Generate session
    token = generate_session_token(email)
    session_key = f"session:{token}"

    session_data = {
        "email": email,
        "created_at": int(time.time())
    }

    redis_client.setex(session_key, 60 * 60 * 24 * 7, json.dumps(session_data))  # 7 days expiry

    print(f"✅ Login success. Session token: {token[:16]}... (set this as cookie in browser)")
    return token

# ---------------------------------------------
# SESSION VALIDATION
# ---------------------------------------------
def validate_session(redis_client, token):
    session_key = f"session:{token}"
    data = redis_client.get(session_key)
    if not data:
        print("⚠️ Invalid or expired session.")
        return None
    return json.loads(data)

# ---------------------------------------------
# MODIFY USER LISTS (wishlist, cart, compare)
# ---------------------------------------------
def add_to_list(redis_client, email, list_name, product_id):
    key_state = f"user:{email}:state"

    data = redis_client.get(key_state)
    if not data:
        print("⚠️ User state not found.")
        return

    state = json.loads(data)
    if list_name not in state:
        print("⚠️ Invalid list name.")
        return

    if product_id not in state[list_name]:
        state[list_name].append(product_id)
        redis_client.set(key_state, json.dumps(state))
        print(f"✅ Added product {product_id} to {list_name}.")
    else:
        print(f"ℹ️ Product already in {list_name}.")

def remove_from_list(redis_client, email, list_name, product_id):
    key_state = f"user:{email}:state"

    data = redis_client.get(key_state)
    if not data:
        print("⚠️ User state not found.")
        return

    state = json.loads(data)
    if list_name in state and product_id in state[list_name]:
        state[list_name].remove(product_id)
        redis_client.set(key_state, json.dumps(state))
        print(f"🗑️ Removed product {product_id} from {list_name}.")

