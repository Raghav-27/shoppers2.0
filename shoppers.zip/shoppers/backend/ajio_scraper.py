"""
Async Scraper Module for Ajio
Handles redirects (e.g. 'specs' → 'spectacles'), pagination, caching, deduplication
"""
import asyncio
import json
import httpx
import time
import random
import redis.asyncio as aioredis
from urllib.parse import quote_plus, urlparse, parse_qs
from typing import List, Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)

# ----------------------------------------
# CONFIG
# ----------------------------------------
MAX_PRODUCTS_PER_PAGE = 40
MAX_PAGES = 5
CONCURRENT_REQUESTS = 2
MAX_RETRIES = 3
RETRY_STATUS_CODES = [429, 500, 502, 503, 504]

# Redis configuration
REDIS_HOST = 'redis'
REDIS_PORT = 6379

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Referer": "https://www.ajio.com/",
}

def get_sort_param(sort_order: Optional[str]) -> str:
    """Map sort_order to Ajio's sort parameter"""
    if sort_order == 'desc':
        return "prce-desc"
    elif sort_order == 'asc':
        return "prce-asc"
    else:
        return "relevance"

def process_image_url(url: str) -> str:
    """Process Ajio image URL to full HTTPS"""
    if not url:
        return ""
    if url.startswith("//"):
        return "https:" + url
    return url

async def get_redis_client() -> aioredis.Redis:
    """Create async Redis client"""
    return await aioredis.from_url(
        f"redis://{REDIS_HOST}:{REDIS_PORT}/0",
        decode_responses=True
    )

def extract_products(data: dict, query: str, filter_name: str, cursor: str, page_number: int) -> List[Dict]:
    """Extract products from API response"""
    products = []
    try:
        for product in data.get("products", []):
            try:
                product_data = product.copy()
                
                if "code" in product_data:
                    product_data["id"] = str(product_data["code"])
                
                # Product URL
                product_url = product.get("url", "")
                if product_url and not product_url.startswith("http"):
                    product_url = "https://www.ajio.com" + product_url
                product_data["product_url"] = product_url
                
                # Images
                all_images = []
                primary_images_obj = product.get("images", {})
                if primary_images_obj and isinstance(primary_images_obj, dict):
                    primary_url = process_image_url(primary_images_obj.get("url", ""))
                    primary_type = primary_images_obj.get("imageType", "")
                    if primary_url:
                        all_images.append({"id": primary_type, "url": primary_url})
                
                extra_images_obj = product.get("extraImages", {})
                extra_images_list = extra_images_obj.get("images", []) if isinstance(extra_images_obj, dict) else []
                for img in extra_images_list:
                    if isinstance(img, dict):
                        img_url = process_image_url(img.get("url", ""))
                        if img_url:
                            all_images.append({"id": img.get("imageType", ""), "url": img_url})
                
                product_data["all_images"] = all_images
                product_data["primary_image"] = all_images[0]["url"] if all_images else ""
                
                # Price & discount
                price_data = product.get("price", {})
                price = price_data.get("value", 0)
                product_data["price"] = price
                
                was_price_data = product.get("wasPriceData", {})
                original_price = was_price_data.get("value", price)
                product_data["original_price"] = original_price
                
                discount_percent = 0
                api_discount = product.get("discountPercent", 0)
                if api_discount and isinstance(api_discount, (int, float)):
                    discount_percent = float(api_discount)
                elif original_price and original_price > price:
                    discount_percent = round(((original_price - price) / original_price) * 100, 1)
                product_data["discount_percent"] = discount_percent
                
                product_data["site"] = "Ajio"
                if "description" not in product_data:
                    product_data["description"] = product.get("additionalInfo", "")
                if "rating" not in product_data:
                    product_data["rating"] = 0
                if "num_ratings" not in product_data:
                    product_data["num_ratings"] = product.get("ratingCount", 0)
                
                if product_data.get("code") and product_data.get("name"):
                    products.append(product_data)
            except Exception as e:
                logger.warning(f"Error processing product: {e}")
                continue
    except Exception as e:
        logger.error(f"Error parsing products: {e}")
    
    return products


# ===============================================
# REDIRECT-HANDLING FETCHER (CORE FIX)
# ===============================================

async def fetch_page_with_retry(
    client: httpx.AsyncClient,
    page_number: int,
    original_query: str,
    effective_query: str,
    sort_param: str,
) -> Tuple[Optional[dict], str]:
    """
    Returns (json_data, final_used_query)
    Handles redirects where Ajio rewrites query (e.g. 'specs' → 'spectacles')
    """
    query_enc = quote_plus(effective_query)
    url = "https://www.ajio.com/api/search"

    params = {
        "query": query_enc,
        "sort": sort_param,
        "currentPage": page_number,
        "pageSize": MAX_PRODUCTS_PER_PAGE,
    }

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = await client.get(url, params=params, timeout=30)
            final_url = str(response.url)

            # Detect if Ajio redirected and changed the query
            if "query=" in final_url:
                parsed = urlparse(final_url)
                redirected_q = parse_qs(parsed.query).get("query", [None])[0]
                if redirected_q and redirected_q != query_enc:
                    logger.info(f"Redirected '{original_query}' → '{redirected_q}' (page {page_number})")
                    # Re-fetch with corrected query
                    params["query"] = redirected_q
                    response = await client.get(url, params=params, timeout=30)
                    final_url = str(response.url)
                    redirected_q = parse_qs(urlparse(final_url).query).get("query", [None])[0]

            if response.status_code == 200:
                try:
                    data = response.json()
                    if data.get("products"):
                        final_query = parse_qs(urlparse(final_url).query).get("query", [effective_query])[0]
                        return data, final_query
                except Exception as e:
                    logger.warning(f"JSON parse error (page {page_number}): {e}")

            if response.status_code in RETRY_STATUS_CODES:
                wait = random.uniform(1, 3)
                logger.warning(f"Retry {attempt}/{MAX_RETRIES} for page {page_number} after {response.status_code}")
                await asyncio.sleep(wait)
                continue

            logger.error(f"HTTP {response.status_code} on page {page_number}")
            return None, effective_query

        except httpx.RequestError as e:
            wait = random.uniform(1, 3)
            logger.warning(f"Network error (attempt {attempt}): {e} – retry in {wait:.2f}s")
            await asyncio.sleep(wait)

    return None, effective_query


async def fetch_pages_with_pages(
    query: str,
    sort_param: str,
    max_pages: int = MAX_PAGES,
    start_page: int = 1
) -> List[Tuple[int, List[Dict]]]:
    """Fetch multiple pages with redirect-aware logic"""
    all_results: List[Tuple[int, List[Dict]]] = []
    sem = asyncio.Semaphore(CONCURRENT_REQUESTS)
    effective_query = query  # Will be updated after first redirect

    async def sem_fetch_page(page_number: int):
        nonlocal effective_query
        async with sem:
            logger.info(f"Fetching page {page_number} with query: {effective_query}")
            data, used_query = await fetch_page_with_retry(
                httpx.AsyncClient(headers=headers, timeout=30, follow_redirects=True),
                page_number,
                original_query=query,
                effective_query=effective_query,
                sort_param=sort_param,
            )
            if used_query != effective_query:
                effective_query = used_query

            if not data:
                return page_number, []

            products = extract_products(data, query, "relevance", None, page_number)
            if not products:
                return page_number, []

            logger.info(f"Page {page_number}: {len(products)} products")
            return page_number, products

    async with httpx.AsyncClient(headers=headers, timeout=30, follow_redirects=True) as _:
        tasks = [sem_fetch_page(p) for p in range(start_page, start_page + max_pages)]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for res in results:
            if isinstance(res, tuple) and len(res) == 2 and res[1]:
                all_results.append(res)

        all_results.sort(key=lambda x: x[0])

    return all_results


# ===============================================
# REDIS & MAIN SCRAPER
# ===============================================

async def store_in_redis(
    query: str,
    sort_order: Optional[str],
    products: List[Dict],
    page_number: int,
    cursor: Optional[str] = None
) -> bool:
    try:
        redis_client = await get_redis_client()
        filter_name = 'relevance' if sort_order is None else sort_order
        redis_key = f'ajio:{query}:{filter_name}:data'
        
        metadata = {
            "query": query,
            "sort_order": sort_order,
            "total_products": len(products),
            "scraped_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "scraped_timestamp": int(time.time()),
            "last_page_scraped": page_number,
            "cursor": cursor
        }
        
        await redis_client.set(redis_key, json.dumps({"metadata": metadata, "products": products}, ensure_ascii=False))
        logger.info(f"Stored {len(products)} products in Redis: {redis_key}")
        await redis_client.close()
        return True
    except Exception as e:
        logger.error(f"Redis store failed: {e}")
        return False

async def get_redis_metadata(query: str, sort_order: Optional[str]) -> Optional[Dict]:
    try:
        redis_client = await get_redis_client()
        filter_name = 'relevance' if sort_order is None else sort_order
        redis_key = f'ajio:{query}:{filter_name}:data'
        data = await redis_client.get(redis_key)
        await redis_client.close()
        return json.loads(data).get("metadata", {}) if data else None
    except Exception as e:
        logger.error(f"Redis read error: {e}")
        return None


async def scrape_products(
    query: str,
    sort_order: Optional[str] = None,
    is_prefetch: bool = False
) -> Dict:
    start_time = time.perf_counter()
    filter_name = 'relevance' if sort_order is None else sort_order
    sort_param = get_sort_param(sort_order)
    metadata = await get_redis_metadata(query, sort_order)

    # Prefetch or resume logic
    if is_prefetch:
        start_page = metadata.get("last_page_scraped", 1) + 1 if metadata else 1
        max_pages_to_fetch = 5
    else:
        if metadata and metadata.get("total_products", 0) >= 20:
            return {"status": "cached", "total_products": metadata["total_products"], "message": "Using cache"}
        start_page = metadata.get("last_page_scraped", 1) + 1 if metadata and metadata.get("total_products", 0) < 20 else 1
        max_pages_to_fetch = MAX_PAGES

    # Fetch pages
    results = await fetch_pages_with_pages(query, sort_param, max_pages_to_fetch, start_page)

    all_products = []
    global_seen = set()

    # Load existing
    if metadata:
        try:
            redis_client = await get_redis_client()
            key = f'ajio:{query}:{filter_name}:data'
            data = await redis_client.get(key)
            await redis_client.close()
            if data:
                existing = json.loads(data).get("products", [])
                for p in existing:
                    url = p.get("product_url")
                    if url and url not in global_seen:
                        global_seen.add(url)
                        all_products.append(p)
        except Exception as e:
            logger.warning(f"Failed to load existing: {e}")

    # Add new
    last_page_scraped = start_page - 1
    for page_number, products in results:
        last_page_scraped = page_number
        for p in products:
            url = p.get("product_url")
            if url and url not in global_seen:
                global_seen.add(url)
                all_products.append(p)

    # Sort
    if sort_order == 'asc':
        all_products.sort(key=lambda x: x.get('price', 0))
    elif sort_order == 'desc':
        all_products.sort(key=lambda x: x.get('price', 0), reverse=True)

    if all_products:
        await store_in_redis(query, sort_order, all_products, last_page_scraped)

    elapsed = time.perf_counter() - start_time
    mode = "Prefetch" if is_prefetch else "Search"
    logger.info(f"{mode} complete: {len(all_products)} products in {elapsed:.2f}s")

    return {
        "status": "success",
        "total_products": len(all_products),
        "message": f"Scraped {len(all_products)} products in {elapsed:.2f}s"
    }


# ===============================================
# MAIN CLI
# ===============================================

async def main():
    query = input("Enter search query: ").strip()
    print("Sort by:")
    print("1. Relevance")
    print("2. Price: High to Low")
    print("3. Price: Low to High")
    choice = input("Choose [1-3]: ").strip()

    sort_order = {"2": "desc", "3": "asc"}.get(choice)

    result = await scrape_products(query, sort_order, is_prefetch=False)
    print(f"\n{result['message']}")

    # Preview
    metadata = await get_redis_metadata(query, sort_order)
    if metadata and metadata.get("total_products", 0) > 0:
        redis_client = await get_redis_client()
        key = f'ajio:{query}:{"relevance" if sort_order is None else sort_order}:data'
        data = await redis_client.get(key)
        await redis_client.close()
        if data:
            products = json.loads(data).get("products", [])[:10]
            print("\nFirst 10 products:")
            for i, p in enumerate(products, 1):
                print(f"{i}. {p.get('name', 'N/A')} - ₹{p.get('price')} (was ₹{p.get('original_price')})")


if __name__ == "__main__":
    # Set logging level
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())