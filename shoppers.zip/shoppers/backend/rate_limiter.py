"""
Rate Limiting Middleware for FastAPI
Uses Redis for distributed rate limiting
"""
from fastapi import Request, HTTPException, status
from starlette.middleware.base import BaseHTTPMiddleware
import redis.asyncio as aioredis
import time
import logging
from typing import Optional

logger = logging.getLogger(__name__)

class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, redis_url: str = "redis://redis:6379/0", 
                 requests_per_minute: int = 60, 
                 burst: int = 10):
        super().__init__(app)
        self.redis_url = redis_url
        self.requests_per_minute = requests_per_minute
        self.burst = burst
        self.window_size = 60  # 1 minute in seconds
        
    async def get_redis(self) -> aioredis.Redis:
        """Get Redis connection"""
        return await aioredis.from_url(self.redis_url, decode_responses=True)
    
    async def get_client_identifier(self, request: Request) -> str:
        """Get unique identifier for client (IP + User-Agent)"""
        # Try to get real IP from headers (for proxy/load balancer scenarios)
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            client_ip = forwarded.split(",")[0].strip()
        else:
            client_ip = request.client.host if request.client else "unknown"
        
        # Include user agent for more granular rate limiting
        user_agent = request.headers.get("User-Agent", "unknown")
        return f"ratelimit:{client_ip}:{hash(user_agent)}"
    
    async def is_rate_limited(self, identifier: str) -> tuple[bool, Optional[int]]:
        """
        Check if client is rate limited using sliding window algorithm
        Returns: (is_limited, retry_after_seconds)
        """
        try:
            redis_client = await self.get_redis()
            current_time = int(time.time())
            window_start = current_time - self.window_size
            
            # Remove old entries outside the window
            await redis_client.zremrangebyscore(identifier, 0, window_start)
            
            # Count requests in current window
            request_count = await redis_client.zcard(identifier)
            
            if request_count >= self.requests_per_minute:
                # Get the oldest request in window to calculate retry_after
                oldest = await redis_client.zrange(identifier, 0, 0, withscores=True)
                if oldest:
                    oldest_time = int(oldest[0][1])
                    retry_after = oldest_time + self.window_size - current_time
                    await redis_client.close()
                    return True, retry_after
            
            # Add current request
            await redis_client.zadd(identifier, {str(current_time): current_time})
            
            # Set expiry on the key (cleanup)
            await redis_client.expire(identifier, self.window_size + 10)
            
            await redis_client.close()
            return False, None
            
        except Exception as e:
            logger.error(f"Rate limiting error: {e}")
            # Fail open - don't block requests if Redis is down
            return False, None
    
    async def dispatch(self, request: Request, call_next):
        # Skip rate limiting for health check endpoints
        if request.url.path in ["/health", "/docs", "/redoc", "/openapi.json"]:
            return await call_next(request)
        
        # Get client identifier
        identifier = await self.get_client_identifier(request)
        
        # Check rate limit
        is_limited, retry_after = await self.is_rate_limited(identifier)
        
        if is_limited:
            logger.warning(f"Rate limit exceeded for {identifier}")
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Rate limit exceeded. Try again in {retry_after} seconds.",
                headers={"Retry-After": str(retry_after)}
            )
        
        # Add rate limit headers to response
        response = await call_next(request)
        
        try:
            redis_client = await self.get_redis()
            remaining = self.requests_per_minute - await redis_client.zcard(identifier)
            await redis_client.close()
            
            response.headers["X-RateLimit-Limit"] = str(self.requests_per_minute)
            response.headers["X-RateLimit-Remaining"] = str(max(0, remaining))
            response.headers["X-RateLimit-Reset"] = str(int(time.time()) + self.window_size)
        except:
            pass
        
        return response


class EndpointRateLimiter:
    """
    Decorator for specific endpoint rate limiting
    Usage: @EndpointRateLimiter(requests=10, window=60)
    """
    def __init__(self, requests: int = 10, window: int = 60):
        self.requests = requests
        self.window = window
        self.redis_url = "redis://redis:6379/0"
    
    async def get_redis(self) -> aioredis.Redis:
        return await aioredis.from_url(self.redis_url, decode_responses=True)
    
    async def check_limit(self, identifier: str) -> tuple[bool, Optional[int]]:
        try:
            redis_client = await self.get_redis()
            current_time = int(time.time())
            window_start = current_time - self.window
            
            key = f"endpoint_ratelimit:{identifier}"
            
            await redis_client.zremrangebyscore(key, 0, window_start)
            request_count = await redis_client.zcard(key)
            
            if request_count >= self.requests:
                oldest = await redis_client.zrange(key, 0, 0, withscores=True)
                if oldest:
                    oldest_time = int(oldest[0][1])
                    retry_after = oldest_time + self.window - current_time
                    await redis_client.close()
                    return True, retry_after
            
            await redis_client.zadd(key, {str(current_time): current_time})
            await redis_client.expire(key, self.window + 10)
            
            await redis_client.close()
            return False, None
            
        except Exception as e:
            logger.error(f"Endpoint rate limiting error: {e}")
            return False, None
    
    def __call__(self, func):
        from functools import wraps
        
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Extract request from args or kwargs
            request = None
            for arg in args:
                if isinstance(arg, Request):
                    request = arg
                    break
            if not request and 'request' in kwargs:
                request = kwargs['request']
            
            if request:
                # Get client IP
                forwarded = request.headers.get("X-Forwarded-For")
                if forwarded:
                    client_ip = forwarded.split(",")[0].strip()
                else:
                    client_ip = request.client.host if request.client else "unknown"
                
                identifier = f"{client_ip}:{request.url.path}"
                is_limited, retry_after = await self.check_limit(identifier)
                
                if is_limited:
                    raise HTTPException(
                        status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                        detail=f"Too many requests. Try again in {retry_after} seconds.",
                        headers={"Retry-After": str(retry_after)}
                    )
            
            return await func(*args, **kwargs)
        
        return wrapper
