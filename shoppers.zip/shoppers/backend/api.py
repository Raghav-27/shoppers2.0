from fastapi import FastAPI, Request, Response, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, EmailStr
import redis.asyncio as aioredis
import json
import asyncio
from typing import Optional, List
import logging
from datetime import timedelta, datetime
import os
from dotenv import load_dotenv
from typing import Dict, Any


# Load environment variables
load_dotenv()

# Import auth functions
from sign_up import hash_password, generate_session_token, verify_password
# Import scraper modules
from meesho_scraper import scrape_products as scrape_meesho
from ajio_scraper import scrape_products as scrape_ajio
from shopshy_scraper import scrape_products as scrape_shopsy
from myntra_scraper import scrape_products as scrape_myntra
from flipkart_scraper import scrape_products as scrape_flipkart

# Import rate limiter
from rate_limiter import RateLimitMiddleware, EndpointRateLimiter

# Import seller product search
from seller_product_search import AsyncSellerProductSearch

# Import order manager
from order_manager import order_manager

# Configure logging
log_level = os.getenv('LOG_LEVEL', 'INFO')
logging.basicConfig(level=getattr(logging, log_level))
logger = logging.getLogger(__name__)

app = FastAPI(title="Shoppers API", version="1.0.0")

# CORS Configuration from environment
cors_origins = os.getenv('CORS_ORIGINS', 'http://localhost:3000,http://localhost:80').split(',')
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Add Rate Limiting Middleware
requests_per_minute = int(os.getenv('RATE_LIMIT_PER_MINUTE', 60))
app.add_middleware(
    RateLimitMiddleware,
    redis_url=f"redis://{os.getenv('REDIS_HOST', 'redis')}:{os.getenv('REDIS_PORT', 6379)}/0",
    requests_per_minute=requests_per_minute,
    burst=10
)

# Redis connection pool
redis_pool = None
REDIS_HOST = os.getenv('REDIS_HOST', 'redis')
REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))

# Seller product search instance
seller_search = None

async def get_redis() -> aioredis.Redis:
    """Get async Redis connection from pool"""
    global redis_pool
    if redis_pool is None:
        redis_pool = aioredis.ConnectionPool.from_url(
            f"redis://{REDIS_HOST}:{REDIS_PORT}/0",
            decode_responses=True,
            max_connections=50
        )
    return aioredis.Redis(connection_pool=redis_pool)

async def get_redis_seller() -> aioredis.Redis:
    """Get async Redis connection for seller data (DB 2)"""
    return await aioredis.Redis(
        host=REDIS_HOST,
        port=REDIS_PORT,
        db=2,
        decode_responses=True
    )

# Pydantic models for request validation
class SignupRequest(BaseModel):
    first_name: str
    last_name: str
    email: EmailStr
    phone: str
    country: str
    password: str

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class ListActionRequest(BaseModel):
    product_data: Dict[str, Any]

class OrderRequest(BaseModel):
    phone: str
    address: str
    items: List[Dict[str, Any]]
    payment_method: str = "cod"

class OrderStatusUpdate(BaseModel):
    status: str
    seller_id: Optional[str] = None

class AddressRequest(BaseModel):
    label: str  # Home, Office, etc.
    phone: str
    street: str
    city: str
    state: str
    postal_code: str
    country: str
    is_default: bool = False

class PaymentGatewayRequest(BaseModel):
    order_id: str
    amount: float
    payment_method: str = "online"

# ============================================
# SCRAPER HELPER FUNCTIONS
# ============================================

async def trigger_prefetch(query: str, sortorder: str):
    """Trigger prefetch for all platforms in background task"""
    try:
        logger.info(f"🔄 Starting prefetch for query: {query}, sort: {sortorder}")
        # Call all scrapers concurrently
        results = await asyncio.gather(
            scrape_meesho(query, sortorder, is_prefetch=True),
            scrape_ajio(query, sortorder, is_prefetch=True),
            scrape_shopsy(query, sortorder, is_prefetch=True),
            scrape_myntra(query, sortorder, is_prefetch=True),
            scrape_flipkart(query, sortorder, is_prefetch=True),
            return_exceptions=True
        )
        
        # Log results
        for platform, result in zip(["Meesho", "Ajio", "Shopsy", "Myntra", "Flipkart"], results):
            if isinstance(result, Exception):
                logger.error(f"❌ {platform} prefetch failed: {result}")
            else:
                logger.info(f"✅ {platform} prefetch completed: {result}")
                
    except Exception as e:
        logger.error(f"❌ Prefetch failed for query: {query}, sort: {sortorder}, error: {e}")

def should_prefetch(total_products: int, requested_end_index: int) -> bool:
    """Check if we should trigger prefetch based on remaining products"""
    if total_products <= 0:
        return False
    
    remaining_products = total_products - requested_end_index
    logger.info(f"📊 Prefetch check: {remaining_products} remaining products")
    
    # Trigger prefetch if 30 or fewer products remain
    return remaining_products <= 30

async def get_products_from_platform(platform: str, query: str, sortorder: str):
    """Fetch products from a specific platform (Meesho, Ajio, or Shopsy)"""
    redis_client = await get_redis()
    key = f"{platform}:{query}:{sortorder}:data"
    
    try:
        data_str = await redis_client.get(key)
        
        if not data_str:
            # Trigger scraper for this platform
            logger.info(f"🔍 No cached {platform} data, triggering scraper for: {query}")
            
            # Map platform to scraper
            scraper_map = {
                "meesho": scrape_meesho,
                "ajio": scrape_ajio,
                "shopsy": scrape_shopsy,
                "myntra": scrape_myntra,
                "flipkart": scrape_flipkart
            }
            
            scraper = scraper_map.get(platform)
            if not scraper:
                logger.error(f"Unknown platform: {platform}")
                return []
                
            result = await scraper(query, sortorder, is_prefetch=False)
            logger.info(f"{platform} scraper result: {result}")
            
            # Try to fetch again after scraping
            data_str = await redis_client.get(key)
        
        if data_str:
            parsed = json.loads(data_str)
            products = parsed.get("products", [])
            # Add platform identifier to each product
            for product in products:
                product["source_platform"] = platform
            return products
        
        return []
    except Exception as e:
        logger.error(f"Error fetching {platform} products: {e}")
        return []
    finally:
        await redis_client.close()

async def get_products_from_redis(query: str, sortorder: str = "relevance", page: int = 1, per_page: int = 10):
    """Fetch products from each platform with pagination - returns 10 products per platform per page with metadata"""
    try:
        # Fetch from all five platforms concurrently
        meesho_products, ajio_products, shopsy_products, myntra_products, flipkart_products = await asyncio.gather(
            get_products_from_platform("meesho", query, sortorder),
            get_products_from_platform("ajio", query, sortorder),
            get_products_from_platform("shopsy", query, sortorder),
            get_products_from_platform("myntra", query, sortorder),
            get_products_from_platform("flipkart", query, sortorder),
            return_exceptions=True
        )
        
        # Handle exceptions
        if isinstance(meesho_products, Exception):
            logger.error(f"Meesho error: {meesho_products}")
            meesho_products = []
        if isinstance(ajio_products, Exception):
            logger.error(f"Ajio error: {ajio_products}")
            ajio_products = []
        if isinstance(shopsy_products, Exception):
            logger.error(f"Shopsy error: {shopsy_products}")
            shopsy_products = []
        if isinstance(myntra_products, Exception):
            logger.error(f"Myntra error: {myntra_products}")
            myntra_products = []
        if isinstance(flipkart_products, Exception):
            logger.error(f"Flipkart error: {flipkart_products}")
            flipkart_products = []
        
        # Store total products available per platform
        metadata = {
            "meesho": len(meesho_products),
            "ajio": len(ajio_products),
            "shopsy": len(shopsy_products),
            "myntra": len(myntra_products),
            "flipkart": len(flipkart_products)
        }
        
        # Paginate: 10 products per platform per page
        products_per_platform_per_page = 10
        start_idx = (page - 1) * products_per_platform_per_page
        end_idx = start_idx + products_per_platform_per_page
        
        products = {
            "meesho": meesho_products[start_idx:end_idx],
            "ajio": ajio_products[start_idx:end_idx],
            "shopsy": shopsy_products[start_idx:end_idx],
            "myntra": myntra_products[start_idx:end_idx],
            "flipkart": flipkart_products[start_idx:end_idx]
        }
        
        # Calculate total products currently returned on this page
        current_page_total = (
            len(products["meesho"]) +
            len(products["ajio"]) +
            len(products["shopsy"]) +
            len(products["myntra"]) +
            len(products["flipkart"])
        )
        
        # Calculate maximum possible products across all platforms
        max_products = max(
            metadata["meesho"],
            metadata["ajio"],
            metadata["shopsy"],
            metadata["myntra"],
            metadata["flipkart"]
        )
        
        # Calculate total pages based on the platform with most products
        total_pages = (max_products + products_per_platform_per_page - 1) // products_per_platform_per_page if max_products > 0 else 1
        
        logger.info(f"✅ Page {page}/{total_pages}: Meesho={len(products['meesho'])}/{metadata['meesho']}, Ajio={len(products['ajio'])}/{metadata['ajio']}, Shopsy={len(products['shopsy'])}/{metadata['shopsy']}, Myntra={len(products['myntra'])}/{metadata['myntra']}, Flipkart={len(products['flipkart'])}/{metadata['flipkart']}")
        return products, metadata, current_page_total, total_pages
        
    except Exception as e:
        logger.error(f"Error in get_products_from_redis: {e}")
        empty_metadata = {"meesho": 0, "ajio": 0, "shopsy": 0, "myntra": 0, "flipkart": 0}
        empty_products = {"meesho": [], "ajio": [], "shopsy": [], "myntra": [], "flipkart": []}
        return empty_products, empty_metadata, 0, 1

# ============================================
# SEARCH ENDPOINT
# ============================================

@app.get("/api/search")
@EndpointRateLimiter(requests=20, window=60)  # Max 20 searches per minute
async def search(
    request: Request,
    query: str = "",
    sort: str = "relevance",
    page: int = 1,
    per_page: int = 10,
    include_sellers: bool = True
):
    """Search for products - includes seller products when include_sellers=True"""
    query = query.strip()
    sort = sort.strip()
    
    if not query:
        return {
            'metadata': {"meesho": 0, "ajio": 0, "shopsy": 0, "myntra": 0, "flipkart": 0},
            'products': {"meesho": [], "ajio": [], "shopsy": [], "myntra": [], "flipkart": []}, 
            'total': 0, 
            'page': page, 
            'per_page': per_page,
            'total_pages': 0,
            'prefetch_status': 'idle'
        }
    
    # Get scraped products (existing functionality)
    products_by_platform, metadata, total_products, total_pages = await get_products_from_redis(query, sort, page, per_page)
    
    # Add seller products if requested WITH PAGINATION
    seller_products = []
    total_seller_products = 0
    if include_sellers:
        try:
            global seller_search
            if seller_search is None:
                seller_search = AsyncSellerProductSearch(redis_host=REDIS_HOST, redis_port=REDIS_PORT)
                logger.info("Initializing seller search on first use")
            
            # Get ALL matching seller products
            all_seller_results = await seller_search.fuzzy_search_sellers(query, threshold=60)
            total_seller_products = len(all_seller_results)
            
            # Apply pagination to seller products (20 per page)
            start_idx = (page - 1) * per_page
            end_idx = start_idx + per_page
            seller_products = all_seller_results[start_idx:end_idx]
            
            logger.info(f"Found {total_seller_products} total seller products for query '{query}', returning {len(seller_products)} for page {page}")
        except Exception as e:
            logger.error(f"Error searching seller products: {e}", exc_info=True)
            seller_products = []
            total_seller_products = 0
    
    # Calculate remaining products for each platform independently
    consumed_idx = page * per_page  # Products consumed up to current page
    
    remaining_products = {
        'meesho': metadata.get('meesho', 0) - consumed_idx,
        'ajio': metadata.get('ajio', 0) - consumed_idx,
        'shopsy': metadata.get('shopsy', 0) - consumed_idx,
        'myntra': metadata.get('myntra', 0) - consumed_idx,
        'flipkart': metadata.get('flipkart', 0) - consumed_idx
    }
    
    # Log remaining products for each platform
    logger.info(f"📊 Remaining Products - Meesho: {remaining_products['meesho']}, "
                f"Ajio: {remaining_products['ajio']}, Shopsy: {remaining_products['shopsy']}, "
                f"Myntra: {remaining_products['myntra']}, Flipkart: {remaining_products['flipkart']}")
    
    # Check if ANY platform has 30 or fewer products remaining
    platforms_low = [platform for platform, remaining in remaining_products.items() 
                     if remaining > 0 and remaining <= 30]
    
    platforms_warning = [platform for platform, remaining in remaining_products.items() 
                         if remaining > 30 and remaining <= 50]
    
    # Trigger prefetch if any platform is running low
    if platforms_low:
        logger.info(f"🚀 Triggering background prefetch - Low products on: {', '.join(platforms_low)}")
        # Trigger prefetch in background without blocking response
        asyncio.create_task(trigger_prefetch(query, sort))
    
    # Calculate prefetch status based on any platform's remaining products
    prefetch_status = 'idle'
    if platforms_low:
        prefetch_status = 'triggered'
    elif platforms_warning:
        prefetch_status = 'warning'
    
    return {
        'metadata': metadata,
        'products': products_by_platform, 
        'seller_products': seller_products,  # Add seller products separately
        'total': total_products,
        'page': page,
        'per_page': per_page,
        'total_pages': total_pages,
        'prefetch_status': prefetch_status,
        'remaining_products': remaining_products,  # Include all remaining counts
        'platforms_low': platforms_low,  # Which platforms triggered prefetch
        'platforms_warning': platforms_warning  # Which platforms are in warning zone
    }

# ============================================
# AUTHENTICATION ENDPOINTS
# ============================================

from fastapi import Response
import secrets
import time

SESSION_EXPIRY = 60 * 60 * 24 * 7  # 7 days

@app.post("/api/signup", status_code=status.HTTP_201_CREATED)
async def signup(signup_data: SignupRequest, response: Response):
    """User signup + auto-login (creates session cookie)"""
    try:
        redis_client = await get_redis()

        # ----- Check if user exists -----
        user_key = f"user:{signup_data.email}"
        exists = await redis_client.exists(user_key)

        if exists:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="User already exists with this email"
            )

        # ----- Create user -----
        user_data = {
            "first_name": signup_data.first_name,
            "last_name": signup_data.last_name,
            "email": signup_data.email,
            "phone": signup_data.phone,
            "country": signup_data.country,
            "password": hash_password(signup_data.password),
            "created_at": int(time.time())
        }

        state_data = {
            "wishlist": [],
            "compare": [],
            "cart": []
        }

        # Save user + state
        await redis_client.set(user_key, json.dumps(user_data))
        await redis_client.set(f"{user_key}:state", json.dumps(state_data))

        # ----- CREATE SESSION TOKEN -----
        session_token = secrets.token_hex(32)
        session_key = f"session:{session_token}"

        session_data = {
            "email": signup_data.email,
            "created": int(time.time())
        }

        # Store session in Redis
        await redis_client.setex(
            session_key, SESSION_EXPIRY, json.dumps(session_data)
        )

        # ----- SET SESSION COOKIE -----
        response.set_cookie(
            key="auth_token",
            value=session_token,
            httponly=True,
            secure=False,            # change to True on HTTPS
            samesite="lax",
            max_age=SESSION_EXPIRY,
            path="/"
        )

        # Remove password before sending back
        user_data.pop("password")

        await redis_client.close()

        return {
            "message": "Signup successful",
            "user": user_data
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Signup error: {e}")
        raise HTTPException(500, str(e))


@app.post("/api/login")
async def login(login_data: LoginRequest, response: Response):
    """User login endpoint"""
    try:
        redis_client = await get_redis()
        
        # Get user data
        user_key = f"user:{login_data.email}"
        user_data_str = await redis_client.get(user_key)
        
        if not user_data_str:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password"
            )
        
        user_data = json.loads(user_data_str)
        
        # Verify password using bcrypt
        if not verify_password(login_data.password, user_data["password"]):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password"
            )
        
        # Generate session token
        token = generate_session_token(login_data.email)
        session_key = f"session:{token}"
        
        session_data = {
            "email": login_data.email,
            "created_at": asyncio.get_event_loop().time()
        }
        
        # Store session with 7 days expiry
        await redis_client.setex(session_key, 60 * 60 * 24 * 7, json.dumps(session_data))
        
        # Remove password from response
        user_data.pop('password', None)
        
        await redis_client.close()
        
        # Set HTTP-only cookie
        response.set_cookie(
            key="auth_token",
            value=token,
            max_age=60*60*24*7,  # 7 days
            httponly=True,
            secure=False,  # Set to True in production with HTTPS
            samesite="lax",
            path="/"
        )
        
        return {
            'message': 'Login successful',
            'token': token,
            'user': user_data
        }
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Login error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.post("/api/logout")
async def logout(request: Request, response: Response):
    """User logout endpoint"""
    try:
        # Get token from cookie
        token = request.cookies.get('auth_token')
        
        if not token:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No active session found"
            )
        
        redis_client = await get_redis()
        
        # Delete session from Redis
        session_key = f"session:{token}"
        await redis_client.delete(session_key)
        
        await redis_client.close()
        
        # Clear cookie
        response.delete_cookie(key="auth_token", path="/")
        
        return {'message': 'Logged out successfully'}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Logout error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.get("/api/validate-session")
async def validate_session(request: Request):
    """Validate user using session cookie"""
    try:
        token = request.cookies.get("auth_token")
        if not token:
            return {"valid": False}

        redis_client = await get_redis()

        session_key = f"session:{token}"
        session_data_str = await redis_client.get(session_key)

        if not session_data_str:
            await redis_client.close()
            return {"valid": False}

        session_data = json.loads(session_data_str)
        user_key = f"user:{session_data['email']}"

        user_data_str = await redis_client.get(user_key)
        await redis_client.close()

        if not user_data_str:
            return {"valid": False}

        user_data = json.loads(user_data_str)
        user_data.pop("password", None)

        return {"valid": True, "user": user_data}

    except Exception as e:
        logger.error(f"Validate session error: {e}")
        return {"valid": False}


# ============================================
# USER LIST MANAGEMENT (Wishlist, Cart, Compare)
# ============================================

async def get_user_from_session(request: Request) -> str:
    """Helper function to get user email from session token"""
    token = request.cookies.get('auth_token')
    
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required"
        )
    
    redis_client = await get_redis()
    session_key = f"session:{token}"
    session_data_str = await redis_client.get(session_key)
    
    if not session_data_str:
        await redis_client.close()
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired session"
        )
    
    session_data = json.loads(session_data_str)
    await redis_client.close()
    
    return session_data['email']

@app.post("/api/user/wishlist")
async def add_to_wishlist(request: Request, action_data: ListActionRequest):
    """Add full product object to wishlist (array mode)"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()
        
        key_state = f"user:{email}:state"
        state_str = await redis_client.get(key_state)

        if not state_str:
            raise HTTPException(
                status_code=404,
                detail="User state not found"
            )

        state = json.loads(state_str)

        # ensure wishlist array exists
        wishlist = state.setdefault("wishlist", [])

        product = action_data.product_data
        product_id = str(product.get("id"))

        # prevent duplicates
        if not any(str(p.get("id")) == product_id for p in wishlist):
            wishlist.append(product)

        # save back
        await redis_client.set(key_state, json.dumps(state))
        await redis_client.close()

        return {"message": "Product added to wishlist"}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, detail=str(e))

@app.delete("/api/user/wishlist")
async def remove_from_wishlist(request: Request, action_data: ListActionRequest):
    """Remove product from wishlist (supports both old IDs and new product objects)"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()

        key_state = f"user:{email}:state"
        state_str = await redis_client.get(key_state)

        if not state_str:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User state not found"
            )

        state = json.loads(state_str)

        # --------------------------
        # Normalize wishlist format
        # --------------------------
        raw_wishlist = state.get("wishlist", [])
        wishlist = []

        for item in raw_wishlist:
            if isinstance(item, str):
                wishlist.append({"id": item})  # old format → normalized
            else:
                wishlist.append(item)

        state["wishlist"] = wishlist

        # --------------------------
        # Remove matching product
        # --------------------------
        product_obj = action_data.product_data
        product_id = product_obj.get("id")

        # Filter out the product
        updated = [item for item in wishlist if item.get("id") != product_id]

        state["wishlist"] = updated

        await redis_client.set(key_state, json.dumps(state))
        await redis_client.close()

        logger.info(f"🗑️ Removed product {product_id} from wishlist for {email}")

        return {"message": "Product removed from wishlist"}

    except HTTPException:
        raise

    except Exception as e:
        logger.error(f"Remove from wishlist error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.post("/api/user/cart")
async def add_to_cart(request: Request, action_data: ListActionRequest):
    """Add full product object to cart (no string ID normalization)"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()

        key_state = f"user:{email}:state"
        state_str = await redis_client.get(key_state)

        if not state_str:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User state not found"
            )

        state = json.loads(state_str)

        # Ensure cart list exists
        cart = state.setdefault("cart", [])

        product_obj = action_data.product_data
        product_id = product_obj.get("id")

        if not product_id:
            raise HTTPException(
                status_code=400,
                detail="Product ID missing from product_data"
            )

        # Check if already added
        exists = any(item.get("id") == product_id for item in cart)

        if not exists:
            cart.append(product_obj)
            await redis_client.set(key_state, json.dumps(state))

            logger.info(f"🛒 Added product {product_id} to cart for {email}")

        await redis_client.close()

        return {"message": "Product added to cart"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Add to cart error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.delete("/api/user/cart")
async def remove_from_cart(request: Request, action_data: ListActionRequest):
    """Remove a full product object from cart using product_data.id"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()

        key_state = f"user:{email}:state"
        state_str = await redis_client.get(key_state)

        if not state_str:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User state not found"
            )

        state = json.loads(state_str)

        cart = state.get("cart", [])

        product_obj = action_data.product_data
        product_id = product_obj.get("id")

        if not product_id:
            raise HTTPException(
                status_code=400,
                detail="Product ID missing from product_data"
            )

        # Filter cart to remove matching product
        new_cart = [item for item in cart if item.get("id") != product_id]

        # Only update if something was removed
        if len(new_cart) != len(cart):
            state["cart"] = new_cart
            await redis_client.set(key_state, json.dumps(state))
            logger.info(f"🗑️ Removed product {product_id} from cart for {email}")

        await redis_client.close()

        return {"message": "Product removed from cart"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Remove from cart error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.put("/api/user/cart/{product_id}")
async def update_cart_quantity(request: Request, product_id: str, quantity_data: Dict[str, Any]):
    """Update quantity of a product in cart"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()

        key_state = f"user:{email}:state"
        state_str = await redis_client.get(key_state)

        if not state_str:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User state not found"
            )

        state = json.loads(state_str)
        cart = state.get("cart", [])
        
        new_quantity = int(quantity_data.get("quantity", 1))
        
        if new_quantity < 1:
            # If quantity is 0 or less, remove the item
            state["cart"] = [item for item in cart if item.get("id") != product_id]
        else:
            # Update the quantity
            found = False
            for item in cart:
                if item.get("id") == product_id:
                    item["quantity"] = new_quantity
                    found = True
                    break
            
            if not found:
                raise HTTPException(
                    status_code=404,
                    detail="Product not found in cart"
                )
        
        await redis_client.set(key_state, json.dumps(state))
        logger.info(f"📦 Updated product {product_id} quantity to {new_quantity} in cart for {email}")

        await redis_client.close()

        return {"message": "Cart updated", "quantity": new_quantity}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update cart error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )


@app.post("/api/user/compare")
async def add_to_compare(request: Request, action_data: ListActionRequest):
    """Add a full product object to compare list"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()

        key_state = f"user:{email}:state"
        state_str = await redis_client.get(key_state)

        if not state_str:
            raise HTTPException(
                status_code=404,
                detail="User state not found"
            )

        state = json.loads(state_str)
        compare = state.get("compare", [])

        product_obj = action_data.product_data
        product_id = product_obj.get("id")

        if not product_id:
            raise HTTPException(status_code=400, detail="Product ID missing")

        # prevent duplicates
        if not any(item.get("id") == product_id for item in compare):
            compare.append(product_obj)
            state["compare"] = compare
            await redis_client.set(key_state, json.dumps(state))
            logger.info(f"➕ Added product {product_id} to compare for {email}")

        await redis_client.close()
        return {"message": "Product added to compare"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Add to compare error: {e}")
        raise HTTPException(500, detail=str(e))

@app.delete("/api/user/compare")
async def remove_from_compare(request: Request, action_data: ListActionRequest):
    """Remove a full product object from compare list using product_data.id"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()

        key_state = f"user:{email}:state"
        state_str = await redis_client.get(key_state)

        if not state_str:
            raise HTTPException(
                status_code=404,
                detail="User state not found"
            )

        state = json.loads(state_str)
        compare = state.get("compare", [])

        product_obj = action_data.product_data
        product_id = product_obj.get("id")

        if not product_id:
            raise HTTPException(status_code=400, detail="Product ID missing")

        # filter out the product with matching id
        new_compare = [item for item in compare if item.get("id") != product_id]

        if len(new_compare) != len(compare):
            state["compare"] = new_compare
            await redis_client.set(key_state, json.dumps(state))
            logger.info(f"🗑️ Removed product {product_id} from compare for {email}")

        await redis_client.close()
        return {"message": "Product removed from compare"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Remove from compare error: {e}")
        raise HTTPException(500, detail=str(e))



@app.get("/api/user/lists")
async def get_user_lists(request: Request):
    """Get all user lists (wishlist, cart, compare)"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()
        
        key_state = f"user:{email}:state"
        state_str = await redis_client.get(key_state)
        
        await redis_client.close()
        
        if state_str:
            state = json.loads(state_str)
            return {
                'wishlist': state.get('wishlist', []),
                'cart': state.get('cart', []),
                'compare': state.get('compare', [])
            }
        else:
            return {
                'wishlist': [],
                'cart': [],
                'compare': []
            }
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get user lists error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

# ============================================
# ORDER MANAGEMENT
# ============================================

@app.post("/api/orders/create")
async def create_order(request: Request, order_req: OrderRequest):
    """Create a new order for seller products"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()
        
        # Get user data
        user_data_str = await redis_client.get(f"user:{email}")
        if not user_data_str:
            raise HTTPException(status_code=404, detail="User not found")
        
        user_data = json.loads(user_data_str)
        user_id = user_data.get('email')  # Using email as user_id
        user_name = f"{user_data.get('first_name', '')} {user_data.get('last_name', '')}".strip()
        
        await redis_client.close()
        
        # Create order
        order = await order_manager.create_order(
            user_id=user_id,
            user_name=user_name,
            user_email=email,
            phone=order_req.phone,
            address=order_req.address,
            items=order_req.items,
            payment_method=order_req.payment_method
        )
        
        return {
            "success": True,
            "message": "Order placed successfully",
            "order": order
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Create order error: {e}")
        raise HTTPException(500, detail=str(e))

@app.get("/api/orders/user")
async def get_user_orders(request: Request):
    """Get all orders for the logged-in user"""
    try:
        email = await get_user_from_session(request)
        
        # Get user orders
        orders = await order_manager.get_user_orders(user_id=email)
        
        return {
            "success": True,
            "orders": orders
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get user orders error: {e}")
        raise HTTPException(500, detail=str(e))

@app.get("/api/orders/{order_id}")
async def get_order_details(request: Request, order_id: str):
    """Get details of a specific order"""
    try:
        email = await get_user_from_session(request)
        
        # Get order
        order = await order_manager.get_order(order_id)
        if not order:
            raise HTTPException(status_code=404, detail="Order not found")
        
        # Verify user owns this order
        if order.get('user_id') != email:
            raise HTTPException(status_code=403, detail="Access denied")
        
        return {
            "success": True,
            "order": order
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get order details error: {e}")
        raise HTTPException(500, detail=str(e))

@app.post("/api/orders/{order_id}/cancel")
async def cancel_order(request: Request, order_id: str):
    """Cancel an order"""
    try:
        email = await get_user_from_session(request)
        
        # Cancel order
        success = await order_manager.cancel_order(order_id=order_id, user_id=email)
        
        if not success:
            raise HTTPException(status_code=400, detail="Unable to cancel order")
        
        return {
            "success": True,
            "message": "Order cancelled successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Cancel order error: {e}")
        raise HTTPException(500, detail=str(e))

@app.get("/api/seller/orders")
async def get_seller_orders(seller_id: str):
    """Get all orders for a seller"""
    try:
        # Get seller orders
        orders = await order_manager.get_seller_orders(seller_id=seller_id)
        
        return {
            "success": True,
            "orders": orders
        }
        
    except Exception as e:
        logger.error(f"Get seller orders error: {e}")
        raise HTTPException(500, detail=str(e))

@app.post("/api/seller/orders/{order_id}/status")
async def update_order_status(order_id: str, status_update: OrderStatusUpdate, seller_id: str):
    """Update order status by seller"""
    try:
        # Update order status
        success = await order_manager.update_order_status(
            order_id=order_id,
            status=status_update.status,
            seller_id=seller_id
        )
        
        if not success:
            raise HTTPException(status_code=400, detail="Unable to update order status")
        
        return {
            "success": True,
            "message": "Order status updated successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update order status error: {e}")
        raise HTTPException(500, detail=str(e))

@app.post("/api/orders/{order_id}/mark-completed")
async def mark_order_completed(order_id: str, request: Request):
    """Mark order as completed by buyer"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()
        
        # Get order from order manager
        order = await order_manager.get_order(order_id)
        if not order:
            await redis_client.close()
            raise HTTPException(status_code=404, detail="Order not found")
        
        # Verify this is the buyer's order
        if order.get('user_email') != email:
            await redis_client.close()
            raise HTTPException(status_code=403, detail="Not authorized to complete this order")
        
        # Verify order is delivered from seller side
        seller_status = order.get('seller_status', 'pending')
        if seller_status != 'delivered':
            await redis_client.close()
            raise HTTPException(status_code=400, detail=f"Order must be delivered by seller first (current seller status: {seller_status})")
        
        # Update order status
        success = await order_manager.update_order_status(
            order_id=order_id,
            buyer_status='completed'
        )
        
        await redis_client.close()
        
        if not success:
            raise HTTPException(status_code=400, detail="Unable to mark order as completed")
        
        logger.info(f"Order {order_id} marked as completed by buyer {email}")
        
        return {
            "success": True,
            "message": "Order marked as completed",
            "order_id": order_id,
            "buyer_status": "completed"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Mark order completed error: {e}")
        raise HTTPException(500, detail=str(e))

# ============================================
# SELLER PRODUCT SEARCH
# ============================================

@app.on_event("startup")
async def startup_event():
    """Initialize seller product search and order manager on startup"""
    global seller_search
    seller_search = AsyncSellerProductSearch(redis_host=REDIS_HOST, redis_port=REDIS_PORT)
    logger.info("✅ Async seller product search initialized")
    
    # Initialize order manager
    await order_manager.connect()

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup seller product search and order manager on shutdown"""
    global seller_search
    if seller_search:
        await seller_search.close()
        logger.info("✅ Async seller product search closed")
    
    # Close order manager
    await order_manager.close()

@app.post("/api/products/search")
@EndpointRateLimiter(requests=30, window=60)  # Max 30 searches per minute
async def unified_search(
    request: Request,
    query: str = "",
    sort: str = "relevance",
    page: int = 1,
    per_page: int = 10,
    category: str = None,
    min_price: float = None,
    max_price: float = None,
    fuzzy_threshold: int = 50
):
    """Unified search endpoint with async seller product fuzzy matching and scraped products"""
    global seller_search
    
    query = query.strip()
    
    if not query:
        return {
            'metadata': {"meesho": 0, "ajio": 0, "shopsy": 0, "myntra": 0, "flipkart": 0, "seller": 0},
            'products': {"meesho": [], "ajio": [], "shopsy": [], "shopsy": [], "myntra": [], "flipkart": [], "seller": []},
            'total': 0,
            'page': page,
            'per_page': per_page,
            'total_pages': 0,
            'prefetch_status': 'idle'
        }
    
    try:
        # Run seller fuzzy search and scraped product search concurrently
        seller_task = seller_search.search_with_filters(
            query=query,
            category=category,
            min_price=min_price,
            max_price=max_price,
            threshold=fuzzy_threshold
        ) if seller_search else asyncio.create_task(asyncio.sleep(0))
        
        scraped_task = get_products_from_redis(query, sort, page, per_page)
        
        # Wait for both to complete
        seller_results, (products_by_platform, metadata, total_products, total_pages) = await asyncio.gather(
            seller_task,
            scraped_task,
            return_exceptions=True
        )
        
        # Handle exceptions
        if isinstance(seller_results, Exception):
            logger.error(f"Seller search error: {seller_results}")
            seller_results = []
        
        if isinstance(products_by_platform, Exception):
            logger.error(f"Scraped search error: {products_by_platform}")
            products_by_platform = {"meesho": [], "ajio": [], "shopsy": [], "myntra": [], "flipkart": []}
            metadata = {"meesho": 0, "ajio": 0, "shopsy": 0, "myntra": 0, "flipkart": 0}
            total_products = 0
            total_pages = 0
        
        # Paginate seller results
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        paginated_seller_results = seller_results[start_idx:end_idx] if seller_results else []
        
        # Add seller products to response
        products_by_platform['seller'] = paginated_seller_results
        metadata['seller'] = len(seller_results) if seller_results else 0
        
        # Calculate total products including seller products
        total_with_seller = total_products + len(paginated_seller_results)
        
        # Calculate remaining products for prefetch logic
        consumed_idx = page * per_page
        remaining_products = {
            'meesho': metadata.get('meesho', 0) - consumed_idx,
            'ajio': metadata.get('ajio', 0) - consumed_idx,
            'shopsy': metadata.get('shopsy', 0) - consumed_idx,
            'myntra': metadata.get('myntra', 0) - consumed_idx,
            'flipkart': metadata.get('flipkart', 0) - consumed_idx
        }
        
        # Check if ANY platform has 30 or fewer products remaining
        platforms_low = [platform for platform, remaining in remaining_products.items()
                         if remaining > 0 and remaining <= 30]
        
        platforms_warning = [platform for platform, remaining in remaining_products.items()
                             if remaining > 30 and remaining <= 50]
        
        # Trigger prefetch if any platform is running low
        if platforms_low:
            logger.info(f"🚀 Triggering background prefetch - Low products on: {', '.join(platforms_low)}")
            asyncio.create_task(trigger_prefetch(query, sort))
        
        # Calculate prefetch status
        prefetch_status = 'idle'
        if platforms_low:
            prefetch_status = 'triggered'
        elif platforms_warning:
            prefetch_status = 'warning'
        
        logger.info(f"✅ Unified search: {len(seller_results) if seller_results else 0} seller products, "
                    f"{total_products} scraped products for query: {query}")
        
        return {
            'metadata': metadata,
            'products': products_by_platform,
            'total': total_with_seller,
            'page': page,
            'per_page': per_page,
            'total_pages': total_pages,
            'prefetch_status': prefetch_status,
            'seller_fuzzy_count': len(seller_results) if seller_results else 0
        }
        
    except Exception as e:
        logger.error(f"Unified search error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Search failed: {str(e)}"
        )

@app.get("/api/seller/product/{product_id}")
async def get_seller_product_details(product_id: str):
    """Get detailed information about a seller product"""
    try:
        redis_client = await get_redis_seller()
        
        # Get all seller IDs
        seller_emails = await redis_client.hgetall('seller:emails')
        
        # Search for the product across all sellers
        for email, seller_id in seller_emails.items():
            product_key = f'seller:{seller_id}:product:{product_id}'
            product_data = await redis_client.hgetall(product_key)
            
            if product_data and product_data.get('is_active') == '1':
                # Get seller info
                seller_key = f'seller:{seller_id}'
                seller_data = await redis_client.hgetall(seller_key)
                
                # Get store info if exists
                store_data = {}
                store_id = product_data.get('store_id')
                if store_id:
                    store_key = f'seller:{seller_id}:store:{store_id}'
                    store_data = await redis_client.hgetall(store_key)
                
                # Collect all images
                images = []
                for i in range(1, 6):
                    img_key = f'image_url_{i}' if i > 1 else 'image_url'
                    img_url = product_data.get(img_key)
                    if img_url:
                        images.append(img_url)
                
                product_details = {
                    'id': product_id,
                    'name': product_data.get('name'),
                    'description': product_data.get('description', ''),
                    'price': float(product_data.get('price', 0)),
                    'category': product_data.get('category', ''),
                    'stock': int(product_data.get('stock', 0)),
                    'images': images,
                    'seller': {
                        'id': seller_id,
                        'business_name': seller_data.get('business_name', ''),
                        'email': seller_data.get('email', ''),
                        'phone': seller_data.get('phone', '')
                    },
                    'store': {
                        'id': store_id,
                        'name': store_data.get('name', ''),
                        'address': store_data.get('address', ''),
                        'phone': store_data.get('phone', '')
                    } if store_data else None
                }
                
                await redis_client.close()
                return product_details
        
        await redis_client.close()
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching seller product details: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.post("/api/seller/products/index")
async def trigger_seller_indexing():
    """Trigger indexing of all seller products (called by seller-backend after product changes)"""
    global seller_search
    
    if not seller_search:
        seller_search = AsyncSellerProductSearch(redis_host=REDIS_HOST, redis_port=REDIS_PORT)
        logger.info("Initializing seller search for indexing")
    
    try:
        result = await seller_search.index_seller_products()
        logger.info(f"✅ Seller product indexing completed: {result} products indexed")
        return {"status": "success", "indexed_count": result, "message": f"Successfully indexed {result} seller products"}
    except Exception as e:
        logger.error(f"Indexing trigger error: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Indexing failed: {str(e)}"
        )

@app.get("/api/seller/products/index/status")
async def get_index_status():
    """Check if seller products are indexed"""
    try:
        redis_client = await aioredis.Redis(
            host=REDIS_HOST,
            port=REDIS_PORT,
            db=3,  # Search index DB
            decode_responses=True
        )
        
        indexed_products = await redis_client.smembers('seller_search:all_products')
        await redis_client.close()
        
        return {
            "status": "ok",
            "indexed_count": len(indexed_products),
            "has_index": len(indexed_products) > 0
        }
    except Exception as e:
        logger.error(f"Error checking index status: {e}")
        return {
            "status": "error",
            "indexed_count": 0,
            "has_index": False,
            "error": str(e)
        }

# ============================================
# ADDRESS MANAGEMENT ENDPOINTS
# ============================================

@app.post("/api/user/addresses")
async def add_address(request: Request, address_req: AddressRequest):
    """Add a new address for the user"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()
        
        # Get user data
        user_data_str = await redis_client.get(f"user:{email}")
        if not user_data_str:
            raise HTTPException(status_code=404, detail="User not found")
        
        user_data = json.loads(user_data_str)
        
        # Initialize addresses list if not present
        if 'addresses' not in user_data:
            user_data['addresses'] = []
        
        # Create address object
        address_id = f"addr_{len(user_data['addresses']) + 1}_{int(datetime.now().timestamp())}"
        address_obj = {
            "id": address_id,
            "label": address_req.label,
            "phone": address_req.phone,
            "street": address_req.street,
            "city": address_req.city,
            "state": address_req.state,
            "postal_code": address_req.postal_code,
            "country": address_req.country,
            "is_default": address_req.is_default,
            "created_at": datetime.now().isoformat()
        }
        
        # If setting as default, unset other defaults
        if address_req.is_default:
            for addr in user_data['addresses']:
                addr['is_default'] = False
        
        user_data['addresses'].append(address_obj)
        
        # Save updated user data
        await redis_client.set(f"user:{email}", json.dumps(user_data))
        await redis_client.close()
        
        logger.info(f"✅ Address added for user {email}: {address_id}")
        
        return {
            "success": True,
            "message": "Address added successfully",
            "address": address_obj
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error adding address: {e}")
        raise HTTPException(500, detail=str(e))

@app.get("/api/user/addresses")
async def get_user_addresses(request: Request):
    """Get all addresses for the user"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()
        
        # Get user data
        user_data_str = await redis_client.get(f"user:{email}")
        if not user_data_str:
            raise HTTPException(status_code=404, detail="User not found")
        
        user_data = json.loads(user_data_str)
        addresses = user_data.get('addresses', [])
        
        await redis_client.close()
        
        return {
            "success": True,
            "addresses": addresses
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching addresses: {e}")
        raise HTTPException(500, detail=str(e))

@app.put("/api/user/addresses/{address_id}")
async def update_address(request: Request, address_id: str, address_req: AddressRequest):
    """Update an existing address"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()
        
        # Get user data
        user_data_str = await redis_client.get(f"user:{email}")
        if not user_data_str:
            raise HTTPException(status_code=404, detail="User not found")
        
        user_data = json.loads(user_data_str)
        addresses = user_data.get('addresses', [])
        
        # Find and update address
        address_found = False
        for addr in addresses:
            if addr['id'] == address_id:
                addr['label'] = address_req.label
                addr['phone'] = address_req.phone
                addr['street'] = address_req.street
                addr['city'] = address_req.city
                addr['state'] = address_req.state
                addr['postal_code'] = address_req.postal_code
                addr['country'] = address_req.country
                addr['updated_at'] = datetime.now().isoformat()
                
                # Handle default address
                if address_req.is_default:
                    for other_addr in addresses:
                        other_addr['is_default'] = False
                    addr['is_default'] = True
                else:
                    addr['is_default'] = False
                
                address_found = True
                break
        
        if not address_found:
            raise HTTPException(status_code=404, detail="Address not found")
        
        user_data['addresses'] = addresses
        await redis_client.set(f"user:{email}", json.dumps(user_data))
        await redis_client.close()
        
        logger.info(f"✅ Address updated for user {email}: {address_id}")
        
        return {
            "success": True,
            "message": "Address updated successfully",
            "address": next((addr for addr in addresses if addr['id'] == address_id), None)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating address: {e}")
        raise HTTPException(500, detail=str(e))

@app.delete("/api/user/addresses/{address_id}")
async def delete_address(request: Request, address_id: str):
    """Delete an address"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()
        
        # Get user data
        user_data_str = await redis_client.get(f"user:{email}")
        if not user_data_str:
            raise HTTPException(status_code=404, detail="User not found")
        
        user_data = json.loads(user_data_str)
        addresses = user_data.get('addresses', [])
        
        # Find and delete address
        original_length = len(addresses)
        user_data['addresses'] = [addr for addr in addresses if addr['id'] != address_id]
        
        if len(user_data['addresses']) == original_length:
            raise HTTPException(status_code=404, detail="Address not found")
        
        await redis_client.set(f"user:{email}", json.dumps(user_data))
        await redis_client.close()
        
        logger.info(f"✅ Address deleted for user {email}: {address_id}")
        
        return {
            "success": True,
            "message": "Address deleted successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting address: {e}")
        raise HTTPException(500, detail=str(e))

# ============================================
# PAYMENT GATEWAY ENDPOINTS
# ============================================

@app.post("/api/payment/initiate")
async def initiate_payment(request: Request, payment_req: PaymentGatewayRequest):
    """Initiate payment gateway session for online payments"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()
        
        # Get order details
        order_manager_conn = await aioredis.Redis(
            host=REDIS_HOST,
            port=REDIS_PORT,
            db=4,  # Orders DB
            decode_responses=True
        )
        
        order_json = await order_manager_conn.get(payment_req.order_id)
        if not order_json:
            await order_manager_conn.close()
            raise HTTPException(status_code=404, detail="Order not found")
        
        order = json.loads(order_json)
        
        # Verify order belongs to user
        if order.get('user_id') != email:
            await order_manager_conn.close()
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Generate payment session
        payment_session = {
            "session_id": f"pay_{payment_req.order_id}_{int(datetime.now().timestamp())}",
            "order_id": payment_req.order_id,
            "user_id": email,
            "amount": payment_req.amount,
            "currency": "INR",
            "status": "initiated",
            "created_at": datetime.now().isoformat(),
            "payment_method": payment_req.payment_method
        }
        
        # Store payment session (expires in 30 minutes)
        await redis_client.setex(
            f"payment:{payment_session['session_id']}", 
            1800,  # 30 minutes
            json.dumps(payment_session)
        )
        
        # Update order payment status
        order['payment_status'] = 'initiated'
        await order_manager_conn.set(payment_req.order_id, json.dumps(order))
        
        await order_manager_conn.close()
        await redis_client.close()
        
        # In production, integrate with actual payment gateway (Razorpay, Stripe, etc.)
        # For now, return payment URL
        payment_url = f"/payment/{payment_session['session_id']}"
        
        logger.info(f"✅ Payment session initiated: {payment_session['session_id']}")
        
        return {
            "success": True,
            "message": "Payment session initiated",
            "session_id": payment_session['session_id'],
            "payment_url": payment_url,
            "amount": payment_req.amount,
            "order_id": payment_req.order_id
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error initiating payment: {e}")
        raise HTTPException(500, detail=str(e))

@app.get("/api/payment/status/{session_id}")
async def get_payment_status(request: Request, session_id: str):
    """Get payment session status"""
    try:
        email = await get_user_from_session(request)
        redis_client = await get_redis()
        
        payment_session_str = await redis_client.get(f"payment:{session_id}")
        if not payment_session_str:
            await redis_client.close()
            raise HTTPException(status_code=404, detail="Payment session not found")
        
        payment_session = json.loads(payment_session_str)
        
        # Verify user owns this payment session
        if payment_session.get('user_id') != email:
            await redis_client.close()
            raise HTTPException(status_code=403, detail="Access denied")
        
        await redis_client.close()
        
        return {
            "success": True,
            "session": payment_session
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting payment status: {e}")
        raise HTTPException(500, detail=str(e))

@app.post("/api/payment/confirm")
async def confirm_payment(request: Request):
    """Confirm payment (webhook from payment gateway)"""
    try:
        body = await request.json()
        session_id = body.get('session_id')
        transaction_id = body.get('transaction_id')
        status = body.get('status')  # success or failed
        
        if not session_id or not transaction_id:
            raise HTTPException(status_code=400, detail="Missing required fields")
        
        redis_client = await get_redis()
        
        payment_session_str = await redis_client.get(f"payment:{session_id}")
        if not payment_session_str:
            await redis_client.close()
            raise HTTPException(status_code=404, detail="Payment session not found")
        
        payment_session = json.loads(payment_session_str)
        order_id = payment_session.get('order_id')
        
        # Update order manager
        order_manager_conn = await aioredis.Redis(
            host=REDIS_HOST,
            port=REDIS_PORT,
            db=4,
            decode_responses=True
        )
        
        order_json = await order_manager_conn.get(order_id)
        if order_json:
            order = json.loads(order_json)
            
            if status == 'success':
                order['payment_status'] = 'completed'
                order['status'] = 'confirmed'
                order['transaction_id'] = transaction_id
            else:
                order['payment_status'] = 'failed'
                order['status'] = 'pending'
            
            await order_manager_conn.set(order_id, json.dumps(order))
        
        await order_manager_conn.close()
        await redis_client.close()
        
        logger.info(f"✅ Payment confirmed: {session_id} - {status}")
        
        return {
            "success": True,
            "message": f"Payment {status}",
            "order_id": order_id
        }
        
    except Exception as e:
        logger.error(f"Error confirming payment: {e}")
        raise HTTPException(500, detail=str(e))

# ============================================
# HEALTH CHECK
# ============================================

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        redis_client = await get_redis()
        await redis_client.ping()
        await redis_client.close()
        return {"status": "healthy", "redis": "connected"}
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return {"status": "unhealthy", "redis": "disconnected", "error": str(e)}

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='0.0.0.0', port=5000, log_level="info")
