"""
Automated Test Suite for Flask → FastAPI Transformation
Tests all 16 completed changes to verify implementation
"""

import asyncio
import sys
import os
from typing import Dict, List

# Test Results
test_results = {
    "passed": [],
    "failed": [],
    "warnings": []
}


def test_result(test_name: str, passed: bool, message: str = ""):
    """Record test result"""
    if passed:
        test_results["passed"].append(f"✅ {test_name}")
        print(f"✅ {test_name}")
    else:
        test_results["failed"].append(f"❌ {test_name}: {message}")
        print(f"❌ {test_name}: {message}")
    if message and passed:
        print(f"   {message}")


def test_warning(test_name: str, message: str):
    """Record warning"""
    test_results["warnings"].append(f"⚠️  {test_name}: {message}")
    print(f"⚠️  {test_name}: {message}")


# ============================================
# TEST 1: FastAPI Framework
# ============================================
def test_fastapi_import():
    """Test if FastAPI is used instead of Flask"""
    try:
        from api import app
        from fastapi import FastAPI
        
        is_fastapi = isinstance(app, FastAPI)
        test_result(
            "FastAPI Framework",
            is_fastapi,
            "Using FastAPI instead of Flask" if is_fastapi else "Still using Flask"
        )
        return is_fastapi
    except Exception as e:
        test_result("FastAPI Framework", False, str(e))
        return False


# ============================================
# TEST 2: Async Redis Client
# ============================================
def test_async_redis():
    """Test if redis.asyncio is imported"""
    try:
        with open('api.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        has_async_redis = 'redis.asyncio' in content or 'aioredis' in content
        no_sync_redis = 'import redis\n' not in content or 'redis.Redis(' not in content
        has_connection_pool = 'redis_pool' in content or 'max_connections' in content
        
        all_passed = has_async_redis and has_connection_pool
        
        test_result(
            "Async Redis Client",
            all_passed,
            "Using redis.asyncio with connection pooling" if all_passed else "Missing async Redis or pooling"
        )
        return all_passed
    except Exception as e:
        test_result("Async Redis Client", False, str(e))
        return False


# ============================================
# TEST 3: Direct Scraper Import (No Subprocess)
# ============================================
def test_no_subprocess():
    """Test if subprocess calls are removed"""
    try:
        with open('api.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        has_scraper_import = 'from scraper_module import' in content
        no_subprocess = 'subprocess.run' not in content and 'subprocess.Popen' not in content
        
        all_passed = has_scraper_import and no_subprocess
        
        test_result(
            "Direct Scraper Import",
            all_passed,
            "Using direct imports instead of subprocess" if all_passed else "Still using subprocess calls"
        )
        return all_passed
    except Exception as e:
        test_result("Direct Scraper Import", False, str(e))
        return False


# ============================================
# TEST 4: Scraper Module is Async
# ============================================
def test_async_scraper():
    """Test if scraper_module.py exists and uses async"""
    try:
        if not os.path.exists('scraper_module.py'):
            test_result("Async Scraper Module", False, "scraper_module.py not found")
            return False
        
        with open('scraper_module.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        has_async_functions = 'async def' in content
        uses_httpx = 'httpx' in content
        uses_async_redis = 'redis.asyncio' in content or 'aioredis' in content
        
        all_passed = has_async_functions and uses_httpx and uses_async_redis
        
        test_result(
            "Async Scraper Module",
            all_passed,
            "Scraper uses async/await with httpx" if all_passed else "Scraper not fully async"
        )
        return all_passed
    except Exception as e:
        test_result("Async Scraper Module", False, str(e))
        return False


# ============================================
# TEST 5: Rate Limiting
# ============================================
def test_rate_limiting():
    """Test if rate limiting is implemented"""
    try:
        if not os.path.exists('rate_limiter.py'):
            test_result("Rate Limiting", False, "rate_limiter.py not found")
            return False
        
        with open('api.py', 'r', encoding='utf-8') as f:
            api_content = f.read()
        
        with open('rate_limiter.py', 'r', encoding='utf-8') as f:
            limiter_content = f.read()
        
        has_middleware = 'RateLimitMiddleware' in api_content
        has_limiter_class = 'class RateLimitMiddleware' in limiter_content
        uses_redis = 'redis' in limiter_content.lower()
        
        all_passed = has_middleware and has_limiter_class and uses_redis
        
        test_result(
            "Rate Limiting",
            all_passed,
            "Redis-backed rate limiting implemented" if all_passed else "Rate limiting incomplete"
        )
        return all_passed
    except Exception as e:
        test_result("Rate Limiting", False, str(e))
        return False


# ============================================
# TEST 6: Pydantic Models
# ============================================
def test_pydantic_models():
    """Test if Pydantic models are used for validation"""
    try:
        with open('api.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        has_pydantic = 'from pydantic import' in content
        has_basemodel = 'BaseModel' in content
        has_emailstr = 'EmailStr' in content
        has_model_classes = 'class' in content and 'Request(BaseModel)' in content
        
        all_passed = has_pydantic and has_basemodel and has_model_classes
        
        test_result(
            "Pydantic Models",
            all_passed,
            "Using Pydantic for request validation" if all_passed else "Missing Pydantic models"
        )
        return all_passed
    except Exception as e:
        test_result("Pydantic Models", False, str(e))
        return False


# ============================================
# TEST 7: bcrypt Password Hashing
# ============================================
def test_bcrypt_hashing():
    """Test if bcrypt is used instead of SHA256"""
    try:
        with open('sign_up.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        uses_bcrypt = 'import bcrypt' in content
        has_hash_function = 'def hash_password' in content
        has_verify_function = 'def verify_password' in content
        no_hashlib = 'hashlib.sha256' not in content
        
        all_passed = uses_bcrypt and has_hash_function and has_verify_function and no_hashlib
        
        test_result(
            "bcrypt Password Hashing",
            all_passed,
            "Using bcrypt instead of SHA256" if all_passed else "Still using weak hashing"
        )
        return all_passed
    except Exception as e:
        test_result("bcrypt Password Hashing", False, str(e))
        return False


# ============================================
# TEST 8: Environment Variables
# ============================================
def test_environment_variables():
    """Test if environment variables are used"""
    try:
        with open('api.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        uses_dotenv = 'from dotenv import load_dotenv' in content or 'load_dotenv()' in content
        uses_os_getenv = 'os.getenv' in content
        has_env_example = os.path.exists('.env.example') or os.path.exists('../.env.example')
        
        all_passed = uses_dotenv and uses_os_getenv
        
        test_result(
            "Environment Variables",
            all_passed,
            "Using python-dotenv for configuration" if all_passed else "Missing environment variable support"
        )
        
        if not has_env_example:
            test_warning("Environment Variables", ".env.example file not found")
        
        return all_passed
    except Exception as e:
        test_result("Environment Variables", False, str(e))
        return False


# ============================================
# TEST 9: Structured Logging
# ============================================
def test_structured_logging():
    """Test if proper logging is implemented"""
    try:
        with open('api.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        imports_logging = 'import logging' in content
        has_logger = 'logger = logging.getLogger' in content
        uses_logger = 'logger.info' in content or 'logger.error' in content or 'logger.warning' in content
        no_print = content.count('print(') < 3  # Allow a few prints, but not many
        
        all_passed = imports_logging and has_logger and uses_logger
        
        test_result(
            "Structured Logging",
            all_passed,
            "Using Python logging module" if all_passed else "Missing proper logging"
        )
        return all_passed
    except Exception as e:
        test_result("Structured Logging", False, str(e))
        return False


# ============================================
# TEST 10: Health Check Endpoint
# ============================================
def test_health_check():
    """Test if health check endpoint exists"""
    try:
        with open('api.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        has_health_endpoint = '/health' in content
        has_redis_ping = 'ping()' in content
        
        all_passed = has_health_endpoint and has_redis_ping
        
        test_result(
            "Health Check Endpoint",
            all_passed,
            "Health check with Redis ping implemented" if all_passed else "Missing health check"
        )
        return all_passed
    except Exception as e:
        test_result("Health Check Endpoint", False, str(e))
        return False


# ============================================
# TEST 11: CORS Configuration
# ============================================
def test_cors_config():
    """Test if CORS is properly configured"""
    try:
        with open('api.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        has_cors_import = 'CORSMiddleware' in content
        has_cors_middleware = 'add_middleware' in content and 'CORSMiddleware' in content
        cors_configurable = 'CORS_ORIGINS' in content or 'cors_origins' in content
        
        all_passed = has_cors_import and has_cors_middleware
        
        test_result(
            "CORS Configuration",
            all_passed,
            "CORS properly configured" if all_passed else "Missing CORS configuration"
        )
        return all_passed
    except Exception as e:
        test_result("CORS Configuration", False, str(e))
        return False


# ============================================
# TEST 12: Docker Compose Backend Service
# ============================================
def test_docker_compose():
    """Test if Docker Compose has backend service"""
    try:
        if not os.path.exists('../docker-compose.yml'):
            test_result("Docker Compose Backend", False, "docker-compose.yml not found")
            return False
        
        with open('../docker-compose.yml', 'r', encoding='utf-8') as f:
            content = f.read()
        
        has_backend_service = 'backend:' in content
        has_depends_on = 'depends_on:' in content
        has_networks = 'networks:' in content
        uses_uvicorn = 'uvicorn' in content.lower() or os.path.exists('Dockerfile')
        
        all_passed = has_backend_service and has_depends_on
        
        test_result(
            "Docker Compose Backend",
            all_passed,
            "Backend service in docker-compose.yml" if all_passed else "Backend service missing"
        )
        return all_passed
    except Exception as e:
        test_result("Docker Compose Backend", False, str(e))
        return False


# ============================================
# TEST 13: Dockerfile Uses Uvicorn
# ============================================
def test_dockerfile_uvicorn():
    """Test if Dockerfile uses Uvicorn instead of Gunicorn"""
    try:
        if not os.path.exists('Dockerfile'):
            test_result("Dockerfile Uvicorn", False, "Dockerfile not found")
            return False
        
        with open('Dockerfile', 'r', encoding='utf-8') as f:
            content = f.read()
        
        uses_uvicorn = 'uvicorn' in content.lower()
        no_gunicorn = 'gunicorn' not in content.lower()
        
        all_passed = uses_uvicorn and no_gunicorn
        
        test_result(
            "Dockerfile Uvicorn",
            all_passed,
            "Using Uvicorn ASGI server" if all_passed else "Not using Uvicorn"
        )
        return all_passed
    except Exception as e:
        test_result("Dockerfile Uvicorn", False, str(e))
        return False


# ============================================
# TEST 14: API Documentation
# ============================================
def test_api_docs():
    """Test if FastAPI auto-documentation is enabled"""
    try:
        from api import app
        from fastapi import FastAPI
        
        if not isinstance(app, FastAPI):
            test_result("API Documentation", False, "Not using FastAPI")
            return False
        
        has_title = hasattr(app, 'title') and app.title
        has_version = hasattr(app, 'version') and app.version
        
        # Check if docs are not disabled
        docs_enabled = not (hasattr(app, 'docs_url') and app.docs_url is None)
        
        all_passed = has_title and has_version and docs_enabled
        
        test_result(
            "API Documentation",
            all_passed,
            f"Auto-generated docs at /docs and /redoc" if all_passed else "API docs not configured"
        )
        return all_passed
    except Exception as e:
        test_result("API Documentation", False, str(e))
        return False


# ============================================
# TEST 15: Codebase Organization
# ============================================
def test_codebase_organization():
    """Test if codebase is properly organized"""
    try:
        has_tools_dir = os.path.exists('tools') or os.path.exists('tools/')
        has_backup = os.path.exists('api_flask_backup.py')
        has_scraper_module = os.path.exists('scraper_module.py')
        has_rate_limiter = os.path.exists('rate_limiter.py')
        
        score = sum([has_tools_dir, has_backup, has_scraper_module, has_rate_limiter])
        all_passed = score >= 3
        
        test_result(
            "Codebase Organization",
            all_passed,
            f"Organized structure ({score}/4 components)" if all_passed else "Poor organization"
        )
        return all_passed
    except Exception as e:
        test_result("Codebase Organization", False, str(e))
        return False


# ============================================
# TEST 16: Dependencies in requirements.txt
# ============================================
def test_requirements():
    """Test if all required packages are in requirements.txt"""
    try:
        with open('requirements.txt', 'r', encoding='utf-8') as f:
            content = f.read().lower()
        
        required_packages = [
            'fastapi',
            'uvicorn',
            'redis',
            'httpx',
            'bcrypt',
            'python-dotenv',
            'pydantic',
            'email-validator'
        ]
        
        missing = [pkg for pkg in required_packages if pkg not in content]
        all_passed = len(missing) == 0
        
        test_result(
            "Requirements.txt",
            all_passed,
            "All required packages present" if all_passed else f"Missing: {', '.join(missing)}"
        )
        return all_passed
    except Exception as e:
        test_result("Requirements.txt", False, str(e))
        return False


# ============================================
# TEST 17: Async Function Definitions
# ============================================
def test_async_functions():
    """Test if main functions are async"""
    try:
        with open('api.py', 'r', encoding='utf-8') as f:
            content = f.read()
        
        async_def_count = content.count('async def')
        await_count = content.count('await ')
        
        has_async = async_def_count >= 5 and await_count >= 10
        
        test_result(
            "Async Functions",
            has_async,
            f"{async_def_count} async functions, {await_count} await calls" if has_async else "Not enough async/await usage"
        )
        return has_async
    except Exception as e:
        test_result("Async Functions", False, str(e))
        return False


# ============================================
# MAIN TEST RUNNER
# ============================================
def run_all_tests():
    """Run all transformation tests"""
    print("\n" + "="*60)
    print("🧪 TESTING FLASK → FASTAPI TRANSFORMATION")
    print("="*60 + "\n")
    
    print("📋 Running 17 automated tests...\n")
    
    # Run all tests
    tests = [
        test_fastapi_import,
        test_async_redis,
        test_no_subprocess,
        test_async_scraper,
        test_rate_limiting,
        test_pydantic_models,
        test_bcrypt_hashing,
        test_environment_variables,
        test_structured_logging,
        test_health_check,
        test_cors_config,
        test_docker_compose,
        test_dockerfile_uvicorn,
        test_api_docs,
        test_codebase_organization,
        test_requirements,
        test_async_functions
    ]
    
    for test in tests:
        try:
            test()
        except Exception as e:
            print(f"❌ Test crashed: {test.__name__} - {e}")
        print()
    
    # Print summary
    print("\n" + "="*60)
    print("📊 TEST SUMMARY")
    print("="*60 + "\n")
    
    passed_count = len(test_results["passed"])
    failed_count = len(test_results["failed"])
    warning_count = len(test_results["warnings"])
    total = passed_count + failed_count
    
    print(f"✅ Passed: {passed_count}/{total} ({passed_count/total*100:.1f}%)")
    print(f"❌ Failed: {failed_count}/{total}")
    print(f"⚠️  Warnings: {warning_count}")
    
    if test_results["failed"]:
        print("\n❌ Failed Tests:")
        for failure in test_results["failed"]:
            print(f"  {failure}")
    
    if test_results["warnings"]:
        print("\n⚠️  Warnings:")
        for warning in test_results["warnings"]:
            print(f"  {warning}")
    
    print("\n" + "="*60)
    
    if failed_count == 0:
        print("🎉 ALL TESTS PASSED! Transformation complete!")
    elif passed_count / total >= 0.8:
        print("✅ MOSTLY PASSED! Minor issues to address.")
    else:
        print("⚠️  SOME FAILURES! Review failed tests above.")
    
    print("="*60 + "\n")
    
    return failed_count == 0


if __name__ == "__main__":
    try:
        os.chdir(os.path.dirname(os.path.abspath(__file__)))
        success = run_all_tests()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n❌ Test suite crashed: {e}")
        sys.exit(1)
