import redis.asyncio as redis
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
import asyncio

logger = logging.getLogger(__name__)

class OrderManager:
    """Manages orders for seller products"""
    
    def __init__(self, redis_host: str = 'redis', redis_port: int = 6379):
        self.redis_host = redis_host
        self.redis_port = redis_port
        self.redis_client = None
        self.order_db = 4  # Separate database for orders
        
    async def connect(self):
        """Initialize Redis connection for orders"""
        try:
            self.redis_client = await redis.Redis(
                host=self.redis_host,
                port=self.redis_port,
                db=self.order_db,
                decode_responses=True
            )
            await self.redis_client.ping()
            logger.info("✅ Order manager connected to Redis")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            raise
    
    async def close(self):
        """Close Redis connection"""
        if self.redis_client:
            await self.redis_client.close()
            logger.info("Order manager Redis connection closed")
    
    async def create_order(
        self,
        user_id: str,
        user_name: str,
        user_email: str,
        phone: str,
        address: str,
        items: List[Dict[str, Any]],
        payment_method: str = "cod"
    ) -> Dict[str, Any]:
        """Create a new order"""
        try:
            # Generate order ID
            timestamp = int(datetime.now().timestamp() * 1000)
            order_id = f"order_{timestamp}_{user_id}"
            
            # Calculate total
            total_amount = sum(float(item.get('price', 0)) * int(item.get('quantity', 1)) for item in items)
            
            # Create order object
            order = {
                "order_id": order_id,
                "user_id": user_id,
                "user_name": user_name,
                "user_email": user_email,
                "phone": phone,
                "address": address,
                "items": items,
                "total_amount": total_amount,
                "order_date": datetime.now().isoformat(),
                "status": "pending",
                "payment_method": payment_method,
                "payment_status": "pending" if payment_method != "cod" else "cod"
            }
            
            # Store order
            await self.redis_client.set(order_id, json.dumps(order))
            
            # Add to user's order list
            await self.redis_client.sadd(f"user_orders:{user_id}", order_id)
            
            # Add to each seller's order list
            for item in items:
                seller_id = item.get('seller_id')
                if seller_id:
                    await self.redis_client.sadd(f"seller_orders:{seller_id}", order_id)
            
            # Add to all orders set
            await self.redis_client.sadd("all_orders", order_id)
            
            logger.info(f"✅ Order created: {order_id}")
            return order
            
        except Exception as e:
            logger.error(f"Error creating order: {e}")
            raise
    
    async def get_order(self, order_id: str) -> Optional[Dict[str, Any]]:
        """Get order by ID"""
        try:
            order_json = await self.redis_client.get(order_id)
            if order_json:
                return json.loads(order_json)
            return None
        except Exception as e:
            logger.error(f"Error getting order {order_id}: {e}")
            return None
    
    async def get_user_orders(self, user_id: str) -> List[Dict[str, Any]]:
        """Get all orders for a user"""
        try:
            order_ids = await self.redis_client.smembers(f"user_orders:{user_id}")
            orders = []
            
            for order_id in order_ids:
                order = await self.get_order(order_id)
                if order:
                    orders.append(order)
            
            # Sort by date (newest first)
            orders.sort(key=lambda x: x.get('order_date', ''), reverse=True)
            return orders
            
        except Exception as e:
            logger.error(f"Error getting user orders: {e}")
            return []
    
    async def get_seller_orders(self, seller_id: str) -> List[Dict[str, Any]]:
        """Get all orders for a seller"""
        try:
            order_ids = await self.redis_client.smembers(f"seller_orders:{seller_id}")
            orders = []
            
            for order_id in order_ids:
                order = await self.get_order(order_id)
                if order:
                    # Filter items to only include this seller's products
                    seller_items = [
                        item for item in order.get('items', [])
                        if item.get('seller_id') == seller_id
                    ]
                    
                    if seller_items:
                        # Create a copy with only seller's items
                        seller_order = order.copy()
                        seller_order['items'] = seller_items
                        seller_order['seller_total'] = sum(
                            float(item.get('price', 0)) * int(item.get('quantity', 1))
                            for item in seller_items
                        )
                        orders.append(seller_order)
            
            # Sort by date (newest first)
            orders.sort(key=lambda x: x.get('order_date', ''), reverse=True)
            return orders
            
        except Exception as e:
            logger.error(f"Error getting seller orders: {e}")
            return []
    
    async def update_order_status(
        self,
        order_id: str,
        status: str = None,
        seller_id: Optional[str] = None,
        seller_status: str = None,
        buyer_status: str = None
    ) -> bool:
        """
        Update order status
        seller_status: pending, confirmed, processing, shipped, delivered
        buyer_status: awaiting_delivery, received, completed
        """
        try:
            order = await self.get_order(order_id)
            if not order:
                return False
            
            # Legacy support: if status is provided, update overall status
            if status:
                order['status'] = status
            
            # Update seller status
            if seller_status:
                # Verify seller has items in this order
                if seller_id:
                    has_seller_items = any(
                        item.get('seller_id') == seller_id 
                        for item in order.get('items', [])
                    )
                    if not has_seller_items:
                        logger.warning(f"Seller {seller_id} not authorized for order {order_id}")
                        return False
                
                order['seller_status'] = seller_status
                
                # When seller marks as delivered, set delivery status
                if seller_status == 'delivered':
                    order['delivery_status'] = 'awaiting_buyer_confirmation'
            
            # Update buyer status
            if buyer_status:
                order['buyer_status'] = buyer_status
                
                # When buyer completes, mark entire order as completed
                if buyer_status == 'completed':
                    order['delivery_status'] = 'completed'
            
            order['updated_at'] = datetime.now().isoformat()
            
            # Save updated order
            await self.redis_client.set(order_id, json.dumps(order))
            logger.info(f"✅ Order {order_id} updated - seller_status: {seller_status}, buyer_status: {buyer_status}")
            return True
            
        except Exception as e:
            logger.error(f"Error updating order status: {e}")
            return False
    
    async def cancel_order(self, order_id: str, user_id: str) -> bool:
        """Cancel an order"""
        try:
            order = await self.get_order(order_id)
            if not order:
                return False
            
            # Verify user owns this order
            if order.get('user_id') != user_id:
                return False
            
            # Only allow cancellation if order is pending
            if order.get('status') not in ['pending', 'confirmed']:
                return False
            
            order['status'] = 'cancelled'
            order['cancelled_at'] = datetime.now().isoformat()
            
            await self.redis_client.set(order_id, json.dumps(order))
            logger.info(f"✅ Order {order_id} cancelled")
            return True
            
        except Exception as e:
            logger.error(f"Error cancelling order: {e}")
            return False

# Global instance
order_manager = OrderManager()
