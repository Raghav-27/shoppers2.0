# Automated test suite runner for Docker environment (Windows PowerShell)

Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host "🧪 RUNNING TESTS INSIDE DOCKER CONTAINER" -ForegroundColor Cyan
Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host ""

# Run tests inside the backend container
docker exec shoppers-backend-1 python test_transformations.py

$exitCode = $LASTEXITCODE

Write-Host ""
Write-Host "==============================================================" -ForegroundColor Cyan
if ($exitCode -eq 0) {
    Write-Host "✅ All tests passed in Docker environment!" -ForegroundColor Green
} else {
    Write-Host "⚠️  Some tests failed - see output above" -ForegroundColor Yellow
}
Write-Host "==============================================================" -ForegroundColor Cyan

exit $exitCode
