"""
Redis Database Connections Module
Manages separate Redis connections for each database (0-4)
"""
import redis.asyncio as aioredis
import os
from typing import Optional

REDIS_HOST = os.getenv('REDIS_HOST', 'redis')
REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))

# Connection pools for each database
redis_pools = {
    0: None,  # Sessions, rate limiting, scraped products cache
    1: None,  # Seller products
    2: None,  # Seller info
    3: None,  # Orders
    4: None,  # Analytics/reserved
}

async def get_redis(db: int = 0) -> aioredis.Redis:
    """
    Get async Redis connection for specific database
    
    Args:
        db: Database number (0-4)
    
    Returns:
        aioredis.Redis connection
    """
    if db not in redis_pools:
        raise ValueError(f"Invalid database number: {db}. Must be 0-4")
    
    if redis_pools[db] is None:
        redis_pools[db] = aioredis.ConnectionPool.from_url(
            f"redis://{REDIS_HOST}:{REDIS_PORT}/{db}",
            decode_responses=True,
            max_connections=50
        )
    
    return aioredis.Redis(connection_pool=redis_pools[db])

async def close_redis_pools():
    """Close all Redis connection pools"""
    for db, pool in redis_pools.items():
        if pool is not None:
            await pool.disconnect()
            redis_pools[db] = None

# Convenience functions for each database
async def get_redis_sessions() -> aioredis.Redis:
    """Get Redis DB 0 (sessions, rate limiting, cache)"""
    return await get_redis(db=0)

async def get_redis_products() -> aioredis.Redis:
    """Get Redis DB 1 (seller products)"""
    return await get_redis(db=1)

async def get_redis_sellers() -> aioredis.Redis:
    """Get Redis DB 2 (seller info)"""
    return await get_redis(db=2)

async def get_redis_orders() -> aioredis.Redis:
    """Get Redis DB 3 (orders)"""
    return await get_redis(db=3)

async def get_redis_analytics() -> aioredis.Redis:
    """Get Redis DB 4 (analytics/reserved)"""
    return await get_redis(db=4)
