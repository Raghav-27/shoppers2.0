# Redis Database Architecture Plan (DB 1-4 Schema)

## Overview
Keep DB 0 as-is (sessions, rate limiting, scraped product cache). Create specialized databases DB 1-4 for seller products, seller info, orders, and future expansion. Clean separation improves scalability, data isolation, and access patterns.

---

## What MUST Stay in DB 0 (Unchanged)

1. ✅ **Rate limiting data** - `ratelimit:*` (Sorted Sets)
2. ✅ **Session tokens** - `session:{token}` (Strings, 7-day expiry)
3. ✅ **User profiles** - `user:{user_id}` (Strings, JSON)
4. ✅ **User shopping state** - `user:{user_id}:lists` (Strings, JSON with wishlist/cart/compare)
5. ✅ **Scraped products cache** - `products:cache:{platform}:{query}:{page}` (Strings, JSON)
6. ✅ **Payment sessions** - `payment:session:{session_id}` (Strings, 30-min expiry)

---

## Database Schema (DB 1-4)

### Database 1: PRODUCTS (Seller Product Catalog)
**Purpose**: Fast seller product indexing and search
**Persistence**: No TTL (persistent)
**Access Pattern**: Query by seller_id, search by product name, auto-complete

**Key Patterns**:
```
seller:prod:{seller_id}:{product_id}         # Hash - product details
seller:prod:index:{query}                    # Sorted Set - ranked search results
seller:prod:all                              # Set - all product IDs (for cleanup/analytics)
seller:prod:search:{term}                    # Set - autocomplete/prefix matching
seller:prod:count:{seller_id}                # String - product count per seller
```

**Data Structure Example**:
```
seller:prod:123:456 = {
  name: "Running Shoes",
  category: "Footwear",
  price: 1299,
  stock: 45,
  description: "...",
  images: ["url1", "url2"],
  ratings: 4.5,
  seller_id: 123,
  created_at: "2026-01-10T10:00:00Z",
  is_active: 1
}
```

---

### Database 2: SELLERS (Seller Registry & Metadata)
**Purpose**: Seller accounts, store info, verification status
**Persistence**: No TTL (persistent)
**Access Pattern**: Query by seller_id or email, lookup by email, list all stores

**Key Patterns**:
```
seller:info:{seller_id}                      # Hash - seller profile/account
seller:stores:{seller_id}                    # Set - store IDs for this seller
seller:store:{store_id}                      # Hash - store details/address
seller:email:lookup                          # Hash - email → seller_id mapping
seller:rating:{seller_id}                    # Hash - ratings/reviews aggregate
seller:status:{seller_id}                    # String - active/inactive/suspended
seller:all                                   # Set - all seller IDs (analytics)
```

**Data Structure Example**:
```
seller:info:123 = {
  email: "john@example.com",
  business_name: "John's Store",
  phone: "+91-9876543210",
  gst_number: "18AABJU1234B1Z5",
  bank_account: "...",
  registration_date: "2025-06-15",
  verified: 1,
  verification_docs: "...",
  commission_rate: 5.0,
  total_orders: 240,
  lifetime_revenue: 125000
}

seller:store:456 = {
  store_name: "John's Main Store",
  address: "123 Market St, Mumbai",
  city: "Mumbai",
  state: "Maharashtra",
  pincode: "400001",
  phone: "+91-9876543210",
  email: "store@example.com",
  hours_open: "09:00",
  hours_close: "21:00",
  image_url: "...",
  created_at: "2025-06-15"
}
```

---

### Database 3: ORDERS (Order Lifecycle)
**Purpose**: Order management, user/seller order tracking, status filtering
**Persistence**: 365-day TTL (compliance/archival after 1 year)
**Access Pattern**: Query by order_id, list by user_id, list by seller_id, filter by status

**Key Patterns**:
```
order:{order_id}                             # Hash - complete order data
order:user:{user_id}                         # Set - order IDs for user
order:seller:{seller_id}                     # Set - order IDs for seller
order:status:{status}                        # Set - order IDs by status (pending/confirmed/shipped/delivered/cancelled)
order:created:{date}                         # Set - order IDs created on date (for daily reports)
order:counter                                # String - auto-increment order ID counter
order:all                                    # Set - all order IDs (analytics/cleanup)
```

**Data Structure Example**:
```
order:ORD-2026-001234 = {
  order_id: "ORD-2026-001234",
  user_id: 789,
  seller_id: 123,
  created_at: "2026-01-10T14:30:00Z",
  updated_at: "2026-01-10T14:30:00Z",
  status: "confirmed",
  items: [
    {
      product_id: 456,
      product_name: "Running Shoes",
      quantity: 2,
      price: 1299,
      subtotal: 2598
    }
  ],
  shipping_address: {
    name: "John Doe",
    address: "123 Main St",
    city: "Mumbai",
    pincode: "400001"
  },
  payment: {
    method: "card",
    status: "completed",
    amount: 2598,
    transaction_id: "TXN-123456"
  },
  tracking: {
    carrier: "FedEx",
    tracking_number: "1234567890",
    shipped_at: "2026-01-11T09:00:00Z",
    estimated_delivery: "2026-01-13T18:00:00Z"
  },
  notes: "Fragile item - handle with care"
}
```

---

### Database 4: ANALYTICS/RESERVED
**Purpose**: Reserved for future use
**Planned Use Cases**:
- Seller performance metrics (daily/monthly)
- Product analytics (views, clicks, conversions)
- Search trends and popular keywords
- Recommendation engine data
- User behavior analytics

---

## Implementation Steps

### Step 1: Update Docker Compose
- Add DB 1-4 to redis-commander environment (already supports multiple DBs)
- No changes needed to Redis service (already supports 16 DBs by default)

### Step 2: Refactor Backend API
- Create separate Redis client connections:
  ```python
  redis_db0 = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=0, decode_responses=True)  # Sessions
  redis_db1 = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=1, decode_responses=True)  # Products
  redis_db2 = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=2, decode_responses=True)  # Sellers
  redis_db3 = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=3, decode_responses=True)  # Orders
  ```
- Migrate all seller product operations from DB2 → DB1
- Migrate seller info operations from DB2 → DB2 (keep same DB)
- Migrate order operations from DB4 → DB3
- Add TTL policies to order operations (365 days)

### Step 3: Data Migration
- Backup existing Redis data
- Run migration script to move data from old location to new databases
- Verify data integrity across DBs
- Test search/query operations on new schema

### Step 4: Update API Endpoints
- `/api/seller/products` → Query DB1
- `/api/seller/profile` → Query DB2
- `/api/orders` → Query DB3
- `/api/search` → Query DB0 (scraped) + DB1 (seller) - aggregate results

### Step 5: Add Monitoring & Health Checks
- Monitor DB 1-4 connection pool
- Track key counts per database
- Alert on high memory usage per database
- Configure keyspace notifications for event-driven operations

---

## Further Considerations

### 1. Key Naming Consistency
**Question**: Should we prefix all keys with database context or keep implicit DB separation?

**Option A (Prefixed)**: `prod:seller:123:item:456`
- Pros: Clear without context
- Cons: Redundant prefix when DB is implicit

**Option B (Current Pattern)**: `seller:prod:123:456`
- Pros: Cleaner, shorter keys
- Cons: Needs documentation

**Recommendation**: Keep Option B - prefixes are implicit to database context

---

### 2. Cross-Database Search
**Question**: How should search span both seller products (DB1) and scraped products (DB0)?

**Option A (Sequential Query)**: Query DB0, then DB1, merge results
- Pros: Simple implementation
- Cons: Slower (network latency × 2)

**Option B (Aggregated Index)**: Maintain search index in DB0 that includes both
- Pros: Single query, faster
- Cons: Complexity, sync issues

**Recommendation**: Start with Option A, optimize to Option B if needed

---

### 3. Data Migration Strategy
**Question**: How to handle migration from old to new schema?

**Option A (Immediate)**: Stop service, migrate all data, restart
- Pros: Clean cutover
- Cons: Downtime required

**Option B (Dual-Write)**: Write to old + new locations during transition
- Pros: Zero downtime
- Cons: Complexity, temporary double storage

**Recommendation**: Use Option B for production; Option A for development

---

### 4. Persistence Configuration
**Question**: Which databases need RDB snapshots?

**Recommended**: Enable persistence for DB2 (Sellers) + DB3 (Orders)
- DB0: In-memory only (sessions/cache are ephemeral)
- DB1: In-memory only (can be rebuilt from scrapers + seller uploads)
- DB2: RDB snapshots every 15 minutes (critical - seller accounts)
- DB3: RDB snapshots every 10 minutes (critical - orders/payments)
- DB4: Reserved (TBD)

---

## Key Considerations Summary

| Aspect | Decision |
|--------|----------|
| **DB 0 Changes** | None - keep as-is |
| **Naming Convention** | Keep current pattern (implicit DB context) |
| **Search Strategy** | Sequential query (DB0 + DB1), optimize later if needed |
| **Migration Approach** | Dual-write strategy for zero downtime |
| **Persistence** | DB2 + DB3 with RDB snapshots every 10-15 minutes |
| **TTL Policy** | DB3 orders expire after 365 days |
| **Monitoring** | Health checks per database, keyspace notifications enabled |
| **Scaling** | Use connection pools (50 connections per DB), separate Redis instance for critical data (optional future) |

---

## Success Criteria

✅ All DB 0 keys remain unchanged and functional
✅ DB 1 products searchable in < 50ms
✅ DB 2 seller operations atomic and consistent
✅ DB 3 orders tracked and accessible by user/seller
✅ Migration completes with zero data loss
✅ Search aggregates results from both DB0 + DB1 correctly
✅ TTL policies enforce data retention correctly
✅ Monitoring alerts on connection/memory issues
