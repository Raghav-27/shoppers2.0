from flask import Flask, request, jsonify, make_response
from flask_cors import CORS
import redis
import json
import subprocess
import threading
import time
from sign_up import connect_to_redis, signup_user, login_user, validate_session, add_to_list, remove_from_list

app = Flask(__name__)
CORS(app, supports_credentials=True)  # Enable CORS with credentials support

def trigger_prefetch(query, sortorder):
    """Trigger prefetch in background thread"""
    def prefetch_task():
        try:
            print(f"🔄 Starting prefetch for query: {query}, sort: {sortorder}")
            subprocess.run(
                ["python", "meesho_scraper.py", query, sortorder, "--prefetch"],
                check=True,
                timeout=180  # 3 minutes timeout for prefetch
            )
            print(f"✅ Prefetch completed for query: {query}, sort: {sortorder}")
        except Exception as e:
            print(f"❌ Prefetch failed for query: {query}, sort: {sortorder}, error: {e}")
    
    # Run prefetch in background thread
    thread = threading.Thread(target=prefetch_task)
    thread.daemon = True
    thread.start()

def should_prefetch(total_products, requested_end_index):
    """Check if we should trigger prefetch based on remaining products"""
    if total_products <= 0:
        return False
    
    remaining_products = total_products - requested_end_index
    
    print(f"📊 Prefetch check: {remaining_products} remaining products")
    
    # Trigger prefetch if 30 or fewer products remain
    return remaining_products <= 30

def get_products_from_redis(query, sortorder="relevance", page=1, per_page=10):
    r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)
    key = f"meesho:{query}:{sortorder}:data"
    data_str = r.get(key)
    
    if not data_str:
        # Trigger meesho_scraper if data not found
        try:
            # Pass sort parameter directly to scraper
            subprocess.run(
                ["python", "meesho_scraper.py", query, sortorder],
                check=True,
                timeout=120
            )
            # Try to fetch again after scraping
            data_str = r.get(key)
            
        except Exception as e:
            print(f"Error running scraper: {e}")
            return [], 0
    
    if data_str:
        try:
            parsed = json.loads(data_str)
            all_products = parsed.get("products", [])
            total_products = len(all_products)
            
            # Calculate pagination
            start_idx = (page - 1) * per_page
            end_idx = start_idx + per_page
            paginated_products = all_products[start_idx:end_idx]
            
            # Check if we should trigger prefetch
            if should_prefetch(total_products, end_idx):
                print(f"🚀 Triggering prefetch for query: {query}, sort: {sortorder}")
                trigger_prefetch(query, sortorder)
            
            return paginated_products, total_products
        except Exception as e:
            print(f"Error parsing Redis data: {e}")
            return [], 0
    
    return [], 0

@app.route('/api/search', methods=['GET'])
def search():
    query = request.args.get('query', '').strip()
    sort = request.args.get('sort', 'relevance').strip()
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 10))
    
    if not query:
        return jsonify({
            'products': [], 
            'total': 0, 
            'page': page, 
            'per_page': per_page,
            'total_pages': 0,
            'prefetch_status': 'idle'
        })
    
    products, total_products = get_products_from_redis(query, sort, page, per_page)
    total_pages = (total_products + per_page - 1) // per_page  # Ceiling division
    
    # Calculate prefetch status
    start_idx = (page - 1) * per_page
    end_idx = start_idx + per_page
    remaining_products = total_products - end_idx
    remaining_percentage = (remaining_products / total_products * 100) if total_products > 0 else 0
    
    prefetch_status = 'idle'
    if remaining_products <= 30 and total_products > 0:
        prefetch_status = 'triggered'
    elif remaining_products <= 50 and total_products > 0:
        prefetch_status = 'warning'
    
    return jsonify({
        'products': products, 
        'total': total_products,
        'page': page,
        'per_page': per_page,
        'total_pages': total_pages,
        'remaining_products': remaining_products,
        'remaining_percentage': round(remaining_percentage, 1),
        'prefetch_status': prefetch_status
    })

# ---------------------------------------------
# AUTHENTICATION ENDPOINTS
# ---------------------------------------------

@app.route('/api/signup', methods=['POST'])
def signup():
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['first_name', 'last_name', 'email', 'phone', 'country', 'password']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Connect to Redis
        redis_client = connect_to_redis()
        if not redis_client:
            return jsonify({'error': 'Database connection failed'}), 500
        
        # Check if user already exists
        if redis_client.exists(f"user:{data['email']}"):
            return jsonify({'error': 'User already exists with this email'}), 409
        
        # Create user
        user_data = signup_user(
            redis_client,
            data['first_name'],
            data['last_name'], 
            data['email'],
            data['phone'],
            data['country'],
            data['password']
        )
        
        if user_data:
            # Remove password from response
            user_data.pop('password', None)
            return jsonify({
                'message': 'User registered successfully',
                'user': user_data
            }), 201
        else:
            return jsonify({'error': 'Failed to create user'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Email and password are required'}), 400
        
        # Connect to Redis
        redis_client = connect_to_redis()
        if not redis_client:
            return jsonify({'error': 'Database connection failed'}), 500
        
        # Attempt login
        token = login_user(redis_client, data['email'], data['password'])
        
        if token:
            # Get user profile data
            user_key = f"user:{data['email']}"
            user_data_str = redis_client.get(user_key)
            if user_data_str:
                user_data = json.loads(user_data_str)
                user_data.pop('password', None)  # Remove password from response
                
                # Create response with cookie
                response = make_response(jsonify({
                    'message': 'Login successful',
                    'token': token,
                    'user': user_data
                }))
                
                # Set secure HTTP cookie
                response.set_cookie(
                    'auth_token',
                    token,
                    max_age=60*60*24*7,  # 7 days
                    httponly=True,       # Prevent JavaScript access
                    secure=False,        # Set to True in production with HTTPS
                    samesite='Lax',      # CSRF protection
                    path='/'
                )
                
                return response, 200
            else:
                return jsonify({'error': 'User data not found'}), 404
        else:
            return jsonify({'error': 'Invalid email or password'}), 401
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/logout', methods=['POST'])
def logout():
    try:
        # Get token from cookie or request body
        token = request.cookies.get('auth_token')
        if not token:
            data = request.get_json() or {}
            token = data.get('token')
        
        if not token:
            return jsonify({'error': 'No active session found'}), 400
        
        # Connect to Redis
        redis_client = connect_to_redis()
        if not redis_client:
            return jsonify({'error': 'Database connection failed'}), 500
        
        # Delete session from Redis
        session_key = f"session:{token}"
        redis_client.delete(session_key)
        
        # Create response and clear cookie
        response = make_response(jsonify({'message': 'Logged out successfully'}))
        response.set_cookie(
            'auth_token',
            '',
            expires=0,
            httponly=True,
            secure=False,
            samesite='Lax',
            path='/'
        )
        
        return response, 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/validate-session', methods=['POST', 'GET'])
def validate_session_endpoint():
    try:
        # Get token from cookie first, then from request body
        token = request.cookies.get('auth_token')
        if not token:
            data = request.get_json() or {}
            token = data.get('token')
        
        if not token:
            return jsonify({'valid': False, 'error': 'No token provided'}), 401
        
        # Connect to Redis
        redis_client = connect_to_redis()
        if not redis_client:
            return jsonify({'error': 'Database connection failed'}), 500
        
        # Validate session
        session_data = validate_session(redis_client, token)
        
        if session_data:
            # Get user profile data
            user_key = f"user:{session_data['email']}"
            user_data_str = redis_client.get(user_key)
            if user_data_str:
                user_data = json.loads(user_data_str)
                user_data.pop('password', None)  # Remove password from response
                
                return jsonify({
                    'valid': True,
                    'user': user_data
                }), 200
            else:
                return jsonify({'error': 'User data not found'}), 404
        else:
            return jsonify({'valid': False}), 401
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/user/wishlist', methods=['POST', 'DELETE'])
def manage_wishlist():
    try:
        # Get token from cookie first, then from request body
        token = request.cookies.get('auth_token')
        if not token:
            data = request.get_json() or {}
            token = data.get('token')
        else:
            data = request.get_json() or {}
        
        product_id = data.get('product_id')
        
        if not token or not product_id:
            return jsonify({'error': 'Authentication and product_id are required'}), 400
        
        # Connect to Redis
        redis_client = connect_to_redis()
        if not redis_client:
            return jsonify({'error': 'Database connection failed'}), 500
        
        # Validate session and get user email
        session_data = validate_session(redis_client, token)
        if not session_data:
            return jsonify({'error': 'Invalid or expired session'}), 401
        
        email = session_data['email']
        
        if request.method == 'POST':
            add_to_list(redis_client, email, 'wishlist', product_id)
            return jsonify({'message': 'Product added to wishlist'}), 200
        else:  # DELETE
            remove_from_list(redis_client, email, 'wishlist', product_id)
            return jsonify({'message': 'Product removed from wishlist'}), 200
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/user/cart', methods=['POST', 'DELETE'])
def manage_cart():
    try:
        # Get token from cookie first, then from request body
        token = request.cookies.get('auth_token')
        if not token:
            data = request.get_json() or {}
            token = data.get('token')
        else:
            data = request.get_json() or {}
        
        product_id = data.get('product_id')
        
        if not token or not product_id:
            return jsonify({'error': 'Authentication and product_id are required'}), 400
        
        # Connect to Redis
        redis_client = connect_to_redis()
        if not redis_client:
            return jsonify({'error': 'Database connection failed'}), 500
        
        # Validate session and get user email
        session_data = validate_session(redis_client, token)
        if not session_data:
            return jsonify({'error': 'Invalid or expired session'}), 401
        
        email = session_data['email']
        
        if request.method == 'POST':
            add_to_list(redis_client, email, 'cart', product_id)
            return jsonify({'message': 'Product added to cart'}), 200
        else:  # DELETE
            remove_from_list(redis_client, email, 'cart', product_id)
            return jsonify({'message': 'Product removed from cart'}), 200
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/user/compare', methods=['POST', 'DELETE'])
def manage_compare():
    try:
        # Get token from cookie first, then from request body
        token = request.cookies.get('auth_token')
        if not token:
            data = request.get_json() or {}
            token = data.get('token')
        else:
            data = request.get_json() or {}
        
        product_id = data.get('product_id')
        
        if not token or not product_id:
            return jsonify({'error': 'Authentication and product_id are required'}), 400
        
        # Connect to Redis
        redis_client = connect_to_redis()
        if not redis_client:
            return jsonify({'error': 'Database connection failed'}), 500
        
        # Validate session and get user email
        session_data = validate_session(redis_client, token)
        if not session_data:
            return jsonify({'error': 'Invalid or expired session'}), 401
        
        email = session_data['email']
        
        if request.method == 'POST':
            add_to_list(redis_client, email, 'compare', product_id)
            return jsonify({'message': 'Product added to compare'}), 200
        else:  # DELETE
            remove_from_list(redis_client, email, 'compare', product_id)
            return jsonify({'message': 'Product removed from compare'}), 200
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/user/lists', methods=['GET'])
def get_user_lists():
    try:
        # Get token from cookie first, then from request args
        token = request.cookies.get('auth_token')
        if not token:
            token = request.args.get('token')
        
        if not token:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Connect to Redis
        redis_client = connect_to_redis()
        if not redis_client:
            return jsonify({'error': 'Database connection failed'}), 500
        
        # Validate session and get user email
        session_data = validate_session(redis_client, token)
        if not session_data:
            return jsonify({'error': 'Invalid or expired session'}), 401
        
        email = session_data['email']
        
        # Get user state data
        key_state = f"user:{email}:state"
        data = redis_client.get(key_state)
        
        if data:
            state = json.loads(data)
            return jsonify({
                'wishlist': state.get('wishlist', []),
                'cart': state.get('cart', []),
                'compare': state.get('compare', [])
            }), 200
        else:
            return jsonify({
                'wishlist': [],
                'cart': [],
                'compare': []
            }), 200
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)