"""
Sellers Manager (DB 2)
Handles seller accounts, stores, and metadata in Redis DB 2
"""
import redis.asyncio as aioredis
import json
from typing import Dict, Optional, List
import logging
from redis_db import get_redis_sellers

logger = logging.getLogger(__name__)

class SellersManager:
    """Manages seller accounts and stores in Redis DB 2"""
    
    def __init__(self, redis_db2: aioredis.Redis):
        self.redis = redis_db2
    
    async def create_seller(self, seller_data: Dict) -> Optional[int]:
        """
        Create new seller account
        
        Args:
            seller_data: Dict with email, business_name, phone, etc.
        
        Returns:
            Seller ID if successful, None otherwise
        """
        try:
            # Get next seller ID
            seller_id = await self.redis.incr("seller:id_counter")
            
            # Store seller info as hash
            key = f"seller:info:{seller_id}"
            seller_data['seller_id'] = seller_id
            seller_data['verified'] = 0  # Not verified by default
            seller_data['status'] = 'active'
            
            await self.redis.hset(key, mapping=seller_data)
            
            # Add email lookup mapping
            email = seller_data.get('email')
            if email:
                await self.redis.hset("seller:email:lookup", email, seller_id)
            
            # Add to all sellers set
            await self.redis.sadd("seller:all", seller_id)
            
            logger.info(f"Seller created: seller_id={seller_id}, email={email}")
            return seller_id
        except Exception as e:
            logger.error(f"Error creating seller: {e}")
            return None
    
    async def get_seller(self, seller_id: int) -> Optional[Dict]:
        """Get seller info"""
        try:
            key = f"seller:info:{seller_id}"
            seller = await self.redis.hgetall(key)
            return seller if seller else None
        except Exception as e:
            logger.error(f"Error getting seller: {e}")
            return None
    
    async def get_seller_by_email(self, email: str) -> Optional[Dict]:
        """Get seller info by email"""
        try:
            seller_id = await self.redis.hget("seller:email:lookup", email)
            if seller_id:
                return await self.get_seller(int(seller_id))
            return None
        except Exception as e:
            logger.error(f"Error getting seller by email: {e}")
            return None
    
    async def update_seller(self, seller_id: int, updates: Dict) -> bool:
        """Update seller info"""
        try:
            key = f"seller:info:{seller_id}"
            await self.redis.hset(key, mapping=updates)
            logger.info(f"Seller updated: seller_id={seller_id}")
            return True
        except Exception as e:
            logger.error(f"Error updating seller: {e}")
            return False
    
    async def create_store(self, seller_id: int, store_data: Dict) -> Optional[int]:
        """
        Create new store for seller
        
        Args:
            seller_id: Seller ID
            store_data: Store details dict
        
        Returns:
            Store ID if successful, None otherwise
        """
        try:
            # Get next store ID
            store_id = await self.redis.incr(f"seller:{seller_id}:store_id_counter")
            
            # Store store info as hash
            key = f"seller:store:{store_id}"
            store_data['store_id'] = store_id
            store_data['seller_id'] = seller_id
            
            await self.redis.hset(key, mapping=store_data)
            
            # Add to seller's stores set
            await self.redis.sadd(f"seller:{seller_id}:stores", store_id)
            
            logger.info(f"Store created: seller_id={seller_id}, store_id={store_id}")
            return store_id
        except Exception as e:
            logger.error(f"Error creating store: {e}")
            return None
    
    async def get_store(self, store_id: int) -> Optional[Dict]:
        """Get store details"""
        try:
            key = f"seller:store:{store_id}"
            store = await self.redis.hgetall(key)
            return store if store else None
        except Exception as e:
            logger.error(f"Error getting store: {e}")
            return None
    
    async def get_seller_stores(self, seller_id: int) -> List[Dict]:
        """Get all stores for seller"""
        try:
            store_ids = await self.redis.smembers(f"seller:{seller_id}:stores")
            stores = []
            
            for store_id in store_ids:
                store = await self.get_store(int(store_id))
                if store:
                    stores.append(store)
            
            return stores
        except Exception as e:
            logger.error(f"Error getting seller stores: {e}")
            return []
    
    async def update_store(self, store_id: int, updates: Dict) -> bool:
        """Update store info"""
        try:
            key = f"seller:store:{store_id}"
            await self.redis.hset(key, mapping=updates)
            logger.info(f"Store updated: store_id={store_id}")
            return True
        except Exception as e:
            logger.error(f"Error updating store: {e}")
            return False
    
    async def update_seller_rating(self, seller_id: int, rating_update: Dict) -> bool:
        """Update seller rating/review aggregate"""
        try:
            key = f"seller:rating:{seller_id}"
            await self.redis.hset(key, mapping=rating_update)
            return True
        except Exception as e:
            logger.error(f"Error updating seller rating: {e}")
            return False
    
    async def get_seller_stats(self, seller_id: int) -> Dict:
        """Get seller statistics"""
        try:
            seller = await self.get_seller(seller_id)
            rating = await self.redis.hgetall(f"seller:rating:{seller_id}")
            stores = await self.get_seller_stores(seller_id)
            
            return {
                'seller_id': seller_id,
                'business_name': seller.get('business_name') if seller else None,
                'rating': float(rating.get('average', 0)) if rating else 0,
                'total_orders': int(seller.get('total_orders', 0)) if seller else 0,
                'stores_count': len(stores),
                'verified': seller.get('verified') == '1' if seller else False
            }
        except Exception as e:
            logger.error(f"Error getting seller stats: {e}")
            return {}

# Singleton instance
_sellers_manager: Optional[SellersManager] = None

async def get_sellers_manager() -> SellersManager:
    """Get singleton sellers manager"""
    global _sellers_manager
    if _sellers_manager is None:
        redis_db2 = await get_redis_sellers()
        _sellers_manager = SellersManager(redis_db2)
    return _sellers_manager
