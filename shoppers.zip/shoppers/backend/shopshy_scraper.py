"""
Async Scraper Module
Provides async functions to be imported and called directly from the API
"""
import asyncio
import json
import httpx
import time
import random
import redis.asyncio as aioredis
import uuid
from urllib.parse import quote_plus
from typing import List, Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)

# ----------------------------------------
# CONFIG
# ----------------------------------------
MAX_PRODUCTS_PER_PAGE = 20
MAX_PAGES = 5
CONCURRENT_REQUESTS = 2
MAX_RETRIES = 3
RETRY_STATUS_CODES = [304, 429, 500, 502, 503, 504]

# Redis configuration
REDIS_HOST = 'redis'
REDIS_PORT = 6379

headers = {
    "accept": "application/json, text/plain, */*",
    "content-type": "application/json",
    "origin": "https://www.shopsy.in",
    "referer": "https://www.shopsy.in/",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
    "x-partner-context": '{"source":"reseller"}',
    "x-user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 FKUA/website/42/website/Desktop"
}

async def get_redis_client() -> aioredis.Redis:
    """Create async Redis client"""
    return await aioredis.from_url(
        f"redis://{REDIS_HOST}:{REDIS_PORT}/0",
        decode_responses=True
    )

def extract_products(data: dict, query: str, sort_name: str, page_number: int) -> List[Dict]:
    """Extract products from API response"""
    products = []
    try:
        for slot in data.get("RESPONSE", {}).get("slots", []):
            for widget in slot.get("widget", {}).get("data", {}).get("products", []):
                product_info = widget.get("productInfo", {}).get("value", {})
                product_id = product_info.get("ids", {}).get("productId", str(uuid.uuid4()))
                title = product_info.get("titles", {}).get("title", "No Name")
                price = product_info.get("pricing", {}).get("finalPrice", {}).get("value", 0)
                original_price = product_info.get("pricing", {}).get("price", {}).get("value", price)
                product_url = product_info.get("baseUrl", "")
                if product_url and not product_url.startswith("http"):
                    product_url = "https://www.shopsy.in" + product_url
                # Store all data from product_info
                product_data = product_info.copy()
                product_data["id"] = str(product_id)
                # Add calculated fields for convenience (optional, but preserves existing logic)
                discount_percent = 0
                if original_price and original_price > price:
                    discount_percent = round(((original_price - price) / original_price) * 100, 1)
                product_data["discount_percent"] = discount_percent
                product_data["product_url"] = product_url
                # Note: rating and num_ratings are already in product_info under "ratings"
                if product_data.get("id") and title:  # Minimal check using extracted title
                    products.append(product_data)
    except Exception as e:
        logger.error(f"Error parsing slots: {e}")
    
    # Debug: Check sorting (access nested price for full data)
    prices = [p.get("pricing", {}).get("finalPrice", {}).get("value", 0) for p in products]
    if sort_name == "price_asc" and prices != sorted(prices):
        logger.warning(f"Page {page_number}: Products are NOT sorted by price ascending!")
    elif sort_name == "price_desc" and prices != sorted(prices, reverse=True):
        logger.warning(f"Page {page_number}: Products are NOT sorted by price descending!")
    
    return products

async def fetch_page_with_retry(
    client: httpx.AsyncClient,
    page_number: int,
    query: str,
    api_sort: str
) -> Optional[dict]:
    """Fetch a page with retry logic"""
    sort_str = f'&sort={api_sort}' if api_sort != 'relevance' else '&sort=relevance'
    page_uri = f"/search?q={query}{sort_str}&page={page_number}"
    payload = {
        "pageUri": page_uri,
        "pageContext": {"fetchSeoData": True, "pageNumber": page_number},
        "trackingContext": {},
        "locationContext": {},
        "requestContext": {
            "type": "BROWSE_PAGE",
            "ssid": "testscript",
            "sqid": str(uuid.uuid4())
        }
    }
    
    logger.debug(f"Page {page_number}: Payload sent to Shopsy API: {payload}")
    
    url = "https://www.shopsy.in/2.rome/api/4/page/fetch?cacheFirst=false"

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = await client.post(url, json=payload, headers=headers)

            if response.status_code in RETRY_STATUS_CODES:
                wait_time = random.uniform(1, 2)
                logger.warning(f"Page {page_number}: Got {response.status_code}, waiting {wait_time:.2f}s (Retry {attempt}/{MAX_RETRIES})")
                await asyncio.sleep(wait_time)
                continue

            if response.status_code != 200:
                logger.error(f"Page {page_number}: HTTP {response.status_code}")
                return None

            try:
                data = response.json()
                return data
            except Exception as e:
                logger.error(f"Page {page_number}: JSON parse error ({e})")
                return None

        except httpx.RequestError as e:
            wait_time = random.uniform(1, 2)
            logger.warning(f"Page {page_number}: Network error ({e}) waiting {wait_time:.2f}s (Retry {attempt}/{MAX_RETRIES})")
            await asyncio.sleep(wait_time)

    logger.error(f"Page {page_number}: Failed after {MAX_RETRIES} retries")
    return None

async def fetch_pages_with_pagination(
    query: str,
    api_sort: str,
    max_pages: int = MAX_PAGES,
    start_page: int = 1
) -> List[Tuple[int, List[Dict]]]:
    """Fetch multiple pages with page-based pagination"""
    all_results = []

    async with httpx.AsyncClient(timeout=10, follow_redirects=True) as client:
        for page_number in range(start_page, start_page + max_pages):
            logger.info(f"🔄 Fetching page {page_number}...")
            
            data = await fetch_page_with_retry(client, page_number, query, api_sort)
            if not data:
                break

            products = extract_products(data, query, api_sort, page_number)
            if not products:
                logger.warning(f"Page {page_number}: No products found, stopping.")
                break

            all_results.append((page_number, products))
            sample_prices = [p.get('price', 0) for p in products[:10]]
            logger.info(f"✅ Page {page_number}: Found {len(products)} products | Sample prices: {sample_prices}")

    return all_results

async def store_in_redis(
    query: str,
    sort_order: Optional[str],
    products: List[Dict],
    page_number: int,
    cursor: Optional[str] = None
) -> bool:
    """Store scraped data in Redis"""
    try:
        redis_client = await get_redis_client()
        
        filter_name = 'relevance' if sort_order is None else sort_order
        redis_key = f'shopsy:{query}:{filter_name}:data'
        
        metadata = {
            "query": query,
            "sort_order": sort_order,
            "total_products": len(products),
            "scraped_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "scraped_timestamp": int(time.time()),
            "last_page_scraped": page_number,
            "cursor": cursor
        }
        
        redis_data = {
            "metadata": metadata,
            "products": products
        }
        
        await redis_client.set(redis_key, json.dumps(redis_data, ensure_ascii=False))
        logger.info(f"✅ Stored {len(products)} products in Redis with key: {redis_key}")
        
        await redis_client.close()
        return True
    except Exception as e:
        logger.error(f"❌ Failed to store data in Redis: {e}")
        return False

async def get_redis_metadata(query: str, sort_order: Optional[str]) -> Optional[Dict]:
    """Fetch metadata for a keyword from Redis"""
    try:
        redis_client = await get_redis_client()
        filter_name = 'relevance' if sort_order is None else sort_order
        redis_key = f'shopsy:{query}:{filter_name}:data'
        
        data = await redis_client.get(redis_key)
        await redis_client.close()
        
        if data:
            parsed_data = json.loads(data)
            return parsed_data.get("metadata", {})
    except Exception as e:
        logger.error(f"Error reading from Redis: {e}")
    return None

def get_api_sort(sort_order: Optional[str]) -> str:
    """Map input sort_order to API sort name"""
    if sort_order == 'asc':
        return 'price_asc'
    elif sort_order == 'desc':
        return 'price_desc'
    elif sort_order == 'popularity':
        return 'popularity'
    else:
        return 'relevance'

async def scrape_products(
    query: str,
    sort_order: Optional[str] = None,
    is_prefetch: bool = False
) -> Dict:
    """
    Main scraping function
    Returns: dict with status, total_products, and message
    """
    start_time = time.perf_counter()
    
    filter_name = 'relevance' if sort_order is None else sort_order
    metadata = await get_redis_metadata(query, sort_order)
    
    api_sort = get_api_sort(sort_order)
    
    if is_prefetch:
        logger.info("🔄 Prefetch mode activated")
        if metadata:
            start_page = metadata.get("last_page_scraped", 1) + 1
            logger.info(f"⏩ Resuming prefetch from page {start_page}")
            max_pages_to_fetch = 5
        else:
            logger.warning("⚠️ No existing data found for prefetch, starting from page 1")
            start_page = 1
            max_pages_to_fetch = 5
    else:
        if metadata:
            logger.info(f"🔎 Found previous scrape for '{query}' in Redis.")
            existing_products_count = metadata.get("total_products", 0)
            if existing_products_count < 20:
                start_page = metadata.get("last_page_scraped", 1) + 1
                logger.info(f"⏩ Resuming from page {start_page}")
            else:
                logger.info(f"✅ Found {existing_products_count} products in cache")
                return {
                    "status": "cached",
                    "total_products": existing_products_count,
                    "message": "Using cached data"
                }
        else:
            start_page = 1
        
        max_pages_to_fetch = MAX_PAGES

    # Fetch pages
    results = await fetch_pages_with_pagination(
        query, api_sort, max_pages_to_fetch, start_page=start_page
    )

    all_products = []
    global_seen = set()
    last_page_scraped = start_page - 1
    
    # Load existing products if prefetching or resuming
    load_existing = (is_prefetch and metadata) or (not is_prefetch and metadata and metadata.get("total_products", 0) < 20)
    if load_existing:
        try:
            redis_client = await get_redis_client()
            redis_key = f'shopsy:{query}:{filter_name}:data'
            existing_data = await redis_client.get(redis_key)
            await redis_client.close()
            
            if existing_data:
                existing_parsed = json.loads(existing_data)
                existing_products = existing_parsed.get("products", [])
                
                for product in existing_products:
                    pid = product.get('id')
                    if pid:
                        global_seen.add(pid)
                        all_products.append(product)
                
                logger.info(f"📦 Loaded {len(existing_products)} existing products from cache")
        except Exception as e:
            logger.warning(f"Could not load existing products: {e}")
    
    # Process new results
    for page_number, products in results:
        last_page_scraped = page_number
        for product in products:
            pid = product.get('id')
            if pid and pid not in global_seen:
                global_seen.add(pid)
                all_products.append(product)

    # Sort if needed (in-memory for price sorts; API handles popularity/relevance)
    if sort_order == 'asc':
        all_products.sort(key=lambda x: x.get('price', 0))
    elif sort_order == 'desc':
        all_products.sort(key=lambda x: x.get('price', 0), reverse=True)

    # Store in Redis
    if all_products:
        await store_in_redis(query, sort_order, all_products, last_page_scraped)

    elapsed = time.perf_counter() - start_time
    mode_text = "Prefetch" if is_prefetch else "Search"
    logger.info(f"✅ {mode_text} Query: {query} | Products: {len(all_products)} | Time: {elapsed:.2f}s")

    return {
        "status": "success",
        "total_products": len(all_products),
        "message": f"Scraped {len(all_products)} products in {elapsed:.2f}s"
    }