"""
Admin API - Separate FastAPI application for admin operations
Runs on port 5002
Handles user management, seller management, order viewing, and product management
"""
from fastapi import FastAPI, Request, Response, HTTPException, status, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, EmailStr
import redis.asyncio as aioredis
import json
import logging
from typing import Optional, List, Dict, Any
from datetime import datetime
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Import password hashing
import bcrypt
import secrets

# Import Redis DB manager
from redis_db import get_redis

# Import managers
from sellers_manager import SellersManager
from orders_manager import OrdersManager
from seller_products_manager import SellerProductsManager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Admin API", version="1.0.0")

# CORS Configuration
cors_origins = os.getenv('CORS_ORIGINS', 'http://localhost:3000,http://localhost:80').split(',')
app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Constants
SESSION_EXPIRY = 60 * 60 * 24 * 7  # 7 days

# Pydantic models
class AdminRegister(BaseModel):
    first_name: str
    last_name: str
    email: EmailStr
    password: str
    phone: str
    country: str = "India"

class AdminLogin(BaseModel):
    email: EmailStr
    password: str

class SellerStatusUpdate(BaseModel):
    status: str  # "active" or "inactive"

# ============================================================
# ADMIN AUTHENTICATION MIDDLEWARE
# ============================================================

async def verify_admin_session(request: Request) -> Dict[str, Any]:
    """
    Verify admin session from cookie
    Returns admin data if authenticated, raises HTTPException otherwise
    """
    token = request.cookies.get('admin_token')
    
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated"
        )
    
    # Get session from Redis DB 0
    redis = await get_redis(0)
    session_key = f"admin_session:{token}"
    session_data = await redis.get(session_key)
    
    if not session_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired session"
        )
    
    session = json.loads(session_data)
    admin_email = session.get('email')
    
    # Get admin data
    admin_key = f"admin:{admin_email}"
    admin_data = await redis.get(admin_key)
    
    if not admin_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Admin not found"
        )
    
    admin = json.loads(admin_data)
    
    return admin

# ============================================================
# AUTHENTICATION ENDPOINTS
# ============================================================

@app.post("/api/admin/register")
async def register_admin(admin_data: AdminRegister, response: Response):
    """
    Register a new admin account
    """
    try:
        redis = await get_redis(0)
        admin_key = f"admin:{admin_data.email}"
        
        # Check if admin already exists
        existing_admin = await redis.get(admin_key)
        if existing_admin:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Admin with this email already exists"
            )
        
        # Hash password
        hashed_password = bcrypt.hashpw(
            admin_data.password.encode('utf-8'),
            bcrypt.gensalt()
        ).decode('utf-8')
        
        # Create admin record
        admin_record = {
            "first_name": admin_data.first_name,
            "last_name": admin_data.last_name,
            "email": admin_data.email,
            "password": hashed_password,
            "phone": admin_data.phone,
            "country": admin_data.country,
            "created_at": datetime.now().isoformat(),
            "role": "admin"
        }
        
        # Store in Redis
        await redis.set(admin_key, json.dumps(admin_record))
        
        # Create session
        session_token = secrets.token_urlsafe(32)
        session_data = {
            "email": admin_data.email,
            "created_at": datetime.now().isoformat(),
            "role": "admin"
        }
        
        session_key = f"admin_session:{session_token}"
        await redis.setex(session_key, SESSION_EXPIRY, json.dumps(session_data))
        
        # Set cookie
        response.set_cookie(
            key="admin_token",
            value=session_token,
            httponly=True,
            max_age=SESSION_EXPIRY,
            samesite="lax",
            secure=False  # Set to True in production with HTTPS
        )
        
        logger.info(f"Admin registered successfully: {admin_data.email}")
        
        return {
            "message": "Admin registered successfully",
            "admin": {
                "email": admin_data.email,
                "first_name": admin_data.first_name,
                "last_name": admin_data.last_name
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in admin registration: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Registration failed: {str(e)}"
        )

@app.post("/api/admin/login")
async def login_admin(credentials: AdminLogin, response: Response):
    """
    Admin login endpoint
    """
    try:
        redis = await get_redis(0)
        admin_key = f"admin:{credentials.email}"
        
        # Get admin data
        admin_data = await redis.get(admin_key)
        if not admin_data:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password"
            )
        
        admin = json.loads(admin_data)
        
        # Verify password
        if not bcrypt.checkpw(
            credentials.password.encode('utf-8'),
            admin['password'].encode('utf-8')
        ):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid email or password"
            )
        
        # Create session
        session_token = secrets.token_urlsafe(32)
        session_data = {
            "email": credentials.email,
            "created_at": datetime.now().isoformat(),
            "role": "admin"
        }
        
        session_key = f"admin_session:{session_token}"
        await redis.setex(session_key, SESSION_EXPIRY, json.dumps(session_data))
        
        # Set cookie
        response.set_cookie(
            key="admin_token",
            value=session_token,
            httponly=True,
            max_age=SESSION_EXPIRY,
            samesite="lax",
            secure=False  # Set to True in production with HTTPS
        )
        
        logger.info(f"Admin logged in: {credentials.email}")
        
        return {
            "message": "Login successful",
            "admin": {
                "email": admin['email'],
                "first_name": admin['first_name'],
                "last_name": admin['last_name']
            }
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in admin login: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Login failed: {str(e)}"
        )

@app.post("/api/admin/logout")
async def logout_admin(request: Request, response: Response):
    """
    Admin logout endpoint
    """
    try:
        token = request.cookies.get('admin_token')
        
        if token:
            # Delete session from Redis
            redis = await get_redis(0)
            session_key = f"admin_session:{token}"
            await redis.delete(session_key)
        
        # Clear cookie
        response.delete_cookie(key="admin_token")
        
        return {"message": "Logged out successfully"}
    
    except Exception as e:
        logger.error(f"Error in admin logout: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Logout failed: {str(e)}"
        )

@app.get("/api/admin/session")
async def check_admin_session(admin: Dict = Depends(verify_admin_session)):
    """
    Check if admin session is valid
    Returns admin info if authenticated
    """
    return {
        "authenticated": True,
        "admin": {
            "email": admin['email'],
            "first_name": admin['first_name'],
            "last_name": admin['last_name'],
            "role": admin.get('role', 'admin')
        }
    }

# ============================================================
# HEALTH CHECK
# ============================================================

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "admin-api"}

# ============================================================
# USER MANAGEMENT ENDPOINTS
# ============================================================

@app.get("/api/admin/users")
async def get_all_users(
    request: Request,
    search: Optional[str] = None,
    offset: int = 0,
    limit: int = 50,
    admin: Dict = Depends(verify_admin_session)
):
    """
    Get all users with pagination and search
    Admin only endpoint
    """
    try:
        redis = await get_redis(0)
        users = []
        
        # Scan for all user keys (user:*)
        cursor = 0
        while True:
            cursor, keys = await redis.scan(cursor, match="user:*", count=100)
            
            for key in keys:
                # Skip session keys and state keys
                if ":state" in key or key.startswith("session:"):
                    continue
                
                user_data = await redis.get(key)
                if user_data:
                    try:
                        user = json.loads(user_data)
                        # Add email from key
                        user['email'] = key.replace('user:', '')
                        # Remove password from response
                        user.pop('password', None)
                        
                        # Apply search filter if provided
                        if search:
                            search_lower = search.lower()
                            if (search_lower in user.get('first_name', '').lower() or
                                search_lower in user.get('last_name', '').lower() or
                                search_lower in user.get('email', '').lower()):
                                users.append(user)
                        else:
                            users.append(user)
                    except json.JSONDecodeError:
                        continue
            
            if cursor == 0:
                break
        
        # Sort by created_at (newest first) - handle both timestamp (int) and ISO string formats
        def get_sort_timestamp(user):
            created = user.get('created_at', 0)
            # If it's already an integer timestamp, use it
            if isinstance(created, int):
                return created
            # If it's a string, try to parse it
            if isinstance(created, str):
                try:
                    from datetime import datetime
                    return int(datetime.fromisoformat(created.replace('Z', '+00:00')).timestamp())
                except:
                    return 0
            return 0
        
        users.sort(key=get_sort_timestamp, reverse=True)
        
        # Apply pagination
        total = len(users)
        paginated_users = users[offset:offset + limit]
        
        return {
            "users": paginated_users,
            "total": total,
            "offset": offset,
            "limit": limit
        }
        
    except Exception as e:
        logger.error(f"Error fetching users: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/admin/users/{email}")
async def get_user_details(
    email: str,
    request: Request,
    admin: Dict = Depends(verify_admin_session)
):
    """Get detailed information about a specific user"""
    try:
        redis = await get_redis(0)
        
        # Get user data
        user_key = f"user:{email}"
        user_data = await redis.get(user_key)
        
        if not user_data:
            raise HTTPException(status_code=404, detail="User not found")
        
        user = json.loads(user_data)
        user['email'] = email
        user.pop('password', None)
        
        # Get user state (wishlist, cart, compare)
        state_key = f"user:{email}:state"
        state_data = await redis.get(state_key)
        if state_data:
            state = json.loads(state_data)
            user['wishlist_count'] = len(state.get('wishlist', []))
            user['cart_count'] = len(state.get('cart', []))
            user['compare_count'] = len(state.get('compare', []))
        
        # Get user orders from DB 3
        orders_redis = await get_redis(3)
        order_keys = await orders_redis.smembers(f"order:user:{email}")
        user['total_orders'] = len(order_keys) if order_keys else 0
        
        return user
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching user details: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================
# SELLER MANAGEMENT ENDPOINTS
# ============================================================

@app.get("/api/admin/sellers")
async def get_all_sellers(
    request: Request,
    search: Optional[str] = None,
    status_filter: Optional[str] = None,
    offset: int = 0,
    limit: int = 50,
    admin: Dict = Depends(verify_admin_session)
):
    """
    Get all sellers with pagination, search, and status filtering
    Admin only endpoint
    """
    try:
        redis = await get_redis(2)
        sellers_manager = SellersManager(redis)
        
        sellers = []
        
        # Get all seller IDs from seller:all set
        seller_ids = await redis.smembers("seller:all")
        
        if not seller_ids:
            return {
                "sellers": [],
                "total": 0,
                "offset": offset,
                "limit": limit
            }
        
        # Fetch each seller's details
        for seller_id in seller_ids:
            seller_data = await sellers_manager.get_seller(int(seller_id))
            
            if seller_data:
                # Apply search filter
                if search:
                    search_lower = search.lower()
                    if not (search_lower in seller_data.get('business_name', '').lower() or
                            search_lower in seller_data.get('email', '').lower() or
                            search_lower in str(seller_data.get('seller_id', '')).lower()):
                        continue
                
                # Apply status filter
                if status_filter and seller_data.get('status') != status_filter:
                    continue
                
                # Get seller stats
                stats = await sellers_manager.get_seller_stats(int(seller_id))
                seller_data.update(stats)
                
                sellers.append(seller_data)
        
        # Sort by created_at (newest first)
        sellers.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        
        # Apply pagination
        total = len(sellers)
        paginated_sellers = sellers[offset:offset + limit]
        
        return {
            "sellers": paginated_sellers,
            "total": total,
            "offset": offset,
            "limit": limit
        }
        
    except Exception as e:
        logger.error(f"Error fetching sellers: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/admin/sellers/{seller_id}")
async def get_seller_details(
    seller_id: int,
    request: Request,
    admin: Dict = Depends(verify_admin_session)
):
    """Get detailed information about a specific seller"""
    try:
        redis_db2 = await get_redis(2)
        sellers_manager = SellersManager(redis_db2)
        
        seller = await sellers_manager.get_seller(seller_id)
        
        if not seller:
            raise HTTPException(status_code=404, detail="Seller not found")
        
        # Get seller stats
        stats = await sellers_manager.get_seller_stats(seller_id)
        seller.update(stats)
        
        # Get seller stores
        stores = await sellers_manager.get_seller_stores(seller_id)
        seller['stores'] = stores
        
        return seller
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching seller details: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.put("/api/admin/sellers/{seller_id}/freeze")
async def freeze_seller(
    seller_id: int,
    request: Request,
    admin: Dict = Depends(verify_admin_session)
):
    """
    Freeze a seller account (set status to 'inactive')
    Admin only endpoint
    """
    try:
        redis_db2 = await get_redis(2)
        sellers_manager = SellersManager(redis_db2)
        
        # Check if seller exists
        seller = await sellers_manager.get_seller(seller_id)
        if not seller:
            raise HTTPException(status_code=404, detail="Seller not found")
        
        # Update seller status to inactive
        success = await sellers_manager.update_seller(seller_id, {"status": "inactive"})
        
        if not success:
            raise HTTPException(status_code=500, detail="Failed to freeze seller")
        
        # Log admin action
        logger.info(f"Admin {admin['email']} froze seller {seller_id}")
        
        return {
            "success": True,
            "message": f"Seller {seller_id} has been frozen",
            "seller_id": seller_id,
            "status": "inactive"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error freezing seller: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.put("/api/admin/sellers/{seller_id}/unfreeze")
async def unfreeze_seller(
    seller_id: int,
    request: Request,
    admin: Dict = Depends(verify_admin_session)
):
    """
    Unfreeze a seller account (set status to 'active')
    Admin only endpoint
    """
    try:
        redis_db2 = await get_redis(2)
        sellers_manager = SellersManager(redis_db2)
        
        # Check if seller exists
        seller = await sellers_manager.get_seller(seller_id)
        if not seller:
            raise HTTPException(status_code=404, detail="Seller not found")
        
        # Update seller status to active
        success = await sellers_manager.update_seller(seller_id, {"status": "active"})
        
        if not success:
            raise HTTPException(status_code=500, detail="Failed to unfreeze seller")
        
        # Log admin action
        logger.info(f"Admin {admin['email']} unfroze seller {seller_id}")
        
        return {
            "success": True,
            "message": f"Seller {seller_id} has been unfrozen",
            "seller_id": seller_id,
            "status": "active"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error unfreezing seller: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================
# ORDER MANAGEMENT ENDPOINTS
# ============================================================

@app.get("/api/admin/orders")
async def get_all_orders(
    request: Request,
    search: Optional[str] = None,
    status_filter: Optional[str] = None,
    offset: int = 0,
    limit: int = 50,
    admin: Dict = Depends(verify_admin_session)
):
    """
    Get all orders with pagination, search, and status filtering
    Admin only endpoint
    """
    try:
        redis = await get_redis(3)
        orders_manager_instance = OrdersManager(redis)
        
        orders = []
        
        # Get all order IDs from order:all set
        order_ids = await redis.smembers("order:all")
        
        if not order_ids:
            return {
                "orders": [],
                "total": 0,
                "offset": offset,
                "limit": limit
            }
        
        # Fetch each order's details
        for order_id in order_ids:
            order_data = await orders_manager_instance.get_order(order_id)
            
            if order_data:
                # Apply search filter (by order_id, user_email, or phone)
                if search:
                    search_lower = search.lower()
                    if not (search_lower in order_data.get('order_id', '').lower() or
                            search_lower in order_data.get('user_email', '').lower() or
                            search_lower in order_data.get('phone', '').lower()):
                        continue
                
                # Apply status filter
                if status_filter and order_data.get('status') != status_filter:
                    continue
                
                orders.append(order_data)
        
        # Sort by order_date (newest first)
        orders.sort(key=lambda x: x.get('order_date', ''), reverse=True)
        
        # Apply pagination
        total = len(orders)
        paginated_orders = orders[offset:offset + limit]
        
        return {
            "orders": paginated_orders,
            "total": total,
            "offset": offset,
            "limit": limit
        }
        
    except Exception as e:
        logger.error(f"Error fetching orders: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/admin/orders/stats")
async def get_order_stats(
    request: Request,
    admin: Dict = Depends(verify_admin_session)
):
    """Get order statistics (counts by status)"""
    try:
        redis = await get_redis(3)
        
        stats = {
            "total": 0,
            "by_status": {}
        }
        
        # Get all order IDs
        order_ids = await redis.smembers("order:all")
        stats["total"] = len(order_ids) if order_ids else 0
        
        # Count by status
        statuses = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"]
        for order_status in statuses:
            status_orders = await redis.smembers(f"order:status:{order_status}")
            stats["by_status"][order_status] = len(status_orders) if status_orders else 0
        
        return stats
        
    except Exception as e:
        logger.error(f"Error fetching order stats: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================
# PRODUCT MANAGEMENT ENDPOINTS
# ============================================================

@app.get("/api/admin/products")
async def get_all_products(
    request: Request,
    search: Optional[str] = None,
    seller_id: Optional[int] = None,
    offset: int = 0,
    limit: int = 50,
    admin: Dict = Depends(verify_admin_session)
):
    """
    Get all seller products with pagination and search
    Admin only endpoint
    """
    try:
        redis = await get_redis(1)
        products_manager = SellerProductsManager(redis)
        
        products = []
        
        if seller_id:
            # Get products for specific seller
            product_ids = await redis.smembers(f"seller:prod:list:{seller_id}")
            
            for product_id in product_ids:
                product = await products_manager.get_product(seller_id, product_id)
                if product:
                    # Apply search filter
                    if search:
                        search_lower = search.lower()
                        if not (search_lower in product.get('name', '').lower() or
                                search_lower in product.get('description', '').lower()):
                            continue
                    products.append(product)
        else:
            # Get all products from all sellers
            all_products = await redis.smembers("seller:prod:all")
            
            for prod_key in all_products:
                # prod_key format: "seller_id:product_id"
                parts = prod_key.split(':')
                if len(parts) == 2:
                    s_id, p_id = parts
                    product = await products_manager.get_product(int(s_id), p_id)
                    
                    if product:
                        # Apply search filter
                        if search:
                            search_lower = search.lower()
                            if not (search_lower in product.get('name', '').lower() or
                                    search_lower in product.get('description', '').lower()):
                                continue
                        products.append(product)
        
        # Sort by created_at (newest first)
        products.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        
        # Apply pagination
        total = len(products)
        paginated_products = products[offset:offset + limit]
        
        return {
            "products": paginated_products,
            "total": total,
            "offset": offset,
            "limit": limit
        }
        
    except Exception as e:
        logger.error(f"Error fetching products: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================
# DASHBOARD STATS ENDPOINT
# ============================================================

@app.get("/api/admin/dashboard/stats")
async def get_dashboard_stats(
    request: Request,
    admin: Dict = Depends(verify_admin_session)
):
    """Get overview statistics for admin dashboard"""
    try:
        stats = {
            "users": {"total": 0, "admins": 0},
            "sellers": {"total": 0, "active": 0, "inactive": 0},
            "orders": {"total": 0, "pending": 0, "completed": 0},
            "products": {"total": 0}
        }
        
        # Count users (DB 0)
        redis_db0 = await get_redis(0)
        cursor = 0
        user_count = 0
        admin_count = 0
        
        while True:
            cursor, keys = await redis_db0.scan(cursor, match="user:*", count=100)
            for key in keys:
                if ":state" not in key and not key.startswith("session:"):
                    user_count += 1
                    user_data = await redis_db0.get(key)
                    if user_data:
                        user = json.loads(user_data)
                        if user.get('is_admin', False):
                            admin_count += 1
            if cursor == 0:
                break
        
        stats["users"]["total"] = user_count
        stats["users"]["admins"] = admin_count
        
        # Count sellers (DB 2)
        redis_db2 = await get_redis(2)
        seller_ids = await redis_db2.smembers("seller:all")
        stats["sellers"]["total"] = len(seller_ids) if seller_ids else 0
        
        sellers_manager = SellersManager(redis_db2)
        for seller_id in (seller_ids or []):
            seller = await sellers_manager.get_seller(int(seller_id))
            if seller:
                if seller.get('status') == 'active':
                    stats["sellers"]["active"] += 1
                else:
                    stats["sellers"]["inactive"] += 1
        
        # Count orders (DB 3)
        redis_db3 = await get_redis(3)
        order_ids = await redis_db3.smembers("order:all")
        stats["orders"]["total"] = len(order_ids) if order_ids else 0
        
        pending_orders = await redis_db3.smembers("order:status:pending")
        stats["orders"]["pending"] = len(pending_orders) if pending_orders else 0
        
        delivered_orders = await redis_db3.smembers("order:status:delivered")
        stats["orders"]["completed"] = len(delivered_orders) if delivered_orders else 0
        
        # Count products (DB 1)
        redis_db1 = await get_redis(1)
        all_products = await redis_db1.smembers("seller:prod:all")
        stats["products"]["total"] = len(all_products) if all_products else 0
        
        return stats
        
    except Exception as e:
        logger.error(f"Error fetching dashboard stats: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================
# STARTUP & SHUTDOWN
# ============================================================

@app.on_event("startup")
async def startup_event():
    """Initialize on startup"""
    logger.info("Admin API starting up...")
    logger.info("Admin API ready on port 5002")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    logger.info("Admin API shutting down...")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5002)
