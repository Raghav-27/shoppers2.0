"""
Orders Manager (DB 3)
Handles order lifecycle management in Redis DB 3
365-day TTL for compliance/archival
"""
import redis.asyncio as aioredis
import json
from typing import Dict, Optional, List, Set
from datetime import datetime, timedelta
import logging
from redis_db import get_redis_orders

logger = logging.getLogger(__name__)

# TTL for orders: 365 days
ORDER_TTL = 365 * 24 * 60 * 60

class OrdersManager:
    """Manages orders in Redis DB 3"""
    
    def __init__(self, redis_db3: aioredis.Redis):
        self.redis = redis_db3
        self.ttl = ORDER_TTL
    
    async def create_order(self, order_data: Dict) -> Optional[str]:
        """
        Create new order
        
        Args:
            order_data: Order details dict
        
        Returns:
            Order ID if successful, None otherwise
        """
        try:
            # Generate order ID
            counter = await self.redis.incr("order:counter")
            order_id = f"ORD-{datetime.now().year}-{str(counter).zfill(6)}"
            
            # Store order with TTL
            key = f"order:{order_id}"
            order_data['order_id'] = order_id
            order_data['created_at'] = datetime.now().isoformat()
            order_data['updated_at'] = datetime.now().isoformat()
            
            # Convert dict to JSON string for storage
            await self.redis.set(key, json.dumps(order_data), ex=self.ttl)
            
            # Add to user's orders
            user_id = order_data.get('user_id')
            if user_id:
                await self.redis.sadd(f"order:user:{user_id}", order_id, ex=self.ttl)
            
            # Add to seller's orders
            seller_id = order_data.get('seller_id')
            if seller_id:
                await self.redis.sadd(f"order:seller:{seller_id}", order_id, ex=self.ttl)
            
            # Add to status set
            status = order_data.get('status', 'pending')
            await self.redis.sadd(f"order:status:{status}", order_id, ex=self.ttl)
            
            # Add to all orders set
            await self.redis.sadd("order:all", order_id, ex=self.ttl)
            
            # Add to date-based set for daily reports
            date = datetime.now().strftime("%Y-%m-%d")
            await self.redis.sadd(f"order:created:{date}", order_id, ex=self.ttl)
            
            logger.info(f"Order created: order_id={order_id}, user_id={user_id}, seller_id={seller_id}")
            return order_id
        except Exception as e:
            logger.error(f"Error creating order: {e}")
            return None
    
    async def get_order(self, order_id: str) -> Optional[Dict]:
        """Get order details"""
        try:
            key = f"order:{order_id}"
            order_json = await self.redis.get(key)
            if order_json:
                return json.loads(order_json)
            return None
        except Exception as e:
            logger.error(f"Error getting order: {e}")
            return None
    
    async def update_order(self, order_id: str, updates: Dict) -> bool:
        """Update order details"""
        try:
            order = await self.get_order(order_id)
            if not order:
                logger.warning(f"Order not found: {order_id}")
                return False
            
            # Merge updates
            order.update(updates)
            order['updated_at'] = datetime.now().isoformat()
            
            # Update status if changed
            old_status = updates.get('status')
            new_status = order.get('status')
            if old_status and old_status != new_status:
                await self.redis.srem(f"order:status:{old_status}", order_id)
                await self.redis.sadd(f"order:status:{new_status}", order_id, ex=self.ttl)
            
            # Save updated order
            key = f"order:{order_id}"
            await self.redis.set(key, json.dumps(order), ex=self.ttl)
            
            logger.info(f"Order updated: order_id={order_id}")
            return True
        except Exception as e:
            logger.error(f"Error updating order: {e}")
            return False
    
    async def get_user_orders(self, user_id: int, status: Optional[str] = None) -> List[Dict]:
        """Get all orders for user"""
        try:
            order_ids = await self.redis.smembers(f"order:user:{user_id}")
            orders = []
            
            for order_id in order_ids:
                order = await self.get_order(order_id)
                if order:
                    if status is None or order.get('status') == status:
                        orders.append(order)
            
            # Sort by created_at descending
            orders.sort(key=lambda x: x.get('created_at', ''), reverse=True)
            return orders
        except Exception as e:
            logger.error(f"Error getting user orders: {e}")
            return []
    
    async def get_seller_orders(self, seller_id: int, status: Optional[str] = None) -> List[Dict]:
        """Get all orders for seller"""
        try:
            order_ids = await self.redis.smembers(f"order:seller:{seller_id}")
            orders = []
            
            for order_id in order_ids:
                order = await self.get_order(order_id)
                if order:
                    if status is None or order.get('status') == status:
                        orders.append(order)
            
            # Sort by created_at descending
            orders.sort(key=lambda x: x.get('created_at', ''), reverse=True)
            return orders
        except Exception as e:
            logger.error(f"Error getting seller orders: {e}")
            return []
    
    async def get_orders_by_status(self, status: str) -> List[Dict]:
        """Get all orders with specific status"""
        try:
            order_ids = await self.redis.smembers(f"order:status:{status}")
            orders = []
            
            for order_id in order_ids:
                order = await self.get_order(order_id)
                if order:
                    orders.append(order)
            
            return orders
        except Exception as e:
            logger.error(f"Error getting orders by status: {e}")
            return []
    
    async def update_order_status(self, order_id: str, new_status: str) -> bool:
        """Update order status"""
        try:
            order = await self.get_order(order_id)
            if not order:
                return False
            
            old_status = order.get('status', 'pending')
            
            # Remove from old status set
            await self.redis.srem(f"order:status:{old_status}", order_id)
            
            # Add to new status set
            await self.redis.sadd(f"order:status:{new_status}", order_id, ex=self.ttl)
            
            # Update order
            order['status'] = new_status
            order['updated_at'] = datetime.now().isoformat()
            
            key = f"order:{order_id}"
            await self.redis.set(key, json.dumps(order), ex=self.ttl)
            
            logger.info(f"Order status updated: order_id={order_id}, {old_status} → {new_status}")
            return True
        except Exception as e:
            logger.error(f"Error updating order status: {e}")
            return False
    
    async def get_daily_orders(self, date: str) -> List[Dict]:
        """Get all orders created on specific date (format: YYYY-MM-DD)"""
        try:
            order_ids = await self.redis.smembers(f"order:created:{date}")
            orders = []
            
            for order_id in order_ids:
                order = await self.get_order(order_id)
                if order:
                    orders.append(order)
            
            return orders
        except Exception as e:
            logger.error(f"Error getting daily orders: {e}")
            return []
    
    async def get_order_stats(self) -> Dict:
        """Get overall order statistics"""
        try:
            total = await self.redis.scard("order:all")
            pending = await self.redis.scard("order:status:pending")
            confirmed = await self.redis.scard("order:status:confirmed")
            shipped = await self.redis.scard("order:status:shipped")
            delivered = await self.redis.scard("order:status:delivered")
            cancelled = await self.redis.scard("order:status:cancelled")
            
            return {
                'total_orders': total,
                'pending': pending,
                'confirmed': confirmed,
                'shipped': shipped,
                'delivered': delivered,
                'cancelled': cancelled
            }
        except Exception as e:
            logger.error(f"Error getting order stats: {e}")
            return {}

# Singleton instance
_orders_manager: Optional[OrdersManager] = None

async def get_orders_manager() -> OrdersManager:
    """Get singleton orders manager"""
    global _orders_manager
    if _orders_manager is None:
        redis_db3 = await get_redis_orders()
        _orders_manager = OrdersManager(redis_db3)
    return _orders_manager
