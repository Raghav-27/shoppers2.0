#!/usr/bin/env python3
"""
Redis Data Viewer - View stored Meesho scraper data from Redis
"""
import redis
import json
import sys

REDIS_HOST = 'localhost'
REDIS_PORT = 6379
REDIS_KEY = 'meesho:keyword:filter:data'

def connect_to_redis():
    """Connect to Redis container."""
    try:
        r = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, decode_responses=True)
        r.ping()
        print(f"✅ Connected to Redis at {REDIS_HOST}:{REDIS_PORT}")
        return r
    except Exception as e:
        print(f"❌ Failed to connect to Redis: {e}")
        return None

def view_redis_data():
    """View the stored scraper data from Redis."""
    redis_client = connect_to_redis()
    if not redis_client:
        return
    
    try:
        # Get data from Redis
        data_str = redis_client.get(REDIS_KEY)
        if not data_str:
            print(f"❌ No data found for key: {REDIS_KEY}")
            return
        
        # Parse JSON data
        data = json.loads(data_str)
        metadata = data.get('metadata', {})
        products = data.get('products', [])
        
        # Display metadata
        print(f"\n📊 SCRAPER DATA SUMMARY")
        print(f"═" * 50)
        print(f"Query: {metadata.get('query', 'N/A')}")
        print(f"Sort Order: {metadata.get('sort_order', 'N/A')}")
        print(f"Total Products: {metadata.get('total_products', 0)}")
        print(f"Scraped At: {metadata.get('scraped_at', 'N/A')}")
        print(f"Redis Key: {REDIS_KEY}")
        
        # Display sample products
        print(f"\n📦 FIRST 5 PRODUCTS:")
        print(f"─" * 50)
        for i, product in enumerate(products[:5], 1):
            name = product.get('name', 'N/A')[:50]
            price = product.get('min_catalog_price', product.get('price', 0))
            pid = product.get('id', 'N/A')
            print(f"{i}. {name} - ₹{price} (ID: {pid})")
        
        if len(products) > 5:
            print(f"... and {len(products) - 5} more products")
            
        print(f"\n💾 Full data available in Redis key: {REDIS_KEY}")
        
    except Exception as e:
        print(f"❌ Error reading data from Redis: {e}")

def clear_redis_data():
    """Clear the stored scraper data from Redis."""
    redis_client = connect_to_redis()
    if not redis_client:
        return
    
    try:
        result = redis_client.delete(REDIS_KEY)
        if result:
            print(f"✅ Cleared data from Redis key: {REDIS_KEY}")
        else:
            print(f"⚠️ No data found to clear for key: {REDIS_KEY}")
    except Exception as e:
        print(f"❌ Error clearing data from Redis: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == 'clear':
        clear_redis_data()
    else:
        view_redis_data()
        print(f"\nUsage: python {sys.argv[0]} [clear]")
        print("  clear - Clear the stored data from Redis")