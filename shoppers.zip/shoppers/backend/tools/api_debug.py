import redis
import json

# Connect to Redis
r = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)

# Pattern to match product key
pattern = "meesho:books:relevance:data"

# Fetch matching keys
keys = r.keys(pattern)
print(f"Found {len(keys)} product keys.\n")

all_products = []

# Loop through and collect only product arrays
for key in keys:
    try:
        data = r.get(key)
        parsed = json.loads(data)

        # Extract only the 'products' array
        products = parsed.get("products", [])
        all_products.extend(products)

    except json.JSONDecodeError:
        print(f"⚠️ Skipping {key}: Invalid JSON format")

# Save only products to JSON file
output_file = "meesho_books_products.json"
with open(output_file, "w", encoding="utf-8") as f:
    json.dump(all_products, f, ensure_ascii=False, indent=2)

print(f"\n✅ Saved {len(all_products)} products to {output_file}")
