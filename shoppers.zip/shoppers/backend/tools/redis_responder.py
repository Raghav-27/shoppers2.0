from flask import Flask, request, jsonify
import redis

app = Flask(__name__)
r = redis.Redis(host='localhost', port=6379, db=0)

@app.route('/api/search')
def search():
    query = request.args.get('query')
    # Your logic to query Redis
    results = r.get(query)  # Example, adjust as needed
    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)