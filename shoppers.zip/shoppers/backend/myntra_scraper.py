"""
Myntra Async Scraper - HTML Parsing Version
Extracts product data from embedded JSON in HTML pages.
Structured like shopsy_scraper.py for API integration.
"""

import asyncio
import json
import httpx
import time
import random
import redis.asyncio as aioredis
import uuid
import re
from urllib.parse import quote_plus
from typing import List, Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)  # Enable console logging

# ----------------------------------------
# CONFIG
# ----------------------------------------
MAX_PRODUCTS_PER_PAGE = 40
MAX_PAGES = 5
MAX_RETRIES = 3
RETRY_STATUS_CODES = [429, 500, 502, 503, 504]

# Redis configuration
REDIS_HOST = 'redis'
REDIS_PORT = 6379

# Headers for fetching HTML pages (based on successful PowerShell request)
myntra_headers = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "en-US,en;q=0.9,hi;q=0.8",
    "DNT": "1",
    "Referer": "https://www.myntra.com/",
    "Sec-Ch-Ua": '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"Windows"',
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "same-origin",
    "Sec-Fetch-User": "?1",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"
}

# Cookies (expand as needed from browser)
myntra_cookies = {
    "_ga": "GA1.1.1992814237.1753163886",
    # Add more if required, e.g., session tokens
}

async def get_redis_client() -> aioredis.Redis:
    """Create async Redis client"""
    return await aioredis.from_url(
        f"redis://{REDIS_HOST}:{REDIS_PORT}/0",
        decode_responses=True
    )

def extract_json_from_html(html: str) -> Optional[dict]:
    """Extract window.__myx JSON object from HTML"""
    try:
        # Find the window.__myx object
        match = re.search(r'window\.__myx\s*=\s*(\{)', html)
        if not match:
            logger.error("Could not find window.__myx in HTML")
            return None
        
        start_pos = match.start(1)
        
        # Extract the JSON object by counting braces
        brace_count = 0
        in_string = False
        escape_next = False
        end_pos = start_pos
        
        for i in range(start_pos, len(html)):
            char = html[i]
            
            if escape_next:
                escape_next = False
                continue
            
            if char == '\\':
                escape_next = True
                continue
            
            if char == '"' and not escape_next:
                in_string = not in_string
            
            if not in_string:
                if char == '{':
                    brace_count += 1
                elif char == '}':
                    brace_count -= 1
                    if brace_count == 0:
                        end_pos = i + 1
                        break
        
        if end_pos > start_pos:
            json_str = html[start_pos:end_pos]
            data = json.loads(json_str)
            return data
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON parse error: {e}")
    except Exception as e:
        logger.error(f"Error extracting JSON: {e}")
    
    return None

def extract_products(data: dict, query: str, sort_name: str, page_number: int) -> List[Dict]:
    """Extract products from embedded JSON data"""
    products = []
    try:
        # Navigate to products in the structure
        search_data = data.get("searchData", {})
        results = search_data.get("results", {})
        raw_products = results.get("products", [])
        
        for p in raw_products:
            # Store full raw data
            product_data = p.copy()
            
            # Extract/calculate fields for convenience
            product_id = p.get("productId", str(uuid.uuid4()))
            title = p.get("productName") or p.get("product", "No Name")
            price = p.get("price", 0)
            mrp = p.get("mrp", price)
            image = p.get("searchImage", "")
            landing_url = p.get("landingPageUrl", "")
            product_url = f"https://www.myntra.com/{landing_url}" if landing_url else ""
            brand = p.get("brand", "")
            rating = p.get("rating", 0)
            rating_count = p.get("ratingCount", 0)
            
            discount_percent = 0
            if mrp > price:
                discount_percent = round(((mrp - price) / mrp) * 100, 1)
            
            product_data.update({
                "id": product_id,
                "title": title,
                "price": price,
                "original_price": mrp,
                "discount_percent": discount_percent,
                "product_url": product_url,
                "image": image,
                "brand": brand,
                "rating": rating,
                "rating_count": rating_count,
            })
            
            if product_data.get("id") and product_data.get("title"):
                products.append(product_data)
                
        logger.info(f"Extracted {len(products)} products from page {page_number}")
    except Exception as e:
        logger.error(f"Error parsing products: {e}")
    
    return products

async def fetch_page_with_retry(
    client: httpx.AsyncClient,
    page_number: int,
    query: str,
    api_sort: str,
    referer: str
) -> Optional[dict]:
    """Fetch a page and extract embedded JSON data with retry logic"""
    # Dynamic referer
    headers = myntra_headers.copy()
    headers["Referer"] = referer
    
    # Build URL - Myntra uses simple pagination with ?p= parameter
    url = f"https://www.myntra.com/{query}?p={page_number}"
    
    # Add sort parameter if needed
    if api_sort != "relevance":
        url += f"&sort={api_sort}"
    
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = await client.get(
                url, 
                headers=headers,
                timeout=30.0
            )

            if response.status_code in RETRY_STATUS_CODES:
                wait_time = random.uniform(1, 3) * attempt  # Backoff
                logger.warning(f"Page {page_number}: Status {response.status_code}, retry {attempt}/{MAX_RETRIES}, wait {wait_time:.2f}s")
                await asyncio.sleep(wait_time)
                continue

            if response.status_code != 200:
                logger.error(f"Page {page_number}: HTTP {response.status_code}")
                return None

            # Extract JSON from HTML
            html = response.text
            data = extract_json_from_html(html)
            
            if data:
                return data
            else:
                logger.error(f"Page {page_number}: Could not extract JSON from HTML")
                return None

        except httpx.RequestError as e:
            logger.warning(f"Page {page_number}: Network error {e}, retry {attempt}")
            await asyncio.sleep(random.uniform(1, 2))

    logger.error(f"Page {page_number}: Failed after {MAX_RETRIES} retries")
    return None

async def fetch_pages_with_pagination(
    query: str,
    api_sort: str,
    max_pages: int = MAX_PAGES,
    start_page: int = 1
) -> List[Tuple[int, List[Dict]]]:
    """Fetch multiple pages"""
    all_results = []
    base_referer = f"https://www.myntra.com/{query}"

    async with httpx.AsyncClient(follow_redirects=True) as client:
        for page_number in range(start_page, start_page + max_pages):
            logger.info(f"🔄 Fetching page {page_number}...")
            
            data = await fetch_page_with_retry(client, page_number, query, api_sort, base_referer)
            if not data:
                logger.warning(f"Page {page_number}: No data returned")
                break

            products = extract_products(data, query, api_sort, page_number)
            if not products:
                logger.warning(f"Page {page_number}: No products, stopping.")
                break

            all_results.append((page_number, products))
            sample_prices = [p.get('price', 0) for p in products[:5]]
            sample_titles = [p.get('title', '')[:30] for p in products[:3]]
            logger.info(f"✅ Page {page_number}: {len(products)} products | Sample prices: {sample_prices}")
            logger.info(f"   Sample titles: {sample_titles}")
            
            # Add delay between pages to avoid rate limiting
            if page_number < start_page + max_pages - 1:
                await asyncio.sleep(random.uniform(0.5, 1.5))

    return all_results

async def store_in_redis(
    query: str,
    sort_order: Optional[str],
    products: List[Dict],
    page_number: int,
    cursor: Optional[str] = None
) -> bool:
    """Store scraped data in Redis"""
    try:
        redis_client = await get_redis_client()
        
        filter_name = 'relevance' if sort_order is None else sort_order
        redis_key = f'myntra:{query}:{filter_name}:data'
        
        metadata = {
            "query": query,
            "sort_order": sort_order,
            "total_products": len(products),
            "scraped_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "scraped_timestamp": int(time.time()),
            "last_page_scraped": page_number,
            "cursor": cursor
        }
        
        redis_data = {
            "metadata": metadata,
            "products": products
        }
        
        await redis_client.set(redis_key, json.dumps(redis_data, ensure_ascii=False))
        logger.info(f"✅ Stored {len(products)} products in Redis: {redis_key}")
        
        await redis_client.close()
        return True
    except Exception as e:
        logger.error(f"❌ Redis store error: {e}")
        return False

async def get_redis_metadata(query: str, sort_order: Optional[str]) -> Optional[Dict]:
    """Fetch metadata from Redis"""
    try:
        redis_client = await get_redis_client()
        filter_name = 'relevance' if sort_order is None else sort_order
        redis_key = f'myntra:{query}:{filter_name}:data'
        
        data = await redis_client.get(redis_key)
        await redis_client.close()
        
        if data:
            parsed_data = json.loads(data)
            return parsed_data.get("metadata", {})
    except Exception as e:
        logger.error(f"Redis metadata error: {e}")
    return None

def get_api_sort(sort_order: Optional[str]) -> str:
    """Map sort_order to API sort"""
    mapping = {
        'asc': 'price_asc',
        'desc': 'price_desc',
        'popularity': 'popularity'
    }
    return mapping.get(sort_order, 'relevance')

async def scrape_products(
    query: str,
    sort_order: Optional[str] = None,
    is_prefetch: bool = False
) -> Dict:
    """
    Main scraping function
    """
    start_time = time.perf_counter()
    
    filter_name = 'relevance' if sort_order is None else sort_order
    metadata = await get_redis_metadata(query, sort_order)
    api_sort = get_api_sort(sort_order)
    
    if is_prefetch:
        logger.info("🔄 Prefetch mode")
        start_page = metadata.get("last_page_scraped", 0) + 1 if metadata else 1
        max_pages_to_fetch = 5
    else:
        if metadata:
            existing_count = metadata.get("total_products", 0)
            if existing_count >= 20:
                logger.info(f"✅ Cache hit: {existing_count} products")
                return {"status": "cached", "total_products": existing_count, "message": "Using cached data"}
            start_page = metadata.get("last_page_scraped", 0) + 1
        else:
            start_page = 1
        max_pages_to_fetch = MAX_PAGES

    # Fetch
    results = await fetch_pages_with_pagination(
        query, api_sort, max_pages_to_fetch, start_page
    )

    all_products = []
    global_seen = set()
    last_page_scraped = start_page - 1
    
    # Load existing for resume/prefetch
    if metadata and (existing_count := metadata.get("total_products", 0)) < 20 or is_prefetch:
        try:
            redis_client = await get_redis_client()
            redis_key = f'myntra:{query}:{filter_name}:data'
            existing_data = await redis_client.get(redis_key)
            await redis_client.close()
            if existing_data:
                existing_parsed = json.loads(existing_data)
                existing_products = existing_parsed.get("products", [])
                for product in existing_products:
                    pid = product.get('id')
                    if pid:
                        global_seen.add(pid)
                        all_products.append(product)
                logger.info(f"📦 Loaded {len(existing_products)} from cache")
        except Exception as e:
            logger.warning(f"Cache load error: {e}")

    # Add new
    for page_number, products in results:
        last_page_scraped = page_number
        for product in products:
            pid = product.get('id')
            if pid and pid not in global_seen:
                global_seen.add(pid)
                all_products.append(product)

    # In-memory sort fallback
    if sort_order == 'asc':
        all_products.sort(key=lambda x: x.get('price', 0))
    elif sort_order == 'desc':
        all_products.sort(key=lambda x: x.get('price', 0), reverse=True)

    # Store
    if all_products:
        await store_in_redis(query, sort_order, all_products, last_page_scraped)

    elapsed = time.perf_counter() - start_time
    mode_text = "Prefetch" if is_prefetch else "Search"
    logger.info(f"✅ {mode_text}: {query} | {len(all_products)} products | {elapsed:.2f}s")

    return {
        "status": "success",
        "total_products": len(all_products),
        "message": f"Scraped {len(all_products)} products in {elapsed:.2f}s"
    }

if __name__ == "__main__":
    query = input("Enter search query: ").strip()
    sort_input = input("Sort order (asc/desc/popularity, Enter for relevance): ").strip() or None
    asyncio.run(scrape_products(query, sort_input))

