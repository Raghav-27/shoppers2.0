"""
Async Flipkart Scraper Module
Provides async functions to be imported and called directly from the API
"""
import asyncio
import json
import httpx
import time
import random
import redis.asyncio as aioredis
import re
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)

# ----------------------------------------
# CONFIG
# ----------------------------------------
SITE_NAME = "flipkart"
MAX_PRODUCTS_PER_PAGE = 40  # Flipkart usually returns ~40 per page
MAX_PAGES = 5
CONCURRENT_REQUESTS = 5
MAX_RETRIES = 4
RETRY_STATUS_CODES = [406, 429, 500, 502, 503, 504]
COOKIE_REFRESH_MINUTES = 90

# Redis
REDIS_HOST = 'redis'
REDIS_PORT = 6379

# User agent
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/142.0.0.0 Safari/537.36"
)

# DC Endpoints
DC_ENDPOINTS = {
    "BLR": "https://1.rome.api.flipkart.com",
    "CHN": "https://3.rome.api.flipkart.com",
    "HYD": "https://2.rome.api.flipkart.com",
}

# ----------------------------------------
# COOKIE EXTRACTOR (Background Refresh)
# ----------------------------------------
class FlipkartCookieExtractor:
    def __init__(self):
        self.client = httpx.Client(timeout=20.0, headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "sec-ch-ua": '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
        })

    def extract(self) -> Dict[str, str]:
        cookies = {}
        try:
            r = self.client.get("https://www.flipkart.com")
            r.raise_for_status()
            cookies.update(self._parse_set_cookie(r))

            r = self.client.get("https://www.flipkart.com/search?q=laptop")
            r.raise_for_status()
            cookies.update(self._parse_set_cookie(r))

            body = r.text
            patterns = {
                r'SN["\']?\s*:\s*["\']([^"\']+)': "SN",
                r'at["\']?\s*:\s*["\']([^"\']+)': "at",
                r'vd["\']?\s*:\s*["\']([^"\']+)': "vd",
                r'T["\']?\s*:\s*["\']([^"\']+)': "T",
                r'S["\']?\s*:\s*["\']([^"\']+)': "S",
                r'K-ACTION["\']?\s*:\s*["\']([^"\']+)': "K-ACTION",
            }
            for pat, key in patterns.items():
                m = re.search(pat, body)
                if m:
                    cookies[key] = m.group(1)

            cookies.setdefault("K-ACTION", "null")
            cookies.setdefault("Network-Type", "4g")
            return cookies
        except Exception as e:
            logger.error(f"Cookie extraction failed: {e}")
            return {}
        finally:
            self.client.close()

    def _parse_set_cookie(self, resp: httpx.Response) -> Dict[str, str]:
        out = {}
        for h in resp.headers.getlist("Set-Cookie"):
            if "; " in h:
                name, val = h.split(";")[0].split("=", 1)
                out[name.strip()] = val.strip()
        return out


# Global client & cookie state
_client: Optional[httpx.AsyncClient] = None
_cookies: Dict[str, str] = {}
_last_cookie_refresh = datetime.min
_cookie_lock = asyncio.Lock()
_stop_refresh = asyncio.Event()


async def _ensure_client() -> httpx.AsyncClient:
    global _client
    if _client is None:
        _client = httpx.AsyncClient(
            timeout=30.0,
            limits=httpx.Limits(max_connections=200, max_keepalive_connections=50),
            headers={"User-Agent": USER_AGENT},
        )
        asyncio.create_task(_cookie_refresh_loop())
    return _client


async def _refresh_cookies(force: bool = False):
    global _cookies, _last_cookie_refresh
    now = datetime.now()
    if not force and now - _last_cookie_refresh < timedelta(minutes=COOKIE_REFRESH_MINUTES):
        return

    async with _cookie_lock:
        logger.info("Refreshing Flipkart cookies...")
        extractor = FlipkartCookieExtractor()
        new_cookies = extractor.extract()

        if not new_cookies:
            logger.warning("No cookies extracted")
            return

        client = await _ensure_client()
        client.cookies.clear()
        for k, v in new_cookies.items():
            client.cookies.set(k, v, domain=".flipkart.com")

        _cookies = new_cookies
        _last_cookie_refresh = now
        logger.info(f"Cookies refreshed ({len(new_cookies)})")


async def _cookie_refresh_loop():
    await _refresh_cookies(force=True)  # First run
    while not _stop_refresh.is_set():
        await asyncio.sleep(60)
        await _refresh_cookies()


# ----------------------------------------
# REDIS HELPERS
# ----------------------------------------
async def get_redis_client() -> aioredis.Redis:
    return await aioredis.from_url(
        f"redis://{REDIS_HOST}:{REDIS_PORT}/0",
        decode_responses=True
    )


# ----------------------------------------
# PRODUCT EXTRACTION
# ----------------------------------------
def extract_products(data: dict, query: str, filter_name: str, cursor: str, page_number: int) -> List[Dict]:
    products = []
    try:
        slots = data.get("RESPONSE", {}).get("slots", [])
        for slot in slots:
            widget = slot.get("widget", {})
            if widget.get("type") != "PRODUCT_SUMMARY":
                continue
            for p in widget.get("data", {}).get("products", []):
                v = p.get("productInfo", {}).get("value", {})
                
                # Extract complete product data
                product = {
                    "id": v.get("id"),
                    "name": v.get("titles", {}).get("title", ""),
                    "brand": v.get("titles", {}).get("superTitle", ""),
                    "subtitle": v.get("titles", {}).get("subtitle", ""),
                    "pricing": v.get("pricing", {}),
                    "rating": v.get("rating", {}),
                    "url": v.get("smartUrl", ""),
                    "media": v.get("media", {}),
                    "categoryPaths": v.get("categoryPaths", {}),
                    "highlights": v.get("highlights", []),
                    "tags": v.get("tags", {}),
                    "labels": v.get("labels", []),
                    "features": v.get("features", []),
                    "flags": v.get("flags", {}),
                    "attributes": v.get("attributes", {}),
                    "flipkartSpecialPrice": v.get("flipkartSpecialPrice", {}),
                    "sellerInfo": v.get("sellerInfo", {}),
                    "availabilityStatus": v.get("availabilityStatus", ""),
                    "stockStatus": v.get("stockStatus", {}),
                    "productBaseInfo": p.get("productBaseInfo", {}),
                    "raw_data": v  # Complete raw data for reference
                }
                
                if product.get("id") and product.get("name"):
                    products.append(product)
    except Exception as e:
        logger.warning(f"Error extracting products: {e}")
    return products


# ----------------------------------------
# PAGE FETCHER WITH RETRY + DC SWITCH
# ----------------------------------------
async def fetch_page_with_retry(
    client: httpx.AsyncClient,
    page_number: int,
    query: str,
    sort_order: Optional[str],
    cursor: Optional[str],
    search_session_id: str
) -> Tuple[Optional[dict], Optional[str]]:
    from urllib.parse import quote

    parts = [f"/search?q={quote(query)}"]
    if sort_order and sort_order != "relevance":
        parts.append(f"sort={sort_order}")
    parts.append(f"page={page_number}")
    page_uri = "&".join(parts)

    payload = {
        "pageUri": page_uri,
        "pageContext": {"fetchSeoData": True, "paginatedFetch": True, "pageNumber": page_number},
        "requestContext": {
            "type": "BROWSE_PAGE",
            "ssid": f"ps{int(time.time())}_{page_number}",
            "sqid": f"sq{int(time.time())}_{page_number}",
        },
    }

    headers = {
        "Accept": "*/*",
        "Origin": "https://www.flipkart.com",
        "Referer": "https://www.flipkart.com/",
        "X-User-Agent": f"{USER_AGENT} FKUA/website/42/website/Desktop",
        "Content-Type": "application/json",
    }

    current_dc = "BLR"
    url = f"{DC_ENDPOINTS[current_dc]}/api/4/page/fetch"

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = await client.post(url, json=payload, headers=headers)

            if response.status_code == 200:
                data = response.json()
                return data, None  # Flipkart uses page numbers, not cursor

            if response.status_code == 406:
                try:
                    err = response.json()
                    new_dc = err.get("META_INFO", {}).get("dcInfo", {}).get("dc")
                    if new_dc and new_dc in DC_ENDPOINTS and new_dc != current_dc:
                        logger.info(f"DC switch: {current_dc} to {new_dc}")
                        current_dc = new_dc
                        url = f"{DC_ENDPOINTS[current_dc]}/api/4/page/fetch"
                        continue
                except:
                    pass

            if response.status_code in RETRY_STATUS_CODES:
                wait = random.uniform(0.5, 1.5) * attempt
                logger.warning(f"Page {page_number}: {response.status_code}, retry {attempt}/{MAX_RETRIES} after {wait:.2f}s")
                await asyncio.sleep(wait)
                continue

            logger.error(f"Page {page_number}: HTTP {response.status_code}")
            return None, None

        except httpx.RequestError as e:
            wait = random.uniform(0.5, 1.5) * attempt
            logger.warning(f"Network error (attempt {attempt}): {e}, retry after {wait:.2f}s")
            await asyncio.sleep(wait)

    return None, None


# ----------------------------------------
# PAGINATION DRIVER
# ----------------------------------------
async def fetch_pages_with_cursor(
    query: str,
    sort_order: Optional[str],
    max_pages: int = MAX_PAGES,
    start_page: int = 1,
    start_cursor: Optional[str] = None
) -> Tuple[List[Tuple[int, List[Dict]]], Optional[str]]:
    all_results = []
    final_cursor = None
    search_session_id = f"ctx_1_uid_-1_txt_-1_t_{int(time.time() * 1000)}"

    client = await _ensure_client()
    sem = asyncio.Semaphore(CONCURRENT_REQUESTS)

    async def fetch_one(page: int):
        async with sem:
            return await fetch_page_with_retry(client, page, query, sort_order, None, search_session_id)

    tasks = [
        fetch_one(page_number)
        for page_number in range(start_page, start_page + max_pages)
    ]
    responses = await asyncio.gather(*tasks)

    for page_number, (data, cursor) in zip(range(start_page, start_page + max_pages), responses):
        if not data:
            break

        products = extract_products(data, query, sort_order or 'relevance', cursor, page_number)
        if not products:
            logger.warning(f"Page {page_number}: No products, stopping.")
            break

        all_results.append((page_number, products))
        prices = [p.get('price', 'N/A') for p in products[:5]]
        logger.info(f"Page {page_number}: {len(products)} products | Sample: {prices}")

    return all_results, final_cursor


# ----------------------------------------
# REDIS STORAGE
# ----------------------------------------
async def store_in_redis(
    query: str,
    sort_order: Optional[str],
    products: List[Dict],
    page_number: int,
    cursor: Optional[str]
) -> bool:
    try:
        redis_client = await get_redis_client()
        filter_name = 'relevance' if sort_order is None else sort_order
        redis_key = f'{SITE_NAME}:{query}:{filter_name}:data'

        metadata = {
            "query": query,
            "sort_order": sort_order,
            "total_products": len(products),
            "scraped_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "scraped_timestamp": int(time.time()),
            "last_page_scraped": page_number,
            "cursor": cursor
        }

        await redis_client.set(
            redis_key,
            json.dumps({"metadata": metadata, "products": products}, ensure_ascii=False)
        )
        logger.info(f"Stored {len(products)} products in Redis → {redis_key}")
        await redis_client.close()
        return True
    except Exception as e:
        logger.error(f"Redis store failed: {e}")
        return False


async def get_redis_metadata(query: str, sort_order: Optional[str]) -> Optional[Dict]:
    try:
        redis_client = await get_redis_client()
        filter_name = 'relevance' if sort_order is None else sort_order
        key = f'{SITE_NAME}:{query}:{filter_name}:data'
        data = await redis_client.get(key)
        await redis_client.close()
        return json.loads(data).get("metadata", {}) if data else None
    except Exception as e:
        logger.error(f"Redis read error: {e}")
        return None


# ----------------------------------------
# MAIN SCRAPER FUNCTION
# ----------------------------------------
async def scrape_products(
    query: str,
    sort_order: Optional[str] = None,
    is_prefetch: bool = False
) -> Dict:
    start_time = time.perf_counter()
    filter_name = 'relevance' if sort_order is None else sort_order
    metadata = await get_redis_metadata(query, sort_order)

    # === Determine start page ===
    if is_prefetch:
        start_page = metadata.get("last_page_scraped", 1) + 1 if metadata else 1
        max_pages_to_fetch = 5
        logger.info(f"Prefetch mode: resuming from page {start_page}")
    else:
        if metadata and metadata.get("total_products", 0) >= 20:
            logger.info(f"Cache hit: {metadata['total_products']} products")
            return {
                "status": "cached",
                "total_products": metadata["total_products"],
                "message": "Using cached data"
            }
        start_page = metadata.get("last_page_scraped", 1) + 1 if metadata and metadata.get("total_products", 0) < 20 else 1
        max_pages_to_fetch = MAX_PAGES

    # === Fetch new pages ===
    results, final_cursor = await fetch_pages_with_cursor(
        query, sort_order, max_pages_to_fetch, start_page
    )

    # === Load existing + deduplicate ===
    all_products = []
    seen = set()

    if metadata:
        try:
            redis_client = await get_redis_client()
            key = f'{SITE_NAME}:{query}:{filter_name}:data'
            cached = await redis_client.get(key)
            await redis_client.close()
            if cached:
                existing = json.loads(cached).get("products", [])
                for p in existing:
                    pid = p.get("id")
                    if pid and pid not in seen:
                        seen.add(pid)
                        all_products.append(p)
                logger.info(f"Loaded {len(existing)} cached products")
        except Exception as e:
            logger.warning(f"Failed to load cache: {e}")

    last_page = start_page - 1
    for page_number, products in results:
        last_page = page_number
        for p in products:
            pid = p.get("id")
            if pid and pid not in seen:
                seen.add(pid)
                all_products.append(p)

    # === Sort if needed ===
    def price_value(p):
        try:
            return int(p.get("price", "₹0").replace("₹", "").replace(",", ""))
        except:
            return 0

    if sort_order == "asc":
        all_products.sort(key=price_value)
    elif sort_order == "desc":
        all_products.sort(key=price_value, reverse=True)

    # === Save ===
    if all_products:
        await store_in_redis(query, sort_order, all_products, last_page, final_cursor)

    elapsed = time.perf_counter() - start_time
    mode = "Prefetch" if is_prefetch else "Search"
    logger.info(f"{mode} '{query}' to {len(all_products)} products in {elapsed:.2f}s")

    return {
        "status": "success",
        "total_products": len(all_products),
        "message": f"Scraped {len(all_products)} products in {elapsed:.2f}s"
    }


# ----------------------------------------
# CLEANUP
# ----------------------------------------
async def close_scraper():
    global _client
    _stop_refresh.set()
    if _client:
        await _client.aclose()
        _client = None
    logger.info("Flipkart scraper client closed")