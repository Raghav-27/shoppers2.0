"""
Async Scraper Module
Provides async functions to be imported and called directly from the API
"""
import asyncio
import json
import httpx
import time
import random
import redis.asyncio as aioredis
from urllib.parse import quote_plus
from typing import List, Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)

# ----------------------------------------
# CONFIG
# ----------------------------------------
MAX_PRODUCTS_PER_PAGE = 20
MAX_PAGES = 5
CONCURRENT_REQUESTS = 2
MAX_RETRIES = 3
RETRY_STATUS_CODES = [304, 429, 500, 502, 503, 504]

# Redis configuration
REDIS_HOST = 'redis'
REDIS_PORT = 6379

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.5",
    "Content-Type": "application/json",
    "Origin": "https://www.meesho.com",
    "Referer": "https://www.meesho.com/search?q=shoes&searchType=manual&searchIdentifier=text_search",
    "Connection": "keep-alive",
    "sec-ch-ua": '"Brave";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "sec-gpc": "1",
    "meesho-iso-country-code": "IN"
}

async def get_redis_client() -> aioredis.Redis:
    """Create async Redis client"""
    return await aioredis.from_url(
        f"redis://{REDIS_HOST}:{REDIS_PORT}/0",
        decode_responses=True
    )

def extract_products(data: dict, query: str, filter_name: str, cursor: str, page_number: int) -> List[Dict]:
    """Extract products from API response"""
    products = []
    try:
        catalogs = data.get("catalogs", [])
        for catalog in catalogs:
            try:
                product_data = {
                    "id": catalog.get("id"),
                    "hero_pid": catalog.get("hero_pid"),
                    "name": catalog.get("name", ""),
                    "category_id": catalog.get("category_id"),
                    "sub_sub_category_name": catalog.get("sub_sub_category_name", ""),
                    "min_catalog_price": catalog.get("min_catalog_price", 0),
                    "min_product_price": catalog.get("min_product_price", 0),
                    "description": catalog.get("description", ""),
                    "full_details": catalog.get("full_details", ""),
                    "share_text": catalog.get("share_text", ""),
                    "hot": catalog.get("hot", False),
                    "type": catalog.get("type", ""),
                    "pre_booking": catalog.get("pre_booking", False),
                    "priority": catalog.get("priority", 0),
                    "num_suppliers": catalog.get("num_suppliers", 0),
                    "num_designs": catalog.get("num_designs", 0),
                    "image": catalog.get("image", ""),
                    "collage_image": catalog.get("collage_image", ""),
                    "image_aspect_ratio": catalog.get("image_aspect_ratio"),
                    "collage_image_aspect_ratio": catalog.get("collage_image_aspect_ratio"),
                    "created": catalog.get("created", ""),
                    "created_iso": catalog.get("created_iso", ""),
                    "valid": catalog.get("valid", True),
                    "trend": catalog.get("trend", ""),
                    "popular": catalog.get("popular", False),
                    "has_mrp": catalog.get("has_mrp", False),
                    "is_added_to_wishlist": catalog.get("is_added_to_wishlist", False),
                    "assured_details": catalog.get("assured_details", {}),
                    "mall_verified": catalog.get("mall_verified", False),
                    "shipping_charges_adjustment": catalog.get("shipping_charges_adjustment", 0),
                    "story_images": catalog.get("story_images", []),
                    "catalog_reviews_summary": catalog.get("catalog_reviews_summary", {}),
                    "shipping": catalog.get("shipping", {}),
                    "shipping_2": catalog.get("shipping_2", {}),
                    "tags": catalog.get("tags", []),
                    "gray_tags": catalog.get("gray_tags", []),
                    "value_prop_tag": catalog.get("value_prop_tag", {}),
                    "has_same_price_products": catalog.get("has_same_price_products", False),
                    "product_images": catalog.get("product_images", []),
                    "images": catalog.get("images", []),
                    "product_id": catalog.get("product_id", ""),
                    "slug": catalog.get("slug", ""),
                    "original_slug": catalog.get("original_slug", ""),
                    "isAdProduct": catalog.get("isAdProduct", False),
                    "product_attributes": catalog.get("product_attributes", []),
                    "original_product_id": catalog.get("original_product_id"),
                    "catalogId": catalog.get("catalogId")
                }
                
                if product_data.get("id") and product_data.get("name"):
                    products.append(product_data)
            except Exception as e:
                logger.warning(f"Error extracting product: {e}")
                continue
    except Exception as e:
        logger.error(f"Error parsing catalogs: {e}")
    
    return products

async def fetch_page_with_retry(
    client: httpx.AsyncClient,
    page_number: int,
    query: str,
    sort_order: Optional[str],
    cursor: Optional[str],
    search_session_id: str
) -> Tuple[Optional[dict], Optional[str]]:
    """Fetch a page with retry logic"""
    payload = {
        "query": query,
        "type": "text_search",
        "page": page_number,
        "offset": (page_number - 1) * MAX_PRODUCTS_PER_PAGE,
        "limit": MAX_PRODUCTS_PER_PAGE,
        "isDevicePhone": False,
        "search_session_id": search_session_id
    }

    # Only add sort_option if sort_order is specified and not "relevance"
    if sort_order and sort_order != "relevance":
        payload["sort_option"] = {"sort_by": "price", "sort_order": sort_order}
    
    if cursor:
        payload["cursor"] = cursor

    url = "https://www.meesho.com/api/v1/products/search"

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = await client.post(url, json=payload)

            if response.status_code in RETRY_STATUS_CODES:
                wait_time = random.uniform(1, 2)
                logger.warning(f"Page {page_number}: Got {response.status_code}, waiting {wait_time:.2f}s (Retry {attempt}/{MAX_RETRIES})")
                await asyncio.sleep(wait_time)
                continue

            if response.status_code != 200:
                logger.error(f"Page {page_number}: HTTP {response.status_code}")
                return None, None

            try:
                data = response.json()
                return data, data.get("cursor")
            except Exception as e:
                logger.error(f"Page {page_number}: JSON parse error ({e})")
                return None, None

        except httpx.RequestError as e:
            wait_time = random.uniform(1, 2)
            logger.warning(f"Page {page_number}: Network error ({e}) waiting {wait_time:.2f}s (Retry {attempt}/{MAX_RETRIES})")
            await asyncio.sleep(wait_time)

    logger.error(f"Page {page_number}: Failed after {MAX_RETRIES} retries")
    return None, None

async def fetch_pages_with_cursor(
    query: str,
    sort_order: Optional[str],
    max_pages: int = MAX_PAGES,
    start_page: int = 1,
    start_cursor: Optional[str] = None
) -> Tuple[List[Tuple[int, List[Dict]]], Optional[str]]:
    """Fetch multiple pages with cursor-based pagination"""
    all_results = []
    cursor = start_cursor
    final_cursor = start_cursor
    search_session_id = f"ctx_1_uid_-1_txt_-1_t_{int(time.time() * 1000)}"

    async with httpx.AsyncClient(headers=headers, timeout=30, follow_redirects=True) as client:
        for page_number in range(start_page, start_page + max_pages):
            logger.info(f"🔄 Fetching page {page_number}...")
            
            data, cursor = await fetch_page_with_retry(client, page_number, query, sort_order, cursor, search_session_id)
            if not data:
                break

            final_cursor = cursor

            products = extract_products(data, query, sort_order or 'relevance', cursor, page_number)
            if not products:
                logger.warning(f"Page {page_number}: No products found, stopping.")
                break

            all_results.append((page_number, products))
            sample_prices = [p.get('min_catalog_price', 0) for p in products[:10]]
            logger.info(f"✅ Page {page_number}: Found {len(products)} products | Sample prices: {sample_prices}")

            if not cursor:
                logger.info("🛑 No cursor found — reached end of pagination.")
                break

    return all_results, final_cursor

async def store_in_redis(
    query: str,
    sort_order: Optional[str],
    products: List[Dict],
    page_number: int,
    cursor: Optional[str]
) -> bool:
    """Store scraped data in Redis"""
    try:
        redis_client = await get_redis_client()
        
        filter_name = 'relevance' if sort_order is None else sort_order
        redis_key = f'meesho:{query}:{filter_name}:data'
        
        metadata = {
            "query": query,
            "sort_order": sort_order,
            "total_products": len(products),
            "scraped_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "scraped_timestamp": int(time.time()),
            "last_page_scraped": page_number,
            "cursor": cursor
        }
        
        redis_data = {
            "metadata": metadata,
            "products": products
        }
        
        await redis_client.set(redis_key, json.dumps(redis_data, ensure_ascii=False))
        logger.info(f"✅ Stored {len(products)} products in Redis with key: {redis_key}")
        
        await redis_client.close()
        return True
    except Exception as e:
        logger.error(f"❌ Failed to store data in Redis: {e}")
        return False

async def get_redis_metadata(query: str, sort_order: Optional[str]) -> Optional[Dict]:
    """Fetch metadata for a keyword from Redis"""
    try:
        redis_client = await get_redis_client()
        filter_name = 'relevance' if sort_order is None else sort_order
        redis_key = f'meesho:{query}:{filter_name}:data'
        
        data = await redis_client.get(redis_key)
        await redis_client.close()
        
        if data:
            parsed_data = json.loads(data)
            return parsed_data.get("metadata", {})
    except Exception as e:
        logger.error(f"Error reading from Redis: {e}")
    return None

async def scrape_products(
    query: str,
    sort_order: Optional[str] = None,
    is_prefetch: bool = False
) -> Dict:
    """
    Main scraping function
    Returns: dict with status, total_products, and message
    """
    start_time = time.perf_counter()
    
    filter_name = 'relevance' if sort_order is None else sort_order
    metadata = await get_redis_metadata(query, sort_order)
    
    if is_prefetch:
        logger.info("🔄 Prefetch mode activated")
        if metadata:
            start_page = metadata.get("last_page_scraped", 1) + 1
            cursor = metadata.get("cursor", None)
            logger.info(f"⏩ Resuming prefetch from page {start_page}")
            max_pages_to_fetch = 5
        else:
            logger.warning("⚠️ No existing data found for prefetch, starting from page 1")
            start_page = 1
            cursor = None
            max_pages_to_fetch = 5
    else:
        if metadata:
            logger.info(f"🔎 Found previous scrape for '{query}' in Redis.")
            existing_products_count = metadata.get("total_products", 0)
            if existing_products_count < 20:
                start_page = metadata.get("last_page_scraped", 1) + 1
                cursor = metadata.get("cursor", None)
                logger.info(f"⏩ Resuming from page {start_page}")
            else:
                logger.info(f"✅ Found {existing_products_count} products in cache")
                return {
                    "status": "cached",
                    "total_products": existing_products_count,
                    "message": "Using cached data"
                }
        else:
            start_page = 1
            cursor = None
        
        max_pages_to_fetch = MAX_PAGES

    # Fetch pages
    results, final_cursor = await fetch_pages_with_cursor(
        query, sort_order, max_pages_to_fetch, start_page=start_page, start_cursor=cursor
    )

    all_products = []
    global_seen = set()
    last_page_scraped = start_page - 1
    
    # Load existing products if prefetching
    if is_prefetch and metadata:
        try:
            redis_client = await get_redis_client()
            redis_key = f'meesho:{query}:{filter_name}:data'
            existing_data = await redis_client.get(redis_key)
            await redis_client.close()
            
            if existing_data:
                existing_parsed = json.loads(existing_data)
                existing_products = existing_parsed.get("products", [])
                
                for product in existing_products:
                    pid = product.get('id')
                    if pid:
                        global_seen.add(pid)
                        all_products.append(product)
                
                logger.info(f"📦 Loaded {len(existing_products)} existing products from cache")
        except Exception as e:
            logger.warning(f"Could not load existing products: {e}")
    elif not is_prefetch and metadata:
        existing_products_count = metadata.get("total_products", 0)
        if existing_products_count < 20:
            try:
                redis_client = await get_redis_client()
                redis_key = f'meesho:{query}:{filter_name}:data'
                existing_data = await redis_client.get(redis_key)
                await redis_client.close()
                
                if existing_data:
                    existing_parsed = json.loads(existing_data)
                    existing_products = existing_parsed.get("products", [])
                    
                    for product in existing_products:
                        pid = product.get('id')
                        if pid:
                            global_seen.add(pid)
                            all_products.append(product)
                    
                    logger.info(f"📦 Loaded {len(existing_products)} existing products from cache")
            except Exception as e:
                logger.warning(f"Could not load existing products: {e}")
    
    # Process new results
    for page_number, products in results:
        last_page_scraped = page_number
        for product in products:
            pid = product.get('id')
            if pid and pid not in global_seen:
                global_seen.add(pid)
                all_products.append(product)

    # Sort if needed
    if sort_order == 'asc':
        all_products.sort(key=lambda x: x.get('min_catalog_price', 0))
    elif sort_order == 'desc':
        all_products.sort(key=lambda x: x.get('min_catalog_price', 0), reverse=True)

    # Store in Redis
    if all_products:
        await store_in_redis(query, sort_order, all_products, last_page_scraped, final_cursor)

    elapsed = time.perf_counter() - start_time
    mode_text = "Prefetch" if is_prefetch else "Search"
    logger.info(f"✅ {mode_text} Query: {query} | Products: {len(all_products)} | Time: {elapsed:.2f}s")

    return {
        "status": "success",
        "total_products": len(all_products),
        "message": f"Scraped {len(all_products)} products in {elapsed:.2f}s"
    }
