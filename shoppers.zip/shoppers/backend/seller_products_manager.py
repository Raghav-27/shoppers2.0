"""
Seller Products Manager (DB 1)
Handles all seller product operations in Redis DB 1
"""
import redis.asyncio as aioredis
import json
from typing import List, Dict, Optional
import logging
from redis_db import get_redis_products

logger = logging.getLogger(__name__)

class SellerProductsManager:
    """Manages seller products in Redis DB 1"""
    
    def __init__(self, redis_db1: aioredis.Redis):
        self.redis = redis_db1
    
    async def add_product(self, seller_id: int, product_id: int, product_data: Dict) -> bool:
        """
        Add or update seller product
        
        Args:
            seller_id: Seller ID
            product_id: Product ID
            product_data: Product details dict
        
        Returns:
            True if successful
        """
        try:
            key = f"seller:prod:{seller_id}:{product_id}"
            await self.redis.hset(key, mapping=product_data)
            
            # Add to seller's product set
            await self.redis.sadd(f"seller:prod:list:{seller_id}", product_id)
            
            # Add to all products set
            await self.redis.sadd("seller:prod:all", f"{seller_id}:{product_id}")
            
            # Update product count
            count = await self.redis.scard(f"seller:prod:list:{seller_id}")
            await self.redis.set(f"seller:prod:count:{seller_id}", count)
            
            logger.info(f"Product added: seller_id={seller_id}, product_id={product_id}")
            return True
        except Exception as e:
            logger.error(f"Error adding product: {e}")
            return False
    
    async def get_product(self, seller_id: int, product_id: int) -> Optional[Dict]:
        """Get product details"""
        try:
            key = f"seller:prod:{seller_id}:{product_id}"
            product = await self.redis.hgetall(key)
            return product if product else None
        except Exception as e:
            logger.error(f"Error getting product: {e}")
            return None
    
    async def get_seller_products(self, seller_id: int, limit: int = 100) -> List[Dict]:
        """Get all products for a seller"""
        try:
            product_ids = await self.redis.smembers(f"seller:prod:list:{seller_id}")
            products = []
            
            for product_id in list(product_ids)[:limit]:
                product = await self.get_product(seller_id, int(product_id))
                if product:
                    product['product_id'] = product_id
                    products.append(product)
            
            return products
        except Exception as e:
            logger.error(f"Error getting seller products: {e}")
            return []
    
    async def search_products(self, query: str, limit: int = 50) -> List[Dict]:
        """
        Search seller products by name/category
        
        Args:
            query: Search query string
            limit: Max results to return
        
        Returns:
            List of matching products
        """
        try:
            # Get all products
            all_product_keys = await self.redis.smembers("seller:prod:all")
            results = []
            
            query_lower = query.lower()
            
            for key_pair in all_product_keys:
                seller_id, product_id = key_pair.split(':')
                product = await self.get_product(int(seller_id), int(product_id))
                
                if product:
                    # Simple substring match in name/category
                    if (query_lower in product.get('name', '').lower() or
                        query_lower in product.get('category', '').lower()):
                        product['product_id'] = product_id
                        product['seller_id'] = seller_id
                        results.append(product)
                
                if len(results) >= limit:
                    break
            
            return results
        except Exception as e:
            logger.error(f"Error searching products: {e}")
            return []
    
    async def delete_product(self, seller_id: int, product_id: int) -> bool:
        """Soft delete product (mark as inactive)"""
        try:
            key = f"seller:prod:{seller_id}:{product_id}"
            await self.redis.hset(key, "is_active", "0")
            logger.info(f"Product marked inactive: seller_id={seller_id}, product_id={product_id}")
            return True
        except Exception as e:
            logger.error(f"Error deleting product: {e}")
            return False
    
    async def update_product_stock(self, seller_id: int, product_id: int, quantity: int) -> bool:
        """Update product stock"""
        try:
            key = f"seller:prod:{seller_id}:{product_id}"
            await self.redis.hset(key, "stock", quantity)
            logger.info(f"Stock updated: seller_id={seller_id}, product_id={product_id}, qty={quantity}")
            return True
        except Exception as e:
            logger.error(f"Error updating stock: {e}")
            return False
    
    async def get_seller_product_count(self, seller_id: int) -> int:
        """Get total active products for seller"""
        try:
            count = await self.redis.get(f"seller:prod:count:{seller_id}")
            return int(count) if count else 0
        except Exception as e:
            logger.error(f"Error getting product count: {e}")
            return 0

# Singleton instance
_seller_products_manager: Optional[SellerProductsManager] = None

async def get_seller_products_manager() -> SellerProductsManager:
    """Get singleton seller products manager"""
    global _seller_products_manager
    if _seller_products_manager is None:
        redis_db1 = await get_redis_products()
        _seller_products_manager = SellerProductsManager(redis_db1)
    return _seller_products_manager
