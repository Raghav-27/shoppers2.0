# Store Management System

## Overview

The seller platform now supports multi-store management, allowing each seller to create and manage multiple stores, each with its own products, description, and branding.

## Features

### 1. Multiple Stores per Seller
- Each seller can create unlimited stores
- Each store has:
  - Store name
  - Description
  - Store image/logo
  - Contact information (address, phone, email)
  - List of products

### 2. Store Management Interface

#### Manage Stores Page (`/seller/stores`)
- View all stores in a grid layout
- Create new stores
- Edit existing stores
- Delete stores (soft delete)
- See product count for each store

#### Store Details Page (`/seller/stores/:storeId`)
- View comprehensive store information
- Display store image
- Show all products in the store
- Add products directly to the store
- Edit store details

#### Dashboard Integration
- Stores overview on seller dashboard
- Quick stats showing total stores
- Preview of first 3 stores
- Quick navigation to manage stores

### 3. Product-Store Association

#### Adding Products to Stores
- When adding a product, sellers can select which store it belongs to
- Products can be standalone (not assigned to any store)
- Store selection dropdown shows all available stores
- URL parameter support: `/seller/add-product?store=<storeId>` pre-selects a store

#### Editing Products
- Change store assignment when editing products
- Move products between stores
- Remove products from stores

## API Endpoints

### Store Management

#### Get All Stores
```
GET /api/seller/stores
```
Returns all active stores for the authenticated seller.

#### Create Store
```
POST /api/seller/stores
```
Body:
```json
{
  "name": "My Store",
  "description": "Store description",
  "image_url": "https://example.com/image.jpg",
  "address": "123 Main St",
  "phone": "+1234567890",
  "email": "store@example.com"
}
```

#### Get Store Details
```
GET /api/seller/stores/:storeId
```
Returns store information with all products in the store.

#### Update Store
```
PUT /api/seller/stores/:storeId
```
Body: Same as create store

#### Delete Store
```
DELETE /api/seller/stores/:storeId
```
Soft deletes the store (sets `is_active` to 0).

### Product Updates

#### Add Product with Store
```
POST /api/seller/products
```
Body includes optional `store_id`:
```json
{
  "name": "Product Name",
  "price": 29.99,
  "category": "Electronics",
  "store_id": "1",  // Optional
  ...
}
```

#### Update Product Store Assignment
```
PUT /api/seller/products/:productId
```
Body includes `store_id` to change store assignment.

## Data Structure

### Redis Keys

#### Store Data
```
seller:{seller_id}:store:{store_id}       # Hash containing store details
seller:{seller_id}:stores                  # Set of store IDs
seller:{seller_id}:store_id_counter        # Counter for generating store IDs
seller:{seller_id}:store:{store_id}:products  # Set of product IDs in this store
```

#### Updated Product Data
```
seller:{seller_id}:product:{product_id}    # Now includes store_id field
```

### Store Hash Fields
- `id` - Store ID
- `seller_id` - Owner seller ID
- `name` - Store name
- `description` - Store description
- `image_url` - Store image URL
- `address` - Physical address
- `phone` - Contact phone
- `email` - Contact email
- `is_active` - Active status (1/0)
- `created_at` - Creation timestamp
- `updated_at` - Last update timestamp

## Components

### New Components

1. **ManageStores.js** - Main store management page
   - Lists all stores
   - Create/edit store form
   - Delete stores
   - Navigate to store details

2. **StoreDetails.js** - Individual store view
   - Display store information
   - List all products in store
   - Add products to store
   - Edit store details

3. **ManageStores.css** - Styling for store management
4. **StoreDetails.css** - Styling for store details page

### Updated Components

1. **SellerDashboard.js**
   - Added stores overview section
   - Store count stat card
   - Quick access to manage stores

2. **AddProduct.js**
   - Added store selection dropdown
   - Pre-select store from URL parameter
   - Optional store assignment

3. **App.example.js**
   - Added routes for `/seller/stores`
   - Added route for `/seller/stores/:storeId`

## Usage Guide

### For Sellers

#### Creating a Store
1. Navigate to "My Stores" from dashboard
2. Click "Add New Store"
3. Fill in store details:
   - Name (required)
   - Description
   - Image URL
   - Address
   - Contact info
4. Click "Create Store"

#### Managing Products in Stores
1. Option 1: From Store Details
   - Go to store details page
   - Click "Add Product to Store"
   - Product will be pre-assigned to that store

2. Option 2: From Add Product
   - Go to "Add Product"
   - Select store from dropdown
   - Product will be added to selected store

#### Editing Stores
1. Go to "My Stores"
2. Click "Edit" on any store card
3. Update store information
4. Click "Update Store"

#### Viewing Store Products
1. Go to "My Stores"
2. Click "View Details" on a store
3. See all products in that store
4. Edit or manage products

## Routes

- `/seller/stores` - Manage all stores
- `/seller/stores/:storeId` - View specific store details
- `/seller/add-product?store=:storeId` - Add product to specific store
- `/seller/dashboard` - Dashboard with stores overview

## Styling

### Design System
- Primary color: `#667eea` to `#764ba2` gradient
- Success color: `#28a745`
- Warning color: `#ffc107`
- Danger color: `#dc3545`

### Responsive Design
- Desktop: 3-column grid for stores
- Tablet: 2-column grid
- Mobile: Single column layout

## Future Enhancements

Potential improvements:
1. Image upload functionality (currently uses URLs)
2. Store analytics and insights
3. Store-specific settings
4. Customer reviews per store
5. Store performance metrics
6. Bulk product import to stores
7. Store templates
8. Multi-seller marketplaces

## Testing

To test the store management:

1. Login as a seller
2. Navigate to "My Stores"
3. Create a new store
4. Add products to the store
5. View store details
6. Edit store information
7. Verify dashboard shows store count

## Troubleshooting

### Store not showing products
- Check if products have `store_id` field set
- Verify product is active (`is_active` = 1)
- Check Redis set: `seller:{seller_id}:store:{store_id}:products`

### Cannot create store
- Verify seller is authenticated
- Check Redis connection
- Verify `store_id_counter` is incrementing

### Products not updating store association
- Check product update API call
- Verify old store product set is updated
- Check new store product set includes product

## Notes

- Stores are soft-deleted (not permanently removed)
- Products can exist without a store assignment
- Each seller manages their stores independently
- Store images require external hosting (URL-based)
