# ⚡ Quick Start Guide

Get the Shoppers application up and running in **5 minutes**!

---

## 🚀 Option 1: Docker (Recommended)

### Prerequisites
- Docker installed ([Get Docker](https://docs.docker.com/get-docker/))
- Docker Compose installed (usually comes with Docker Desktop)

### Steps

1. **Clone the repository**
```bash
git clone <your-repo-url>
cd shoppers
```

2. **Start the application**
```bash
docker-compose up --build
```

That's it! 🎉

### Access the application:
- **Frontend**: http://localhost
- **Backend API**: http://localhost/api/
- **API Documentation**: http://localhost/docs
- **Redis Commander**: http://localhost:8081

---

## 💻 Option 2: Local Development

### Prerequisites
- Python 3.11+
- Node.js 18+
- Redis (or use Docker for Redis only)

### Backend Setup

```bash
# 1. Navigate to backend
cd backend

# 2. Create virtual environment
python -m venv venv

# 3. Activate virtual environment
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# 4. Install dependencies
pip install -r requirements.txt

# 5. Create environment file
cp .env.example .env

# 6. Start Redis (if not using Docker)
# Option A: Docker
docker run -d -p 6379:6379 --name redis redis:7-alpine
# Option B: Local Redis
redis-server

# 7. Start the backend
uvicorn api:app --reload --host 0.0.0.0 --port 5000
```

### Frontend Setup

```bash
# In a new terminal, from project root

# 1. Install dependencies
npm install

# 2. Create environment file
cp .env.example .env

# 3. Edit .env and set:
# REACT_APP_API_URL=http://localhost:5000

# 4. Start the frontend
npm start
```

### Access the application:
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000
- **API Documentation**: http://localhost:5000/docs

---

## 📝 First-Time Setup

### 1. Create an Account
1. Open http://localhost (or http://localhost:3000)
2. Click "Sign Up"
3. Fill in your details
4. Click "Sign Up"

### 2. Search for Products
1. Enter a search term (e.g., "shoes", "laptop", "dress")
2. Select sort order (Relevance, Low to High, High to Low)
3. Click Search
4. Browse results!

### 3. Add to Lists
- Click ❤️ to add to Wishlist
- Click 🛒 to add to Cart
- Click ⚖️ to add to Compare

---

## 🔧 Configuration

### Environment Variables

**Backend** (`backend/.env`):
```env
REDIS_HOST=redis              # Use 'localhost' for local Redis
REDIS_PORT=6379
CORS_ORIGINS=http://localhost:3000,http://localhost:80
RATE_LIMIT_PER_MINUTE=60
LOG_LEVEL=INFO
```

**Frontend** (`.env`):
```env
REACT_APP_API_URL=http://localhost:5000  # For local dev
# Leave empty for Docker production
```

---

## 🧪 Test the Setup

### 1. Health Check
```bash
curl http://localhost:5000/health
# Expected: {"status":"healthy","redis":"connected"}
```

### 2. Search Test
```bash
curl "http://localhost:5000/api/search?query=shoes&sort=relevance&page=1"
# Expected: JSON with products array
```

### 3. API Documentation
Open: http://localhost:5000/docs
Try out the endpoints interactively!

---

## 🐛 Troubleshooting

### Backend won't start
```bash
# Check if port 5000 is already in use
# Windows:
netstat -ano | findstr :5000
# Mac/Linux:
lsof -i :5000

# Kill the process or use a different port
```

### Frontend can't connect to backend
```bash
# 1. Verify backend is running
curl http://localhost:5000/health

# 2. Check REACT_APP_API_URL in .env
cat .env | grep REACT_APP_API_URL

# 3. Restart frontend
npm start
```

### Redis connection error
```bash
# 1. Check if Redis is running
# Docker:
docker ps | grep redis

# Local:
redis-cli ping
# Expected: PONG

# 2. Start Redis if not running
# Docker:
docker run -d -p 6379:6379 --name redis redis:7-alpine

# Local:
redis-server
```

### Docker issues
```bash
# 1. Stop all containers
docker-compose down

# 2. Remove volumes (CAUTION: deletes data)
docker-compose down -v

# 3. Rebuild and restart
docker-compose up --build
```

---

## 📚 Next Steps

1. **Read the Full Documentation**: [FULL_README.md](./FULL_README.md)
2. **Learn About Deployment**: [DEPLOYMENT.md](./DEPLOYMENT.md)
3. **Understand the Changes**: [TRANSFORMATION_SUMMARY.md](./TRANSFORMATION_SUMMARY.md)
4. **Explore the API**: http://localhost:5000/docs

---

## 🎯 Common Use Cases

### Development with Hot Reload
```bash
# Use development docker-compose
docker-compose -f docker-compose.dev.yml up --build

# Backend and frontend will auto-reload on code changes!
```

### View Logs
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend
docker-compose logs -f frontend
```

### Inspect Redis Data
```bash
# Access Redis Commander
http://localhost:8081

# Or use CLI
docker-compose exec redis redis-cli
KEYS *
GET meesho:shoes:relevance:data
```

### Reset Everything
```bash
# Stop and remove everything (including data)
docker-compose down -v

# Start fresh
docker-compose up --build
```

---

## 💡 Pro Tips

1. **Use Docker for consistency** - Same environment everywhere
2. **Check /docs endpoint** - Interactive API testing
3. **Monitor Redis** - Use Redis Commander at :8081
4. **Rate limiting** - Max 60 requests/min globally, 20 searches/min
5. **Prefetching** - App automatically fetches more products as you scroll

---

## 🆘 Getting Help

- **Logs**: `docker-compose logs -f`
- **Health**: `curl http://localhost:5000/health`
- **Redis**: http://localhost:8081
- **API Docs**: http://localhost:5000/docs
- **Issue Tracker**: [GitHub Issues]

---

## ✅ Success Indicators

You're all set when you see:

- ✅ Backend health check returns `{"status":"healthy"}`
- ✅ Frontend loads at http://localhost
- ✅ Can search for products
- ✅ Can sign up and log in
- ✅ Redis Commander shows data at http://localhost:8081

---

**Happy Shopping! 🛍️**

---

*For detailed information, see [FULL_README.md](./FULL_README.md)*
