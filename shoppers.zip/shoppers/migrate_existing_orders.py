"""
Migration Script: Convert Legacy Orders (DB 4) to New Format (DB 3)

This script migrates existing orders from DB 4 (legacy order_manager.py) 
to DB 3 (new orders_manager.py format).

Old pattern (DB 4):
- all_orders set
- order:{order_id}
- user_orders:{email}
- seller_orders:{seller_id}

New pattern (DB 3):
- order:all set
- order:{order_id}
- order:user:{email}
- order:seller:{seller_id}
- order:status:{status}
- order:date:{YYYY-MM-DD}
"""
import redis
import json
from datetime import datetime

REDIS_HOST = 'localhost'
REDIS_PORT = 6379

def migrate_orders():
    """Migrate orders from DB 4 to DB 3"""
    print("=" * 70)
    print("ORDER DATA MIGRATION (DB 4 → DB 3)")
    print("=" * 70)
    
    # Connect to both databases
    r4 = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=4, decode_responses=True)
    r3 = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=3, decode_responses=True)
    
    # Step 1: Get all legacy orders from DB 4
    print("\n1. Scanning for legacy orders in DB 4...")
    legacy_order_ids = r4.smembers('all_orders')
    
    print(f"   Found {len(legacy_order_ids) if legacy_order_ids else 0} order(s)")
    
    if not legacy_order_ids:
        print("\n✅ No legacy orders to migrate!")
        return
    
    # Step 2: Check current state in DB 3
    current_order_all = r3.smembers('order:all')
    print(f"\n2. Current state in DB 3:")
    print(f"   order:all set: {len(current_order_all) if current_order_all else 0} order(s)")
    
    # Step 3: Migrate each order
    print(f"\n3. Migrating {len(legacy_order_ids)} order(s)...")
    
    migrated_count = 0
    skipped_count = 0
    
    for old_order_id in legacy_order_ids:
        print(f"\n   Processing {old_order_id}...")
        
        # Get order data from DB 4 (keys don't have 'order:' prefix in DB 4)
        old_order_data = r4.get(old_order_id)
        
        if not old_order_data:
            print(f"      ⚠️  No data found, skipping")
            skipped_count += 1
            continue
        
        try:
            order = json.loads(old_order_data)
        except json.JSONDecodeError:
            print(f"      ❌ Invalid JSON, skipping")
            skipped_count += 1
            continue
        
        # Check if already migrated to DB 3
        new_order_id = order.get('order_id', old_order_id)
        if r3.exists(f'order:{new_order_id}'):
            print(f"      ⚠️  Already exists in DB 3, skipping")
            skipped_count += 1
            continue
        
        # Get order metadata
        user_email = order.get('user_email', '')
        status = order.get('status', 'pending')
        created_at = order.get('created_at', '')
        
        # Extract date from created_at
        try:
            if isinstance(created_at, str):
                order_date = datetime.fromisoformat(created_at.replace('Z', '+00:00')).strftime('%Y-%m-%d')
            else:
                order_date = datetime.now().strftime('%Y-%m-%d')
        except:
            order_date = datetime.now().strftime('%Y-%m-%d')
        
        # Store order in DB 3 with new pattern
        r3.set(f'order:{new_order_id}', json.dumps(order), ex=31536000)  # 365 days TTL
        print(f"      ✅ Stored order:{new_order_id}")
        
        # Add to order:all set
        r3.sadd('order:all', new_order_id)
        print(f"      ✅ Added to order:all")
        
        # Add to user's orders set
        if user_email:
            r3.sadd(f'order:user:{user_email}', new_order_id)
            print(f"      ✅ Added to order:user:{user_email}")
        
        # Add to status set
        if status:
            r3.sadd(f'order:status:{status}', new_order_id)
            print(f"      ✅ Added to order:status:{status}")
        
        # Add to date set
        r3.sadd(f'order:date:{order_date}', new_order_id)
        print(f"      ✅ Added to order:date:{order_date}")
        
        # Add to seller's orders if items exist
        items = order.get('items', [])
        for item in items:
            seller_id = item.get('seller_id')
            if seller_id:
                r3.sadd(f'order:seller:{seller_id}', new_order_id)
        
        if items:
            print(f"      ✅ Added to seller order sets")
        
        migrated_count += 1
        print(f"      ✅ Order {new_order_id} migrated successfully!")
    
    # Step 4: Verify migration
    print(f"\n4. Verifying migration...")
    
    final_order_all = r3.smembers('order:all')
    pending_orders = r3.smembers('order:status:pending')
    
    print(f"\n   Final state in DB 3:")
    print(f"   order:all: {len(final_order_all) if final_order_all else 0} order(s)")
    print(f"   order:status:pending: {len(pending_orders) if pending_orders else 0} order(s)")
    
    # Show sample order
    if final_order_all:
        sample_id = list(final_order_all)[0]
        sample_order = r3.get(f'order:{sample_id}')
        if sample_order:
            sample = json.loads(sample_order)
            print(f"\n   Sample order:")
            print(f"   - ID: {sample.get('order_id', 'N/A')}")
            print(f"   - Customer: {sample.get('user_name', 'N/A')}")
            print(f"   - Amount: ${sample.get('total_amount', 'N/A')}")
            print(f"   - Status: {sample.get('status', 'N/A')}")
    
    print(f"\n{'=' * 70}")
    print(f"✅ MIGRATION COMPLETE!")
    print(f"{'=' * 70}")
    print(f"\nMigrated: {migrated_count} order(s)")
    print(f"Skipped: {skipped_count} order(s)")
    print(f"\nNext steps:")
    print(f"1. Refresh the admin dashboard")
    print(f"2. Verify orders appear in Order Management")
    print(f"3. If everything works, orders in DB 4 can be kept as backup")
    print(f"   or deleted if you want to save memory")

if __name__ == "__main__":
    try:
        migrate_orders()
    except Exception as e:
        print(f"\n❌ Migration failed: {e}")
        import traceback
        traceback.print_exc()
