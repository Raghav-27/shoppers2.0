"""
Test admin users endpoint
"""
import requests
import json

ADMIN_URL = "http://localhost:5002"

def test_users_endpoint():
    """Test fetching users list for management page"""
    
    # Login as admin
    session = requests.Session()
    
    login_response = session.post(
        f"{ADMIN_URL}/api/admin/login",
        json={"email": "admin@shoppers.com", "password": "admin123"}
    )
    
    if login_response.status_code != 200:
        print("❌ Admin login failed")
        return
    
    print("✅ Admin logged in successfully\n")
    
    # Fetch users list
    print("Fetching users list...")
    
    users_response = session.get(
        f"{ADMIN_URL}/api/admin/users",
        params={"offset": 0, "limit": 50}
    )
    
    print(f"Status: {users_response.status_code}")
    print(f"Response: {users_response.text}\n")
    
    if users_response.status_code == 200:
        data = users_response.json()
        users = data.get('users', [])
        total = data.get('total', 0)
        
        print(f"📋 Users Management Data:")
        print(f"Total Users: {total}")
        print(f"Users Retrieved: {len(users)}\n")
        
        if users:
            print("User Details:")
            print(json.dumps(users, indent=2))
            print(f"\n✅ SUCCESS! User Management page should show {len(users)} user(s)!")
        else:
            print("❌ No users found in response")
            print("\nLet's check Redis directly...")
            
            # Check Redis
            import redis
            r = redis.Redis(host='localhost', port=6379, db=0, decode_responses=True)
            
            print("\nRedis DB 0 user keys:")
            user_keys = [k for k in r.scan_iter('user:*') if ':state' not in k and not k.startswith('session:')]
            print(f"Found {len(user_keys)} user keys:")
            
            for key in user_keys[:5]:  # Show first 5
                user_data = r.get(key)
                if user_data:
                    import json as json_module
                    user = json_module.loads(user_data)
                    print(f"  - {key}: {user.get('first_name', 'N/A')} {user.get('last_name', 'N/A')} ({user.get('email', 'N/A')})")
    else:
        print(f"❌ Failed to fetch users: {users_response.text}")

if __name__ == "__main__":
    print("=" * 60)
    print("ADMIN USERS MANAGEMENT TEST")
    print("=" * 60)
    print()
    
    test_users_endpoint()
    
    print("\n" + "=" * 60)
