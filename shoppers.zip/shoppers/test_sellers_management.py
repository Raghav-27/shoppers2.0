"""
Test admin sellers management endpoint
"""
import requests
import json

ADMIN_URL = "http://localhost:5002"

def test_sellers_management():
    """Test fetching sellers list for management page"""
    
    # Login as admin
    session = requests.Session()
    
    login_response = session.post(
        f"{ADMIN_URL}/api/admin/login",
        json={"email": "admin@shoppers.com", "password": "admin123"}
    )
    
    if login_response.status_code != 200:
        print("❌ Admin login failed")
        return
    
    print("✅ Admin logged in successfully\n")
    
    # Fetch sellers list
    print("Fetching sellers list...")
    
    sellers_response = session.get(
        f"{ADMIN_URL}/api/admin/sellers",
        params={"offset": 0, "limit": 20}
    )
    
    print(f"Status: {sellers_response.status_code}")
    
    if sellers_response.status_code == 200:
        data = sellers_response.json()
        sellers = data.get('sellers', [])
        total = data.get('total', 0)
        
        print(f"\n📋 Sellers Management Data:")
        print(f"Total Sellers: {total}")
        print(f"Sellers Retrieved: {len(sellers)}\n")
        
        if sellers:
            print("Seller Details:")
            print(json.dumps(sellers, indent=2))
            
            print(f"\n🎉 SUCCESS! Seller Management page will now show {len(sellers)} seller(s)!")
        else:
            print("❌ No sellers found in response")
    else:
        print(f"❌ Failed to fetch sellers: {sellers_response.text}")

if __name__ == "__main__":
    print("=" * 60)
    print("ADMIN SELLERS MANAGEMENT TEST")
    print("=" * 60)
    print()
    
    test_sellers_management()
    
    print("\n" + "=" * 60)
